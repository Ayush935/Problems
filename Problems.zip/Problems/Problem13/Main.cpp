#include "Functionalities.h"

int main()
{
    Container data;
    CreateObjects(data);

    fnContainer Functions;
    Createlamda(Functions);

    std::cout << "AVerage " << AveragePages(data) << std::endl;

    DisplayFirstNPublisher(data, 2);

    for (BookPointer book : ContainerBooksAboveTHresoldPages(data))
    {
        std::cout << *book << std::endl;
    }

    Adaptor(data, Functions);

    auto BindFunction = std::bind(DisplayFirstNPublisher,std::ref(data),3);

    BindFunction();
}