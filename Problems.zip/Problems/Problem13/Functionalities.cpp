#include "Functionalities.h"

void CreateObjects(Container &data)
{
    data.push_back(std::make_shared<Book>("MH123", Genre::FANTASY, 123, "Ayush", "Durga"));
    data.push_back(std::make_shared<Book>("MH124", Genre::FICTION, 128, "Bob", "Mark"));
    data.push_back(std::make_shared<Book>("MH125", Genre::NON_FICTON, 323, "ABobby", "Lead"));
}

Fntype1 AveragePages;
Fntype2 DisplayFirstNPublisher;
Fntype3 IsAllBooksLessThan300;
Fntype3 AreAllBooksSameGenrePublisher;
Fntype5 ContainerBooksAboveTHresoldPages;

void Createlamda(fnContainer &functions)
{
    AveragePages = [](Container &data) -> float
    {
        if (data.empty())
        {
            throw;
        }
        float sum = 0.0;
        for (BookPointer book : data)
        {
            if (book)
            {
                sum += book->pages();
            }
        }

        return sum / data.size();
    };

    DisplayFirstNPublisher = [](Container &data, int N) -> void
    {
        if (data.empty())
        {
            throw;
        }

        for (BookPointer book : data)
        {
            if (book)
            {
                std::cout << *book << std::endl;
                N--;
                if (N == 0)
                {
                    break;
                }
            }
        }
    };

    IsAllBooksLessThan300 = [](Container &data) -> bool
    {
        if (data.empty())
        {
            throw;
        }

        for (BookPointer book : data)
        {
            if (book && book->pages() < 300)
            {
                return false;
            }
        }

        return true;
    };

    AreAllBooksSameGenrePublisher = [](Container &data) -> bool
    {
        if (data.empty())
        {
            throw;
        }
        int count = 0;
        Genre genre = data.front()->genre();
        std::string publisher = data.front()->publisher();
        for (BookPointer book : data)
        {
            if (book && book->genre() != genre && book->publisher() != publisher)
            {
                return false;
            }
        }

        return true;
    };

    ContainerBooksAboveTHresoldPages = [](Container &data) -> Container
    {
        if (data.empty())
        {
            throw;
        }

        Container result;

        for (BookPointer book : data)
        {
            if (book && book->pages() > 300)
            {
                result.push_back(book);
            }
        }

        if (result.empty())
        {
            throw;
        }

        if (result.size() > data.size())
        {
            throw;
        }

        return result;
    };

    functions.push_back(IsAllBooksLessThan300);
    functions.push_back(AreAllBooksSameGenrePublisher);
}

void Adaptor(Container &data, fnContainer &functions)
{
    if (data.empty())
    {
        throw;
    }

    if (functions.empty())
    {
        throw;
    }

    for(Fntype3 function: functions){
       std::cout<< (function)(data)<<"\n";
    }
}



