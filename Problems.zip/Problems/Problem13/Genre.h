#ifndef GENRE_H
#define GENRE_H

enum class Genre{
   FICTION,
   NON_FICTON,
   FANTASY
};

#endif // GENRE_H
