#ifndef BOOK_H
#define BOOK_H

#include <iostream>
#include "Genre.h"

class Book
{
private:
    std::string _id;
    Genre _genre;
    int _pages;
    std::string _author;
    std::string _publisher;

public:
    Book(/* args */) = default;
    Book(const Book &) = delete;
    Book(Book &&) = delete;
    Book &operator=(const Book &) = delete;
    Book &operator=(Book &&) = delete;
    ~Book() = default;

    Book(std::string id,
         Genre genre,
         int pages,
         std::string author,
         std::string publisher);

    std::string id() const { return _id; }

    Genre genre() const { return _genre; }
    void setGenre(const Genre &genre) { _genre = genre; }

    int pages() const { return _pages; }

    std::string author() const { return _author; }

    std::string publisher() const { return _publisher; }

    friend std::ostream &operator<<(std::ostream &os, const Book &rhs);

    
};

#endif // BOOK_H
