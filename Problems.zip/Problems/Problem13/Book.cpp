#include "Book.h"
std::ostream &operator<<(std::ostream &os, const Book &rhs) {
    os << "_id: " << rhs._id
       << " _genre: " << static_cast<int>(rhs._genre)
       << " _pages: " << rhs._pages
       << " _author: " << rhs._author
       << " _publisher: " << rhs._publisher;
    return os;
}

Book::Book(std::string id, Genre genre, int pages, std::string author, std::string publisher)
    : _id{id}, _genre{genre},_pages{pages},_author{author},_publisher{publisher}
{
}