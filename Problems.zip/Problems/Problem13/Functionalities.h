#include <list>
#include <functional>
#include <memory>
#include "Book.h"

using BookPointer = std::shared_ptr<Book>;
using Container = std::list<BookPointer>;

using Fntype1 = std::function<float(Container&data)>;
using Fntype2 = std::function<void(Container&data,int)>;
using Fntype3 = std::function<bool(Container&data)>;
using Fntype4 = std::function<void( Container&)>;
using Fntype5 = std::function<Container(Container&)>;

using fnContainer = std::list<Fntype3>;


void CreateObjects(Container &data);

void Createlamda(fnContainer &functions);

void Adaptor( Container& data,fnContainer& functions);

extern Fntype1 AveragePages;
extern Fntype2 DisplayFirstNPublisher;
extern Fntype3 IsAllBooksLessThan300;
extern Fntype3 AreAllBooksSameGenrePublisher;
extern Fntype5 ContainerBooksAboveTHresoldPages;
