#include "Reservation.h"
std::ostream &operator<<(std::ostream &os, const Reservation &rhs) {
    os << "_registration_id: " << rhs._registration_id
       << " _check_in_date: " << rhs._check_in_date
       << " _check_out_date: " << rhs._check_out_date
       << " _room_ref: " << rhs._room_ref.get()
       << " _guest_ref: " << rhs._guest_ref.get();
    return os;
}

Reservation::Reservation(std::string registration_id, std::string check_in_date, std::string check_out_date, RoomRef room_ref, GuestRef guest_ref)
   : _registration_id{registration_id},_check_in_date{check_in_date},_check_out_date{check_out_date},_room_ref{room_ref},_guest_ref{guest_ref}
{
}