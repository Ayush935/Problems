#include "Functionalities.h"

int main(){
    ReservationContainer reserve;
    RoomContainer rooms;
    GuestContainer guest;
    
    CreateRoomsGuests(rooms,guest);
    
    CreateReservations("MH123",124,"12/2/1221","12/1/2312",rooms,guest,reserve);

    ReservedRooms ("MH123", reserve);

    AVailableRooms("12132","!223321",rooms);
    
    //bindedAvailable("2353",rooms);
}