#ifndef GUEST_H
#define GUEST_H

#include <iostream>

class Guest
{
private:
    std::string _guest_id;
    std::string _name;
    unsigned int _contact_number;
    std::string _email_address;

public:
    Guest(/* args */) = delete;
    Guest(const Guest &) = delete;
    Guest(Guest &&) = default;
    Guest &operator=(const Guest &) = delete;
    Guest &operator=(Guest &&) = delete;
    ~Guest() = default;

    Guest(std::string guest_id,
          std::string name,
          unsigned int contact_number,
          std::string email_address);

    std::string guestId() const { return _guest_id; }

    std::string name() const { return _name; }

    unsigned int contactNumber() const { return _contact_number; }

    std::string emailAddress() const { return _email_address; }

    friend std::ostream &operator<<(std::ostream &os, const Guest &rhs);
};

#endif // GUEST_H
