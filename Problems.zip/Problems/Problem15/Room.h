#ifndef ROOM_H
#define ROOM_H

#include <iostream>
#include "RoomType.h"

class Room
{
private:
    int _room_number;
    RoomType _type;
    bool _available;
    float _cost_per_night;

public:
    Room(/* args */) = delete;
    Room(const Room &) = delete;
    Room(Room &&) = default;
    Room &operator=(const Room &) = delete;
    Room &operator=(Room &&) = delete;
    ~Room() = default;

    Room(int room_number,
         RoomType type,
         bool available,
         float cost_per_night);

    int roomNumber() const { return _room_number; }

    RoomType type() const { return _type; }
    void setType(const RoomType &type) { _type = type; }

    bool available() const { return _available; }
    void setAvailable(bool available) { _available = available; }

    float costPerNight() const { return _cost_per_night; }
    void setCostPerNight(float cost_per_night) { _cost_per_night = cost_per_night; }

    

    friend std::ostream &operator<<(std::ostream &os, const Room &rhs);
};

#endif // ROOM_H
