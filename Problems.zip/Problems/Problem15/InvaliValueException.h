#ifndef INVALIVALUEEXCEPTION_H
#define INVALIVALUEEXCEPTION_H

#include <iostream>
#include <stdexcept>

class InvalidValueExpression: std::exception
{
private:
    std::string _msg;
public:
    InvalidValueExpression(/* args */) = delete;
    InvalidValueExpression(const InvalidValueExpression &) = delete;
    InvalidValueExpression(InvalidValueExpression &&) = delete;
    InvalidValueExpression &operator=(const InvalidValueExpression &) = delete;
    InvalidValueExpression &operator=(InvalidValueExpression &&) = delete;
    ~InvalidValueExpression() = default;
    InvalidValueExpression(std::string msg) : _msg{msg} {}

    std::string What() const { return _msg; }
};

#endif // INVALIVALUEEXCEPTION_H
