#include "Room.h"
std::ostream &operator<<(std::ostream &os, const Room &rhs) {
    os << "_room_number: " << rhs._room_number
       << " _type: " << static_cast<int>(rhs._type)
       << " _available: " << rhs._available
       << " _cost_per_night: " << rhs._cost_per_night;
    return os;
}

Room::Room(int room_number, RoomType type, bool available, float cost_per_night)
    : _room_number{room_number},_type{type},_available{available},_cost_per_night{cost_per_night}
{
}