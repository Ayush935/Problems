#ifndef RESERVATION_H
#define RESERVATION_H

#include <iostream>
#include "Room.h"
#include "Guest.h"
#include <functional>
using RoomRef = std::reference_wrapper<Room>;
using GuestRef = std::reference_wrapper<Guest>;

class Reservation
{
private:
    std::string _registration_id;
    std::string _check_in_date;
    std::string _check_out_date;
    RoomRef _room_ref;
    GuestRef _guest_ref;

public:
    Reservation(/* args */) = delete;
    Reservation(const Reservation &) = delete;
    Reservation(Reservation &&) = delete;
    Reservation &operator=(const Reservation &) = delete;
    Reservation &operator=(Reservation &&) = delete;
    ~Reservation() = default;

    Reservation(std::string registration_id,
                std::string check_in_date,
                std::string check_out_date,
                RoomRef room_ref,
                GuestRef guest_ref);

    std::string registrationId() const { return _registration_id; }
    void setRegistrationId(const std::string &registration_id) { _registration_id = registration_id; }

    std::string checkInDate() const { return _check_in_date; }
    void setCheckInDate(const std::string &check_in_date) { _check_in_date = check_in_date; }

    std::string checkOutDate() const { return _check_out_date; }
    void setCheckOutDate(const std::string &check_out_date) { _check_out_date = check_out_date; }

    RoomRef roomRef() const { return _room_ref; }

    GuestRef guestRef() const { return _guest_ref; }

    friend std::ostream &operator<<(std::ostream &os, const Reservation &rhs);
};

#endif // RESERVATION_H
