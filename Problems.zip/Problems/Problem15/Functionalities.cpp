#include "Functionalities.h"

void CreateRoomsGuests(RoomContainer &rooms, GuestContainer &guests)
{
    rooms.push_back(std::make_shared<Room>(123, RoomType::DOUBLE, true, 200.0));
    rooms.push_back(std::make_shared<Room>(124, RoomType::SINGLE, true, 100.0));
    rooms.push_back(std::make_shared<Room>(125, RoomType::SUITE, true, 300.0));
    rooms.push_back(std::make_shared<Room>(126, RoomType::DOUBLE, true, 500.0));
    rooms.push_back(std::make_shared<Room>(127, RoomType::DOUBLE, true, 1000.0));

    guests.push_back(std::make_shared<Guest>("MH123", "Ayush", 123244, "Pune"));
    guests.push_back(std::make_shared<Guest>("MH223", "Ayush3", 4123244, "Pune2"));
    guests.push_back(std::make_shared<Guest>("MH323", "Ayush1", 14423244, "Pune1"));
}


FnType1 CreateReservations = [](std::string guestId, int roomNum, std::string checkDate, std::string checkOut, RoomContainer &rooms, GuestContainer &guest, ReservationContainer &reserve)
{
    if (rooms.empty())
    {
        throw ContainerEmptyDataException("Room Data is empty");
    }

    if (guest.empty())
    {
        throw ContainerEmptyDataException("Guest Data is empty");
    }

    // auto itr = guest.begin();
    // auto itr1 = rooms.begin();

    
    GuestPointer temp;
    for(GuestPointer p:guest){
        if(guestId == p->guestId()){
            temp=p;
            break;
        }
    }
    RoomPointer temp2;

    for(RoomPointer p:rooms){
        if(roomNum==p->roomNumber()){
            temp2=p;
            break;
        }
    }

    reserve.push_back(std::make_shared<Reservation>("R-101",checkDate,checkOut,*temp2, *temp));

};

FnType2 ReservedRooms = [](std::string guestId, ReservationContainer &data)
{
    if (data.empty())
    {
        throw ContainerEmptyDataException("Data is empty");
    }

    for (ReservationPointer rc : data)
    {
        if (rc && rc->guestRef().get().guestId() == guestId)
        {
            std::cout << *rc << std::endl;
        }
    }
};

FnType3 AVailableRooms = [](std::string checkin, std::string checkOut, RoomContainer &rooms)
{
    for (RoomPointer room : rooms)
    {
        if (room && room->available() == true)
        {
            std::cout << *room << std::endl;
        }
    }
    
};
// std::string FixedParam="8784294";

// FnType3 bindedAvailable=std::bind(AVailableRooms, FixedParam,std::placeholders::_1,std::placeholders::_2);
