#include "Guest.h"
std::ostream &operator<<(std::ostream &os, const Guest &rhs) {
    os << "_guest_id: " << rhs._guest_id
       << " _name: " << rhs._name
       << " _contact_number: " << rhs._contact_number
       << " _email_address: " << rhs._email_address;
    return os;
}

Guest::Guest(std::string guest_id, std::string name, unsigned int contact_number, std::string email_address)
    : _guest_id{guest_id},_name{name},_contact_number{contact_number},_email_address{email_address}
{
}