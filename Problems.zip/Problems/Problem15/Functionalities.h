#include <list>
#include <memory>
#include "Reservation.h"
#include "ContainerEmptyDataException.h"
#include "InvaliValueException.h"
// #include<functional>

using RoomPointer = std::shared_ptr<Room>;
using RoomContainer = std::list<RoomPointer>;

using GuestPointer = std::shared_ptr<Guest>;
using GuestContainer = std::list<GuestPointer>;

using ReservationPointer = std::shared_ptr<Reservation>;
using ReservationContainer = std::list<ReservationPointer>;

using FnType1 = std::function<void(std::string,int,std::string,std::string,RoomContainer &rooms,GuestContainer &guest,ReservationContainer&)>;
using FnType2 = std::function<void(std::string,ReservationContainer&)>;
using FnType3 = std::function<void(std::string,std::string,RoomContainer &rooms)>;



void CreateRoomsGuests(RoomContainer& rooms, GuestContainer& guests);


extern FnType1 CreateReservations;
extern FnType2 ReservedRooms;
extern FnType3 AVailableRooms;


extern FnType3 bindedAvailable;