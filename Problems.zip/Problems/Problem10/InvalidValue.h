#ifndef INVALIDVALUE_H
#define INVALIDVALUE_H

#include <iostream>

class InvalidValue
{
private:
    std::string _msg;
public:
    InvalidValue(/* args */) = default;
    InvalidValue(const InvalidValue&) = delete;
    InvalidValue &operator=(const InvalidValue&) = delete;
    InvalidValue( InvalidValue&&) = delete;
    InvalidValue &operator=(InvalidValue&&) = default;
    ~InvalidValue() = default;

    std::string what() const { return _msg; }
};

#endif // INVALIDVALUE_H
