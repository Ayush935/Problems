#include "Person.h"
#include "Student.h"
#include "Emplyoyee.h"
#include <vector>
#include <array>

using Container = std::vector<Person*>;
//using Container = std::array<Person*,5>;

void CreateObjPerson(Container &personData);

void CheckDisplayStudentEmplyoyee(const Container &personData);

void Display(Container &personData);

void DestroyObjPerson(Container &personData);
