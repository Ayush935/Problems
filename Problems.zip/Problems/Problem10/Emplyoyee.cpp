#include "Emplyoyee.h"
std::ostream &operator<<(std::ostream &os, const Emplyoyee &rhs) {
    os << static_cast<const Person &>(rhs)
       << " _employeeId: " << rhs._employeeId
       << " _department: " << rhs._department;
    return os;
}

Emplyoyee::Emplyoyee(std::string name, unsigned int age, Address *address, int employeeId, std::string department)
   : Person(name,age,address), _employeeId{employeeId}, _department{department}
{
}