#include "Address.h"
std::ostream &operator<<(std::ostream &os, const Address &rhs) {
    os << "_street: " << rhs._street
       << " _city: " << rhs._city
       << " _zipcode: " << rhs._zipcode;
    return os;
}

Address::Address(std::string street, std::string city, std::string zipcode)
    : _street{street}, _city{city}, _zipcode{zipcode}
{
}