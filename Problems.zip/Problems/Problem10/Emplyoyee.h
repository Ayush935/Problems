#ifndef EMPLYOYEE_H
#define EMPLYOYEE_H

#include "Person.h"
#include <ostream>

class Emplyoyee : public Person
{
private:
    int _employeeId;
    std::string _department;
public:
    Emplyoyee(/* args */) = default;
    Emplyoyee(const Emplyoyee&) = delete;
    Emplyoyee &operator=(const Emplyoyee&) = delete;
    Emplyoyee( Emplyoyee&&) = delete;
    Emplyoyee &operator=(Emplyoyee&&) = delete;
    ~Emplyoyee() = default;

    Emplyoyee(std::string name,unsigned int age,Address *address, int employeeId,std::string department);

    int employeeId() const { return _employeeId; }

    std::string department() const { return _department; }
    void setDepartment(const std::string &department) { _department = department; }

    friend std::ostream &operator<<(std::ostream &os, const Emplyoyee &rhs);


};

#endif // EMPLYOYEE_H
