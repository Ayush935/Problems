#include "Functionalities.h"
#include "ContainerDataException.h"
#include "InvalidValue.h"

void CreateObjPerson(Container &personData)
{
    personData.push_back(new Emplyoyee("Ayush", 20, new Address("Abcd", "Pune", "43522"), 1234, "Ml"));
    personData.push_back(new Emplyoyee("Bob", 30, new Address("Abcde", "Bombay", "43222"), 1534, "Software"));
    personData.push_back(new Student("Bob", 14, new Address("Dvsd", "Delhi", "23324"), 123, "A"));
    personData.push_back(new Student("Jack", 13, new Address("Desd", "Nagpur", "26324"), 125, "B"));
}

void CheckDisplayStudentEmplyoyee(const Container &personData)
{
    if (personData.empty())
    {
        throw ContainerDataException("personData is empty");
    }
    int count = 0;
    for (Person *ptr : personData)
    {
        if (ptr)
        {
            Emplyoyee *Eptr = dynamic_cast<Emplyoyee *>(ptr);
            if (Eptr)
            {
                count++;
                std::cout << "Person instance " << count << " is Employee" << std::endl;
                std::cout << "Employee ID ";
                std::cout << Eptr->employeeId() << std::endl;
                std::cout << "Employee Department ";
                std::cout << Eptr->department() << std::endl;
            }
            std::cout << std::endl;

            Student *Sptr = dynamic_cast<Student *>(ptr);
            if (Sptr)
            {
                count++;
                std::cout << "Person instance " << count << " is Student" << std::endl;
                std::cout << "Student ID ";
                std::cout << Sptr->studentId() << std::endl;
                std::cout << "Student Grade ";
                std::cout << Sptr->grade() << std::endl;
            }
            std::cout << std::endl;
        }
    }
}

void Display(Container &personData)
{
    if (personData.empty())
    {
        throw ContainerDataException("personData is empty");
    }
    // for(Person* ptr: personData){
    //     if(ptr){
    //         std::cout<<*ptr<<std::endl;
    //     }
    // }
    // for(std::array<int,5>::reverse_iterator itr =arr.rbegin();itr!=arr.rend();++itr ){
    //     std::cout<<*itr<<"\n";
    // }

    for (Container::reverse_iterator itr = personData.rbegin(); itr != personData.rend(); ++itr)
    {

        Emplyoyee *Eptr = dynamic_cast<Emplyoyee *>(*itr);
        if (Eptr)
        {
            std::cout << *Eptr << std::endl;
        }

        Student *Sptr = dynamic_cast<Student *>(*itr);
        if (Sptr)
        {
            std::cout << *Sptr << std::endl;
        }
    }
}

void DestroyObjPerson(Container &personData)
{
    if (personData.empty())
    {
        throw ContainerDataException("personData is empty");
    }

    for (Person *ptr : personData)
    {
        if (ptr)
        {
            if (ptr->address())
            {
                delete ptr->address();
            }
            delete ptr;
        }
    }
}
