#ifndef STUDENT_H
#define STUDENT_H

#include "Person.h"
#include <iostream>

class Student : public Person
{
private:
    int _studentId;
    std::string _grade;

public:
    Student(/* args */) = default;
    Student(const Student&) = delete;
    Student &operator=(const Student&) = delete;
    Student( Student&&) = delete;
    Student &operator=(Student&&) = delete;
    ~Student() = default;

    Student(std::string name,unsigned int age,Address *address,int studentId,std::string grade);

    int studentId() const { return _studentId; }
    void setStudentId(int studentId) { _studentId = studentId; }

    std::string grade() const { return _grade; }
    void setGrade(const std::string &grade) { _grade = grade; }

    friend std::ostream &operator<<(std::ostream &os, const Student &rhs);

    
};

#endif // STUDENT_H
