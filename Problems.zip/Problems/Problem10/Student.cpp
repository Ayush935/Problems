#include "Student.h"
std::ostream &operator<<(std::ostream &os, const Student &rhs) {
    os << static_cast<const Person &>(rhs)
       << " _studentId: " << rhs._studentId
       << " _grade: " << rhs._grade;
    return os;
}

Student::Student(std::string name, unsigned int age, Address *address, int studentId, std::string grade)
   : Person(name,age,address), _studentId{studentId}, _grade{grade}
{
}