#ifndef ADDRESS_H
#define ADDRESS_H

#include <iostream>

class Address
{
private:
    std::string _street;
    std::string _city;
    std::string _zipcode;

public:
    Address(/* args */) = default;
    Address(const Address&) = delete;
    Address &operator=(const Address&) = delete;
    Address( Address&&) = delete;
    Address &operator=(Address&&) = delete;
    ~Address() = default;

    Address( std::string street,std::string city,std::string zipcode);

    std::string street() const { return _street; }
    void setStreet(const std::string &street) { _street = street; }

    std::string city() const { return _city; }
    void setCity(const std::string &city) { _city = city; }

    std::string zipcode() const { return _zipcode; }

    friend std::ostream &operator<<(std::ostream &os, const Address &rhs);
};

#endif // ADDRESS_H
