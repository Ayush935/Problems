#ifndef CONTAINERDATAEXCEPTION_H
#define CONTAINERDATAEXCEPTION_H

#include <iostream>

class ContainerDataException
{
private:
    std::string _msg;
public:
    ContainerDataException(/* args */) = default;
    ContainerDataException(const ContainerDataException&) = delete;
    ContainerDataException &operator=(const ContainerDataException&) = delete;
    ContainerDataException( ContainerDataException&&) = delete;
    ContainerDataException &operator=(ContainerDataException&&) = default;
    ~ContainerDataException() = default;

    ContainerDataException(std::string msg){_msg = msg;};

    std::string what() const { return _msg; }
};

#endif // CONTAINERDATAEXCEPTION_H
