#ifndef PERSON_H
#define PERSON_H

#include "Address.h"
#include <ostream>

class Person
{
private:
    std::string _name;
    unsigned int _age;
    Address *_address;
public:
    Person(/* args */) = default;
    Person(const Person&) = delete;
    Person &operator=(const Person&) = delete;
    Person( Person&&) = delete;
    Person &operator=(Person&&) = delete;
    virtual ~Person() = default;

    Person(std::string name,unsigned int age,Address *address);

    Address *address() const { return _address; }

    void setAddress(Address *address) { _address = address; }

    std::string name() const { return _name; }
    void setName(const std::string &name) { _name = name; }

    unsigned int age() const { return _age; }
    void setAge(unsigned int age) { _age = age; }

    friend std::ostream &operator<<(std::ostream &os, const Person &rhs);

    friend std::ostream &operator<<(std::ostream &os, const Person &rhs);
};

#endif // PERSON_H
