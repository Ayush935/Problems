#include "Functionalities.h"
#include "ContainerDataException.h"
#include "InvalidValue.h"

int main()
{
    Container personData;
    CreateObjPerson(personData);

    try
    {
        CheckDisplayStudentEmplyoyee(personData);

        Display(personData);

        DestroyObjPerson(personData);
    }
    catch (const ContainerDataException &e)
    {
        std::cerr << e.what() << '\n';
    }
    catch (const InvalidValue &e){
        std::cerr << e.what() << '\n';
    }
}