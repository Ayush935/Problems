#include "Person.h"

Person::Person(std::string name, unsigned int age, Address *address)
    : _name{name}, _age{age}, _address{address}
{
}

std::ostream &operator<<(std::ostream &os, const Person &rhs) {
    os << "_name: " << rhs._name
       << " _age: " << rhs._age
       << " _address: " << *(rhs._address);
    return os;
}
