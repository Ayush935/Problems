#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <iostream>
#include <vector>
#include "Car.h"
using Container = std::vector<Car*>;

/*
  Create Insatances of Car
*/
void CreateObjCar(Container &data);

/*
  Find the Engine HorsePower
  - whose Carid is provided in argument
*/
int FindEngineHorsepower(const Container &data,const std::string Carid);

/*
  Find the intances of Car
  - whose Engine Torque is over 80
*/
Container FindCarInstancesEngineTorque(const Container&data);

/*
  Find the Car instance
  -whose cartype is provided in the argument
*/
Container FindCarInstances(const Container&data,const CarType type);

/*
  Find the average Horsepower 
  - Engine TYpe should be ICT
  - Car price is over 1000000
*/
float FindAverageHorsepower(const Container&data);

/*
  Find Car id of the car with lowest car price
*/
std::string FindCarIdLowestPrice(const Container& data);

/*
  Accepts refernce or pointers to 2 instances of car and returns their combined price
*/
// Car* operator+(Car& rhs, Car& lhs);
float CombinedPrice(Car& rhs, Car& lhs);


#endif // FUNCTIONALITIES_H
