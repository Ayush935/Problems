#include "Engine.h"

std::ostream &operator<<(std::ostream &os, const Engine &rhs) {
    os << "_engine_Number: " << rhs._engine_Number
       << " _engine_type: " << static_cast<int>(rhs._engine_type)
       << " _engine_Horsepower: " << rhs._engine_Horsepower
       << " _engine_torque: " << rhs._engine_torque;
    return os;
}

Engine::Engine(std::string engine_Number, EngineType engine_type, int engine_Horsepower, int engine_torque)
    : _engine_Number{engine_Number},_engine_type{engine_type},_engine_Horsepower{engine_Horsepower},_engine_torque{engine_torque}
{
}