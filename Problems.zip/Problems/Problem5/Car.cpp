#include "Car.h"
std::ostream &operator<<(std::ostream &os, const Car &rhs) {
    os << "_car_id: " << rhs._car_id
       << " _car_brand: " << rhs._car_brand
       << " _type: " << static_cast<int>(rhs._type)
       << " carEngine: " << *(rhs.carEngine)
       << " _car_price: " << rhs._car_price;
    return os;
}

Car::Car(std::string car_id, std::string car_brand, CarType type, Engine *_carEngine, float car_price)
   : _car_id{car_id},_car_brand{car_brand},_type{type},carEngine{_carEngine},_car_price{car_price}
{
}