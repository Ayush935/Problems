#ifndef CAR_H
#define CAR_H

#include <iostream>
#include "CarType.h"
#include "Engine.h"

class Car
{
private:
    std::string _car_id;
    std::string _car_brand;
    CarType _type;
    Engine * carEngine;
    float _car_price;


public:
    Car() =  default;
    Car(const Car&) = delete;
    Car operator=(const Car&) = delete;
    Car(Car&&) = delete;
    Car operator=(Car&&) = delete;
    ~Car() = default;

    Car( std::string car_id,std::string car_brand,CarType type,Engine * _carEngine,float car_price);

    std::string carId() const { return _car_id; }
    void setCarId(const std::string &car_id) { _car_id = car_id; }

    std::string carBrand() const { return _car_brand; }
    void setCarBrand(const std::string &car_brand) { _car_brand = car_brand; }

    CarType type() const { return _type; }
    void setType(const CarType &type) { _type = type; }

    Engine * getCarEngine() const { return carEngine; }
    void setCarEngine(Engine * carEngine_) { carEngine = carEngine_; }

    float carPrice() const { return _car_price; }
    void setCarPrice(float car_price) { _car_price = car_price; }

    friend std::ostream &operator<<(std::ostream &os, const Car &rhs);
};

#endif // CAR_H
