#ifndef ENGINE_H
#define ENGINE_H

#include "EngineType.h"
#include <iostream>

class Engine
{
private:
    std::string _engine_Number;
    EngineType _engine_type;
    int _engine_Horsepower;
    int _engine_torque;


public:
    Engine() =  default;
    Engine(const Engine&) = delete;
    Engine operator=(const Engine&) = delete;
    Engine(Engine&&) = delete;
    Engine operator=(Engine&&) = delete;
    ~Engine() = default;

    Engine(std::string engine_Number,EngineType engine_type,int engine_Horsepower,int engine_torque);

    std::string engineNumber() const { return _engine_Number; }
    void setEngineNumber(const std::string &engine_Number) { _engine_Number = engine_Number; }

    EngineType engineType() const { return _engine_type; }
    void setEngineType(const EngineType &engine_type) { _engine_type = engine_type; }

    int engineHorsepower() const { return _engine_Horsepower; }
    void setEngineHorsepower(int engine_Horsepower) { _engine_Horsepower = engine_Horsepower; }

    int engineTorque() const { return _engine_torque; }
    void setEngineTorque(int engine_torque) { _engine_torque = engine_torque; }

    friend std::ostream &operator<<(std::ostream &os, const Engine &rhs);
};

#endif // ENGINE_H
