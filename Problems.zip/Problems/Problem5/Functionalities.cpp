#include "Functionalities.h"


void CreateObjCar(Container &data)
{
    data.push_back(new Car("MH123","Honda",CarType::HATCHBACK,new Engine("12h1",EngineType::HYBRID,200,56),500000.0f));
    data.push_back(new Car("MH432","Maruti",CarType::SEDAN,new Engine("124g1",EngineType::ICT,240,96),5000000.0f));
    data.push_back(new Car("MH193","Tesla",CarType::SPORTS,new Engine("1232h1",EngineType::HYBRID,100,76),1500000.0f));
    data.push_back(new Car("MH125","Tata",CarType::SUV,new Engine("12re41",EngineType::ICT,400,76),90000000.0f));
    data.push_back(new Car("MS123","Indica",CarType::HATCHBACK,new Engine("112h1",EngineType::HYBRID,900,156),95000000.0f));

}

int FindEngineHorsepower(const Container &data, const std::string Carid)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }
    int Horsepower = 0;
    for(Car* ptr: data){
        if(ptr && ptr->carId()==Carid){
           Horsepower =  ptr->getCarEngine()->engineHorsepower();
        }
    }
    
    return Horsepower;
}

Container FindCarInstancesEngineTorque(const Container &data)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }
    
    Container result;
    for(Car* ptr: data){
        if(ptr && ptr->getCarEngine()->engineTorque()>80){
            result.push_back(ptr);     
        }
    }

    return result;
}

Container FindCarInstances(const Container &data, const CarType type)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }

    Container result;
    for(Car* ptr: data){
        if(ptr && ptr->type()==type){
            result.push_back(ptr);
        }
    }
    return result;
}

float FindAverageHorsepower(const Container &data)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }
    EngineType type = EngineType::ICT;
    float sum = 0.0f;
    int count = 0;
    for(Car* ptr: data){
        if(ptr && ptr->getCarEngine()->engineType()==type && ptr->carPrice()>1000000){
            sum = sum + ptr->getCarEngine()->engineHorsepower();
            count++;
        }
    }
    return sum/count;
}

std::string FindCarIdLowestPrice(const Container &data)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }
    
    float CardPrice = 100000000000000.0f;
    for(Car* ptr: data){
        if(ptr && ptr->carPrice()<CardPrice ){
            CardPrice = ptr->carPrice();
        }
    }
    
    std::string Carid = "";
    for(Car* ptr: data){
        if(ptr && ptr->carPrice()==CardPrice ){
            Carid = ptr->carId();
        }
    }

    return Carid;
}

// Car* operator+(Car &rhs, Car &lhs)
// {
//     Car *temp;
//     temp->setCarPrice(rhs.carPrice()+lhs.carPrice());

//     return temp;
// }

float CombinedPrice(Car& rhs, Car& lhs){
    return rhs.carPrice()+lhs.carPrice();
}