#include "Functionalities.h"

int main(){
    Container data;

    CreateObjCar(data);

    std::cout<<"Enter the car Id"<<std::endl;
    std::string carid;
    getline(std::cin,carid);
    std::cout<<"Horse Power is "<<FindEngineHorsepower(data,carid)<<std::endl;
    
    std::cout<<"Car Instances greater than 80 Engine Torque"<<std::endl;
    for(Car *ptr : FindCarInstancesEngineTorque(data)){
        std::cout<<*ptr<<std::endl;
    }

    std::cout<<"Enter the Car type"<<std::endl;
    int n;
    std::cin>>n;
    CarType type = CarType::HATCHBACK;
    switch (n)
    {
    case 0:
        type = CarType::SEDAN;
        break;
    case 1:
        type = CarType::SUV;
        break;
    case 2:
        type = CarType::SPORTS;
        break;
    case 3:
        type = CarType::HATCHBACK;
        break;
    
    default:
        break;
    }

    std::cout<<"Car INstances matches the type " << static_cast<int>(type)<<" are as follows"<<std::endl;
    for(Car *ptr : FindCarInstances(data,type)){
        std::cout<<*ptr<<std::endl;
    }

    std::cout<<"Average amount of Horsepower is "<<FindAverageHorsepower(data)<<std::endl;


    std::cout<<"Lowest price Car ID is "<<FindCarIdLowestPrice(data)<<std::endl;
    
      
    Car a;
    Car b;
    std::cout<<"Combination of the price"<<CombinedPrice(b, a)<<std::endl;

    
}