#ifndef TICKET_H
#define TICKET_H

#include "TicketType.h"
#include <iostream>
class Ticket
{
private:
    float m_tax;
    TicketType m_type;

public:
    Ticket(/* args */) = default;
    Ticket(const Ticket &) = delete;
    Ticket(Ticket &&) = default;
    Ticket &operator=(const Ticket &) = delete;
    Ticket &operator=(Ticket &&) = delete;
    ~Ticket() = default;

    Ticket(float _tax,
           TicketType _type);

    float tax() const { return m_tax; }

    TicketType type() const { return m_type; }

    friend std::ostream &operator<<(std::ostream &os, const Ticket &rhs);
};

#endif // TICKET_H
