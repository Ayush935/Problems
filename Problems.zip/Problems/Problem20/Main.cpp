#include "Functionalities.h"
#include <thread>
#include <future>


int main(){
    Container data;
    TicketRefContainer ref;
    CreateObjects(data,ref);
    
    PassengerIdContainer ps{123,"Emp101"};
    std::thread t1(&DisplayAverage,std::ref(data),std::ref(ps));
    if(t1.joinable()){
        t1.join();
    }
    
    std::promise<Vtype>pr1;
    std::future<Vtype>ft1 = pr1.get_future();

    std::future<std::optional<PassengerPtr>> answer = std::async(&DisplayPassenger,std::ref(data),std::ref(ft1));

    std::cout<<"Enter Value integer for id"<<std::endl;
    int value;
    std::cin>>value;

    pr1.set_value(value);

    std::optional<PassengerPtr> answer1 = answer.get();

    if(answer1.has_value()){
        PassengerPtr ans = answer1.value();
        std::cout<<"Displaying Passenger having matching id"<<"\n";
        std::cout<<*ans<<"\n";
    }

    std::thread t2(&DisplayMaximimPassengerFare,std::ref(data));
    if(t2.joinable()){
        t2.join();
    }
    
    std::promise<std::string>pr2;
    std::future<std::string>ft2 = pr2.get_future();
    
    std::future<std::optional<Container>> result = std::async(&NotMatchesPassengerName,std::ref(data),std::ref(ft2));
    std::cout<<"Enter Passenger Name"<<std::endl;
    std::string name;
    std::cin>>name;
    pr2.set_value(name);
    std::optional<Container> result1 = result.get();
    
    if(result1.has_value()){
         for(auto it: result1.value()){
            std::cout<<*it<<std::endl;
         }
    }
}