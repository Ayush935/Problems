#ifndef PASSENGER_H
#define PASSENGER_H

#include <iostream>
#include <variant>
#include "Ticket.h"
#include <functional>
using Vtype = std::variant<int, std::string>;
using TicketRef = std::reference_wrapper<Ticket>;

class Passenger
{
private:
    Vtype m_id;
    std::string m_name;
    unsigned short m_age;
    TicketRef m_ref;
    float m_flare;

public:
    Passenger(/* args */) = default;
    Passenger(const Passenger &) = delete;
    Passenger(Passenger &&) = delete;
    Passenger &operator=(const Passenger &) = delete;
    Passenger &operator=(Passenger &&) = delete;
    ~Passenger() = default;

    Passenger(Vtype m_id,
              std::string m_name,
              unsigned short m_age,
              TicketRef m_ref,
              float m_flare);

    Vtype id() const { return m_id; }

    std::string name() const { return m_name; }

    unsigned short age() const { return m_age; }

    

    float flare() const { return m_flare; }

    TicketRef ref() const { return m_ref; }
    void setRef(const TicketRef &ref) { m_ref = ref; }

    friend std::ostream &operator<<(std::ostream &os, const Passenger &rhs);
};

#endif // PASSENGER_H
