#include "Functionalities.h"
std::mutex m1;

void CreateObjects(Container &data, TicketRefContainer &refData)
{
    refData.emplace_back(Ticket(10000.0f, TicketType::GENERAL));
    refData.emplace_back(Ticket(20000.0f, TicketType::RESERVED));
    refData.emplace_back(Ticket(30000.0f, TicketType::RESERVED));
    auto itr = refData.begin();
    if (itr != refData.end())
    {
        data.emplace_back(std::make_shared<Passenger>(123, "Ayush", 23, *itr++, 123400.4f));
    }
    if (itr != refData.end())
    {
        data.emplace_back(std::make_shared<Passenger>("Emp101", "Bob", 33, *itr++, 323400.4f));
    }
    if (itr != refData.end())
    {
        data.emplace_back(std::make_shared<Passenger>(125, "Bobby", 43, *itr++, 1234000.4f));
    }
}

void DisplayAverage(const Container &data, const PassengerIdContainer &ps)
{
    if (data.empty())
    {
        throw;
    }

    float sum = 0.0f;
    int count = 0;
    for (PassengerPtr ptr : data)
    {
        if (ptr)
        {
            for (Vtype pss : ps)
            {
                if (ptr->id() == pss)
                {
                    sum += ptr->age();
                    count++;
                    break;
                }
            }
        }
    }
    std::unique_lock<std::mutex> ul(m1);
    std::cout << "Average is " << sum / static_cast<float>(count) << std::endl;
}

std::optional<PassengerPtr> DisplayPassenger(Container &data, std::future<Vtype> &type)
{
    if (data.empty())
    {
        throw;
    }
    PassengerPtr answer;
    int count = 0;
    Vtype v = type.get();
    for (PassengerPtr ptr : data)
    {
        if (ptr && ptr->id() == v)
        {
            answer = ptr;
            count++;
            break;
        }
    }

    if (count == 0)
    {
        return std::nullopt;
    }

    return answer;
}

void DisplayMaximimPassengerFare(const Container &data)
{
    if (data.empty())
    {
        throw;
    }

    float MaxFare = data.front()->flare();
    for (PassengerPtr ptr : data)
    {
        if (ptr && ptr->flare() > MaxFare)
        {
            MaxFare = ptr->flare();
        }
    }
    for (PassengerPtr ptr : data)
    {
        if (ptr && ptr->flare() == MaxFare)
        {
            std::unique_lock<std::mutex> ul(m1);
            std::cout << "Maximum fare is " << MaxFare << std::endl;
            break;
        }
    }
}

std::optional<Container> NotMatchesPassengerName(const Container &data, std::future<std::string> &name)
{
    
    Container result;
    std::string s = name.get();
    for (PassengerPtr ptr : data)
    {
        if (ptr)
        {
            if ((ptr->name() != s))
            {
                result.emplace_back(ptr);
            }
        }
    }

    if (result.empty())
    {
        return std::nullopt;
    }

    return result;
}
