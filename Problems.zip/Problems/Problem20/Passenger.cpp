#include "Passenger.h"
std::ostream &operator<<(std::ostream &os, const Passenger &rhs) {
   
   if(std::holds_alternative<int>(rhs.m_id)){
      os<<"m_id "<<std::get<0>(rhs.m_id);
   }
   if(std::holds_alternative<std::string>(rhs.m_id)){
      os<<"m_id "<<std::get<1>(rhs.m_id);
   }
   
    os  << " m_name: " << rhs.m_name
       << " m_age: " << rhs.m_age
       << " m_ref: " << rhs.m_ref.get()
       << " m_flare: " << rhs.m_flare;
    return os;
}

Passenger::Passenger(Vtype m_id, std::string m_name, unsigned short m_age, TicketRef m_ref, float m_flare)
   : m_id{m_id},m_name{m_name},m_age{m_age},m_ref{m_ref},m_flare{m_flare}
{
}