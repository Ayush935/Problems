#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include "Passenger.h"
#include <memory>
#include<future>
#include <list>
#include <optional>
#include <mutex>


using PassengerPtr = std::shared_ptr<Passenger>;
using Container = std::list<PassengerPtr>;
using TicketRefContainer = std::list<Ticket>;
using PassengerIdContainer = std::list<Vtype>;

void CreateObjects(Container& data,TicketRefContainer& refData);
void DisplayAverage(const Container& data,const PassengerIdContainer& ps);
std::optional<PassengerPtr> DisplayPassenger(Container& data,std::future<Vtype>& type);
void DisplayMaximimPassengerFare(const Container& data);
std::optional<Container> NotMatchesPassengerName (const Container& data,std::future<std::string> &name);


#endif // FUNCTIONALITIES_H
