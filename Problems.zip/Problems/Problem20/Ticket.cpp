#include "Ticket.h"
std::ostream &operator<<(std::ostream &os, const Ticket &rhs) {
    std::string val = "";
    if(rhs.m_type==TicketType::GENERAL){
        val="GENERAL";
    }
    if(rhs.m_type==TicketType::RESERVED){
        val="RESERVED";
    }
    os << "m_tax: " << rhs.m_tax
       << " m_type: " << val;
    return os;
}

Ticket::Ticket(float _tax, TicketType _type)
    : m_tax{_tax},m_type{_type}
{
}