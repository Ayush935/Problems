#ifndef TRANSMISSIONTYPE_H
#define TRANSMISSIONTYPE_H

enum class TransmissionType{
    MANUAL,
    AUTOMATIVE

};

#endif // TRANSMISSIONTYPE_H
