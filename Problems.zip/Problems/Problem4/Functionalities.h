#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <list>
#include "RegisteredOwners.h"
#include "CommercialOwner.h"
#include "PrivateVehicleOwner.h"

using Container = std::list<RegisteredOwners*>;

void CreateObjRegisteredOwner(Container &data);

void findVehicleDetails(const int vehicleID,const Container &data);

void FindAvgMaxMin(const Container& data);

void findCommercialOwner(CommercialType type,const Container& data);

Container FindLastNinstances(Container& data,int N);

void INstancesAboveThresold(Container &data);



#endif // FUNCTIONALITIES_H
