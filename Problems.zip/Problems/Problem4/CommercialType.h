#ifndef COMMERCIALTYPE_H
#define COMMERCIALTYPE_H

enum class CommercialType{
    ECONOMIC,
    COMMERCIAL

};

#endif // COMMERCIALTYPE_H
