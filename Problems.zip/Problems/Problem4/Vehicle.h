#ifndef VEHICLE_H
#define VEHICLE_H

#include <iostream>
#include "VehicleType.h"
#include "FuelType.h"
#include "TransmissionType.h"

class Vehicle
{
private:
    static int id;
    int _vehicle_id;
    std::string _vehicle_name;
    VehicleType _type;
    float _price;
    int _seat_count;
    std::string _brand;
    FuelType _fuel_type;
    TransmissionType _transmission_type;

public:
    Vehicle() = default;                               //default constructor
    Vehicle(const Vehicle&) = delete;                  //copy constructor - not enabled
    Vehicle& operator=(const Vehicle&) = delete;       //copy assignment - not enabled
    Vehicle(Vehicle &&) = default;                      //move constructor - not enabled
    Vehicle& operator=( Vehicle&&) = delete;      //move assignment - not enabled
    ~Vehicle() = default;                               //default destructor
    Vehicle(std::string vehicle_name,VehicleType type,float price,int seat_count,std::string brand,FuelType fuel_type,TransmissionType transmission_type);
                                                       //paramaterized Constructor
    int vehicleId() const { return _vehicle_id; }

    std::string vehicleName() const { return _vehicle_name; }

    void setVehicleName(const std::string &vehicle_name) { _vehicle_name = vehicle_name; }

    VehicleType type() const { return _type; }
    void setType(const VehicleType &type) { _type = type; }

    float price() const { return _price; }
    void setPrice(float price) { _price = price; }

    int seatCount() const { return _seat_count; }

    std::string brand() const { return _brand; }

    FuelType fuelType() const { return _fuel_type; }
    void setFuelType(const FuelType &fuel_type) { _fuel_type = fuel_type; }

    TransmissionType transmissionType() const { return _transmission_type; }
    void setTransmissionType(const TransmissionType &transmission_type) { _transmission_type = transmission_type; }

    friend std::ostream &operator<<(std::ostream &os, const Vehicle &rhs);
  
};

#endif // VEHICLE_H
