#ifndef VEHICLETYPE_H
#define VEHICLETYPE_H

enum class VehicleType{
    TWO_WHEELER,
    THREE_WHEELER,
    FOUR_WHEELER
};

#endif // VEHICLETYPE_H
