#include "PrivateVehicleOwner.h"

std::ostream &operator<<(std::ostream &os, const PrivateVehicleOwner &rhs) {
    os << static_cast<const RegisteredOwners &>(rhs)
       << " _aadhar_card_number: " << rhs._aadhar_card_number;
    return os;
}

PrivateVehicleOwner::PrivateVehicleOwner(std::string name, std::string location, Vehicle *vehicle, std::string aadhar_card_number)
    :RegisteredOwners{name,location,vehicle},_aadhar_card_number{aadhar_card_number}
{
}

float PrivateVehicleOwner::PayRegistrationCharges()
{
    
    return (vehicle()->price())*0.1;
}
