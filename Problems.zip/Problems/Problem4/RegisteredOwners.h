#ifndef REGISTEREDOWNERS_H
#define REGISTEREDOWNERS_H

#include <iostream>
#include "Vehicle.h"

class RegisteredOwners
{
private:
    std::string _name;
    std::string _location;
    Vehicle* _vehicle;
    
    
public:
    RegisteredOwners() = default;                               //default constructor
    RegisteredOwners(const RegisteredOwners&) = delete;                  //copy constructor - not enabled
    RegisteredOwners& operator=(const RegisteredOwners&) = delete;       //copy assignment - not enabled
    RegisteredOwners(RegisteredOwners &&) = default;                      //move constructor - enabled
    RegisteredOwners& operator=( RegisteredOwners&&) = delete;      //move assignment - not enabled
    ~RegisteredOwners() = default;                               //default destructor

    RegisteredOwners( std::string name,std::string location,Vehicle* vehicle);

    virtual float PayRegistrationCharges()=0;

    std::string name() const { return _name; }
    void setName(const std::string &name) { _name = name; }

    std::string location() const { return _location; }
    void setLocation(const std::string &location) { _location = location; }

    Vehicle* vehicle() const { return _vehicle; }

    friend std::ostream &operator<<(std::ostream &os, const RegisteredOwners &rhs);
};

#endif // REGISTEREDOWNERS_H
