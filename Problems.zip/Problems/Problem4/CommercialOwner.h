#ifndef COMMERCIALOWNER_H
#define COMMERCIALOWNER_H

#include "RegisteredOwners.h"
#include "CommercialType.h"
#include <ostream>

class CommercialOwner:public RegisteredOwners
{
private:
    float _gst_numbers;
    CommercialType _commercial_type;

public:
    CommercialOwner() = default;                               //default constructor
    CommercialOwner(const CommercialOwner&) = delete;                  //copy constructor - not enabled
    CommercialOwner& operator=(const CommercialOwner&) = delete;       //copy assignment - not enabled
    CommercialOwner(CommercialOwner &&) = default;                      //move constructor -  enabled
    CommercialOwner& operator=(CommercialOwner&&) = delete;      //move assignment - not enabled
    ~CommercialOwner() = default;                               //default destructor

    CommercialOwner(std::string name, std::string location, Vehicle *vehicle,float gst_numbers,CommercialType commercial_type);  //Paramaterized Constructor

    float gstNumbers() const { return _gst_numbers; }

    CommercialType commercialType() const { return _commercial_type; }
    void setCommercialType(const CommercialType &commercial_type) { _commercial_type = commercial_type; }

    friend std::ostream &operator<<(std::ostream &os, const CommercialOwner &rhs);

    float PayRegistrationCharges();
};

#endif // COMMERCIALOWNER_H
