#ifndef PRIVATEVEHICLEOWNER_H
#define PRIVATEVEHICLEOWNER_H

#include "RegisteredOwners.h"
#include <ostream>

class PrivateVehicleOwner:public RegisteredOwners
{
private:
    std::string _aadhar_card_number;
public:
    PrivateVehicleOwner() = default;                               //default constructor
    PrivateVehicleOwner(const PrivateVehicleOwner&) = delete;                  //copy constructor - not enabled
    PrivateVehicleOwner& operator=(const PrivateVehicleOwner&) = delete;       //copy assignment - not enabled
    PrivateVehicleOwner(PrivateVehicleOwner &&) = default;                      //move constructor -  enabled
    PrivateVehicleOwner& operator=( PrivateVehicleOwner&&) = delete;      //move assignment - not enabled
    ~PrivateVehicleOwner() = default;                               //default destructor

    PrivateVehicleOwner(std::string name,std::string location,Vehicle* vehicle,std::string aadhar_card_number );

    std::string aadharCardNumber() const { return _aadhar_card_number; }

    friend std::ostream &operator<<(std::ostream &os, const PrivateVehicleOwner &rhs);

    float PayRegistrationCharges();
};

#endif // PRIVATEVEHICLEOWNER_H
