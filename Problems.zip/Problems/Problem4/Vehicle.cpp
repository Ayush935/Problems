#include "Vehicle.h"

int Vehicle::id = 100;

std::ostream &operator<<(std::ostream &os, const Vehicle &rhs) {
    os << "_vehicle_id: " << rhs._vehicle_id
       << " _vehicle_name: " << rhs._vehicle_name
       << " _type: " << static_cast<int>(rhs._type)
       << " _price: " << rhs._price
       << " _seat_count: " << rhs._seat_count
       << " _brand: " << rhs._brand
       << " _fuel_type: " << static_cast<int>(rhs._fuel_type)
       << " _transmission_type: " << static_cast<int>(rhs._transmission_type);
    return os;
}

Vehicle::Vehicle(std::string vehicle_name, VehicleType type, float price, int seat_count, std::string brand, FuelType fuel_type, TransmissionType transmission_type)
   : _vehicle_name{vehicle_name},_type{type},_price{price},_seat_count{seat_count},_brand{brand},_fuel_type{fuel_type},_transmission_type{transmission_type},_vehicle_id{id++}
{
}