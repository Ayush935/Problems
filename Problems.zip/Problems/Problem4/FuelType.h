#ifndef FUELTYPE_H
#define FUELTYPE_H

enum class FuelType{
    PETROL,
    DIESEL,
    CNG

};

#endif // FUELTYPE_H
