#include "Functionalities.h"
#include <limits.h>

void CreateObjRegisteredOwner(Container &data)
{
    data.push_back(new PrivateVehicleOwner("Ayush","Pune",new Vehicle("BMW",VehicleType::FOUR_WHEELER,100000.0f,4,"XYZ",FuelType::DIESEL,TransmissionType::MANUAL),"4505 6348 4385"));
    data.push_back(new CommercialOwner("Bob","Bombay",new Vehicle("Bus",VehicleType::FOUR_WHEELER,50000.9f,40,"DNR",FuelType::PETROL,TransmissionType::MANUAL),345.4f,CommercialType::COMMERCIAL));
    data.push_back(new PrivateVehicleOwner("Bobby","Nagpur",new Vehicle("Auto",VehicleType::THREE_WHEELER,40000.0f,4,"STML",FuelType::CNG,TransmissionType::MANUAL),"4505 3448 4385"));
    data.push_back(new CommercialOwner("Jay","Nashik",new Vehicle("Bike",VehicleType::TWO_WHEELER,70000.9f,2,"Honda",FuelType::PETROL,TransmissionType::MANUAL),305.4f,CommercialType::ECONOMIC));
    data.push_back(new PrivateVehicleOwner("Kai","Rajura",new Vehicle("Car",VehicleType::FOUR_WHEELER,1000000.0f,2,"Tesla",FuelType::DIESEL,TransmissionType::AUTOMATIVE),"4505 6349 4385"));
    
}

void findVehicleDetails(const int vehicleID, const Container &data)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }
    for(RegisteredOwners* ptr: data){
        if(ptr && ptr->vehicle()->vehicleId()==vehicleID){
            std::cout<<*ptr<<std::endl;
        }
    }
}

void FindAvgMaxMin(const Container &data)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }
    
    float max = INT_MIN;
    float min = INT_MAX;
    float sum = 0.0f;
    for(RegisteredOwners*ptr : data){
        if(ptr){
          sum +=ptr->vehicle()->price();
          if(max<ptr->vehicle()->price()){
            max = ptr->vehicle()->price();
          }
          if(min>ptr->vehicle()->price()){
            min = ptr->vehicle()->price();
          }
        }
    }
    
    std::cout<<"Maximum Vehicle Price is "<<max<<std::endl;
    std::cout<<"Minimum Vehicle Price is "<<min<<std::endl;
    std::cout<<"Average Vehicle Price is "<<sum/static_cast<float>(data.size())<<std::endl;

}

void findCommercialOwner(CommercialType type, const Container &data)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }
    Container result;
    for(RegisteredOwners*ptr : data){
        if(ptr){
            CommercialOwner* ptr1 = dynamic_cast<CommercialOwner*>(ptr);
            if(ptr1 && ptr1->commercialType()==type){
                std::cout<<*ptr<<std::endl;
            }
        }
    }
}

Container FindLastNinstances(Container &data,int N)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }

    if(N<=0 || N>data.size()){
        throw std::runtime_error("N value is invalid");
    }

    int count = 0;
    Container result;
    for(std::list<RegisteredOwners*>::reverse_iterator itr=data.rbegin();itr!=data.rend();itr++){
        if(*itr){
           result.push_back(*itr);
        }
        count++;
        if(count==N){
            break;
        }
    } 

    return result;
}

void INstancesAboveThresold(Container &data)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }
    for(RegisteredOwners *ptr : data){
        if(ptr && ptr->vehicle()->price()>100000.0f){
            std::cout<<*ptr<<std::endl;
        }
    }
    
}
