#include "Functionalities.h"

int main()
{
    Container data;
    CreateObjRegisteredOwner(data);

    int vehicleID;
    std::cin >> vehicleID;
    findVehicleDetails(vehicleID, data);

    FindAvgMaxMin(data);

    int n;

    bool check = false;
    while (!check)
    {
        try
        {
            std::cin >> n;
            if (n < 0 || n > 1)
            {
                throw std::runtime_error("n value is not valid");
            }
            check = true;
        }
        catch (const std::exception &e)
        {
            std::cerr << e.what() << '\n';
        }
    }

    CommercialType type;
    switch (n)
    {
    case 0:
        type = CommercialType::ECONOMIC;
        break;
    case 1:
        type = CommercialType::COMMERCIAL;
        break;

    default:
        break;
    }
    try
    {
        findCommercialOwner(type, data);

        int N;
        std::cin >> N;
        Container result = FindLastNinstances(data, N);
        for (RegisteredOwners *ptr : result )
        {
            std::cout << *ptr << std::endl;
        }

        INstancesAboveThresold(data);
    }
    catch (const std::exception &e)
    {
        std::cerr << e.what() << '\n';
    }
}