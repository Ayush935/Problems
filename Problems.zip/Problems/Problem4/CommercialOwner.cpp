#include "CommercialOwner.h"

std::ostream &operator<<(std::ostream &os, const CommercialOwner &rhs) {
    os << static_cast<const RegisteredOwners &>(rhs)
       << " _gst_numbers: " << rhs._gst_numbers
       << " _commercial_type: " << static_cast<int>(rhs._commercial_type);
    return os;
}

CommercialOwner::CommercialOwner(std::string name, std::string location, Vehicle *vehicle,float gst_numbers, CommercialType commercial_type)
    : RegisteredOwners{name,location,vehicle},_gst_numbers{gst_numbers},_commercial_type{commercial_type}
{
}

float CommercialOwner::PayRegistrationCharges()
{
    return (vehicle()->price())*0.2;
}