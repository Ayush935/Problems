#include "Functionalities.h"

int main(){
    Container data;
    CreateObjEngine(data);

    try
    {
        int typeNum = InputEngineType();
        EngineType type = EngineType::BALANCED;

        switch (typeNum)
        {
        case 0:
            type=EngineType::TURBOCHARGE;
            break;
        case 1:
            type=EngineType::PERFORMANCE;
            break;
        case 2:
            type=EngineType::BALANCED;
            break;
        
        default:
            break;
        }
        FindDsplayAverageHorsePower(data,type);


        std::vector<std::function<void(Container,int)>> FuncionWrapper{
            DisplayEngineFuelType,
            DisplayEngineTorque
        };

        FuncionWrapper[0];

        short choice = InputChoice();
        
           std::cout<<"Enter the value"<<std::endl;
           int number;
           std::cin>>number;
           Adaptor(
            data,
            FuncionWrapper[choice],
            number
        );
        


        std::cout<<"Enter the Thresold value"<<std::endl;
        float thresold;
        std::cin>>thresold;
        Container result = EngineInstance( data,thresold);
        std::cout<<"Engine Instance thrsold values greater than thresold "<<std::endl;
        for(Engine* ptr:result){
            std::cout<<*ptr<<std::endl;
        }
        
    }
    catch(const std::runtime_error& e)
    {
        std::cerr << e.what() << '\n';
    }

    DeleteObjects(data);

    
}