#include "Functionalities.h"

void CreateObjEngine(Container &data)
{
    data.push_back(new Engine("MH342",EngineType::BALANCED,200.8f,98.5f,EngineFuelType::DIESEL));
    data.push_back(new Engine("MH382",EngineType::PERFORMANCE,100.8f,48.5f,EngineFuelType::PETROL));
    data.push_back(new Engine("MH842",EngineType::TURBOCHARGE,250.8f,108.5f,EngineFuelType::DIESEL));
    
}

void FindDsplayAverageHorsePower(const Container &data, const EngineType type)
{
    if(data.empty()){
        throw std::runtime_error("data is empty");
    }

    for(Engine * ptr: data){
        if(ptr && ptr->engineType()==type){
            std::cout<<*ptr<<std::endl;
        }
    }
}

void DisplayEngineFuelType(const Container &data, const int N)
{
    if(data.empty()){
        throw std::runtime_error("data is empty");
    }

    if(N<0 || N>data.size()){
        throw std::runtime_error("N value is invalid");
    }
    int count{0};
    for(Engine* ptr: data){
        if(ptr){
            std::cout<<static_cast<int>(ptr->engineFuelType())<<std::endl;
            count++;
            if(count==N){
                break;
            }
        }
    }


}

void DisplayEngineTorque(const Container &data, const int EngineTorque)
{
    if(data.empty()){
        throw std::runtime_error("data is empty");
    }
    bool check = true;
    for(Engine* ptr: data){
        if(ptr && ptr->engineTorque()>EngineTorque){
            check=false;
        }
    }
    if(check){
        std::cout<<"All Engines Have Engine Torque below 200"<<std::endl;
    }
    else{
        std::cout<<"All Engines do not  Have Engine Torque below 200"<<std::endl;
    }
}

Container EngineInstance(const Container &data, const float thresold)
{
    if(data.empty()){
        throw std::runtime_error("data is empty");
    }

    if(thresold<0){
        throw std::runtime_error("Thrsold is Invalid");
    }
    Container result;
    for(Engine* ptr: data){
        if(ptr && ptr->engineHorsepower()>thresold){
            result.push_back(ptr);
        }
    }

    return result;
}

void Adaptor(const Container &data, std::function<void(Container, int)> fns, const int number)
{
    if(data.empty()){
        throw std::runtime_error("data is empty");
    }

   
        (fns)(data,number);
    
}

int InputEngineType()
{
    std::cout<<"Enter the Engine Type 0 for TURBOCHARGE,1 for PERFORMANCE,2 for BALANCED";
    int typenum;
    std::cin>>typenum;

    if(typenum<0 || typenum >2){
        throw std::runtime_error("Invalidvalue of typenum");
    }
    return typenum;
}

int InputValueN()
{
    std::cout<<"Enter the value of N";
    int N;
    std::cin>>N;
    return N;
}

short InputChoice()
{   
    short choice{-1};
    std::cout<<"Enter the choice 0 for DisplayEngineFuel, 1 for Displaying ENgine torque less than 200"<<std::endl;
    std::cin>>choice;
    return choice;
}

void DeleteObjects(const Container &data)
{
    for(Engine*ptr: data){
        delete ptr;
    }
}
