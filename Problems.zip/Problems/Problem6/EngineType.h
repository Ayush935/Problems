#ifndef ENGINETYPE_H
#define ENGINETYPE_H

enum class EngineType{
    TURBOCHARGE,
    PERFORMANCE,
    BALANCED
};

#endif // ENGINETYPE_H
