#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <iostream>
#include <functional>
#include <vector>
#include "Engine.h"
using Container = std::vector<Engine*>;

void CreateObjEngine(Container &data);

void FindDsplayAverageHorsePower(const Container&data, const EngineType type);

void DisplayEngineFuelType(const Container& data, const int N);

void DisplayEngineTorque(const Container& data, const int EngineTorque);

bool SameEngineTypeAndEngineFuelType();

Container EngineInstance(const Container& data, const float thresold);

void Adaptor(const Container&data, std::function<void(Container,int)>fns, const int number);

int InputEngineType();

int InputValueN();

short InputChoice();

void DeleteObjects(const Container &data);
/*
 Binding Function
*/

#endif // FUNCTIONALITIES_H
