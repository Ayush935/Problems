#include "Engine.h"
std::ostream &operator<<(std::ostream &os, const Engine &rhs) {
    os << "_id: " << rhs._id
       << " _engine_type: " << static_cast<int>(rhs._engine_type)
       << " _engine_Horsepower: " << rhs._engine_Horsepower
       << " _engine_Torque: " << rhs._engine_Torque
       << " _engine_fuel_type: " << static_cast<int>(rhs._engine_fuel_type);
    return os;
}

Engine::Engine(std::string id, EngineType engine_type, float engine_Horsepower, float engine_Torque, EngineFuelType engine_fuel_type)
    : _id{id}, _engine_type{engine_type}, _engine_Horsepower{engine_Horsepower}, _engine_Torque{engine_Torque},_engine_fuel_type{engine_fuel_type}
{
}