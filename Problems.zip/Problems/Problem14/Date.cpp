#include "Date.h"
std::ostream &operator<<(std::ostream &os, const Date &rhs) {
    os << "_date: " << rhs._date
       << " _month: " << rhs._month
       << " _year: " << rhs._year;
    return os;
}

Date::Date(int date, int month, int year)
    : _date{date},_month{month},_year{year}
{
}