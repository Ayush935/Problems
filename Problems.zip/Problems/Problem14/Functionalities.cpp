#include "Functionalities.h"

void CreateObjProducts(ProductContainer &data, DateContainer &dates)
{
    dates.emplace_back(Date(12, 12, 2001));
    dates.emplace_back(Date(22, 02, 2201));
    dates.emplace_back(Date(02, 11, 2101));

    auto itr = dates.begin();
    if (itr != dates.end())
    {
        data.emplace_back(std::make_shared<Product>("MH123", Category::CLOTHING, 1268.9, "FRESH", *itr++));
    }
    if (itr != dates.end())
    {
        data.emplace_back(std::make_shared<Product>("MH143", Category::ELECTRONIC, 1568.9, "ORIO", *itr++));
    }
    if (itr != dates.end())
    {
        data.emplace_back(std::make_shared<Product>("MH133", Category::FOOD, 1668.9, "FPD", *itr++));
    }
}

Fntype1 AVerageOfAllCategory;
Fntype2 DisplayNBrand;
Fntype3 INstancePriceBelow100;
Fntype3 IsProductSameCategoryAndBrand;
Fntype4 PriceAboveThresold;
//Fntype2 BindFunctionDisplayNBrand;

void MakeLamda(FnCotainer &fn)
{
    AVerageOfAllCategory = [](ProductContainer &data, Category type)
    {
        if (data.empty())
        {
            throw ContainerEmptyDataException("data is empty");
        }

        float sum = 0.0;
        int count = 0;
        for (ProductPointer product : data)
        {
            if (product && product->category() == type)
            {
                count++;
                sum += product->price();
            }
        }

        if (count == 0)
        {
            throw InvalidValueException("Sorry No Category matches found");
        }

        return sum / count;
    };

    DisplayNBrand = [](ProductContainer &data, int N)
    {
        if (data.empty())
        {
            throw ContainerEmptyDataException("data is empty");
        }

        if (N <= 0 || N > data.size())
        {
            throw InvalidValueException("Value is invalid");
        }
        for (ProductPointer product : data)
        {
            if (product)
            {
                std::cout << *product << std::endl;
                N--;
            }
            if (N == 0)
            {
                break;
            }
        }
    };

    INstancePriceBelow100 = [](ProductContainer &data)
    {
        if (data.empty())
        {
            throw ContainerEmptyDataException("data is empty");
        }

        for (ProductPointer product : data)
        {
            if (product && product->price() < 100)
            {
                return false;
            }
        }
        return true;
    };

    IsProductSameCategoryAndBrand = [](ProductContainer &data)
    {
        if (data.empty())
        {
            throw ContainerEmptyDataException("data is empty");
        }
        std::string brand = data.front()->brand();
        Category type = data.front()->category();
        for (ProductPointer product : data)
        {
            if (product && (product->category() != type || product->brand() != brand))
            {
                return false;
            }
        }
        return true;
    };

    PriceAboveThresold = [](ProductContainer &data, int Thresold)
    {
        if (data.empty())
        {
            throw ContainerEmptyDataException("data is empty");
        }
        ProductContainer result;
        for (ProductPointer product : data)
        {
            if (product && product->price() < Thresold)
            {
                result.emplace_back(product);
            }
        }
        return result;
    };

    fn.emplace_back(INstancePriceBelow100);
    fn.emplace_back(IsProductSameCategoryAndBrand);

   /// BindFunctionDisplayNBrand = std::bind(DisplayNBrand,std::placeholders::_1,3);
}

void Adaptor(ProductRef products, FnCotainer &fn)
{
    for (std::function<bool(ProductContainer &)> functions : fn)
    {
        std::cout << functions(products) << std::endl;
    }
}
