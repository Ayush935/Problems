#include <list>
#include "Product.h"
#include <memory>

using ProductPointer = std::shared_ptr<Product>;
using ProductContainer = std::list<ProductPointer>;
using Fntype1 = std::function<float(ProductContainer&,Category type)>;
using Fntype2 = std::function<void(ProductContainer&,int N)>;
using Fntype3 = std::function<bool(ProductContainer&)>;
using Fntype4 = std::function<ProductContainer(ProductContainer&,int Thresold)>;
using FnCotainer = std::list<Fntype3>;
using ProductRef = std::reference_wrapper<ProductContainer>;
using DateContainer = std::list<Date>;
#include "ContainerEmptyDataException.h"
#include "InvalidValueDataException.h"

extern Fntype1 AVerageOfAllCategory;
extern Fntype2 DisplayNBrand;
extern Fntype3 INstancePriceBelow100;
extern Fntype3 IsProductSameCategoryAndBrand;
extern Fntype4 PriceAboveThresold;
// extern Fntype2 BindFunctionDisplayNBrand;

void CreateObjProducts(ProductContainer &data, DateContainer &dates);

void MakeLamda(FnCotainer &fn);

void Adaptor(ProductRef products,FnCotainer& fn);
