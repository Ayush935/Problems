#ifndef CATEGORY_H
#define CATEGORY_H

enum class Category{
    ELECTRONIC,
    CLOTHING,
    FOOD
};

#endif // CATEGORY_H
