#ifndef DATE_H
#define DATE_H
#include <iostream>

class Date
{
private:
    int _date;
    int _month;
    int _year;

public:
    Date(/* args */) = default;
    Date(const Date &) = delete;
    Date(Date &&) = default;
    Date &operator=(const Date &) = delete;
    Date &operator=(Date &&) = delete;
    ~Date() = default;

    Date(int date,int month,int year);

    int date() const { return _date; }

    int month() const { return _month; }

    int year() const { return _year; }

    friend std::ostream &operator<<(std::ostream &os, const Date &rhs);
};

#endif // DATE_H
