#ifndef INVALIDVALUEDATAEXCEPTION_H
#define INVALIDVALUEDATAEXCEPTION_H

#include <stdexcept>
#include <iostream>

class InvalidValueException : std::exception
{
private:
    std::string _msg;
public:
    InvalidValueException(std::string msg) : _msg{msg} {}
    InvalidValueException(/* args */) = delete;
    InvalidValueException(const InvalidValueException &) = delete;
    InvalidValueException(InvalidValueException &&) = delete;
    InvalidValueException &operator=(const InvalidValueException &) = delete;
    InvalidValueException &operator=(InvalidValueException &&) = delete;
    ~InvalidValueException() = default;

    std::string What() const { return _msg; }

    
};

#endif // INVALIDVALUEDATAEXCEPTION_H
