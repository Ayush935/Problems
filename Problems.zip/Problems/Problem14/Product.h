#ifndef PRODUCT_H
#define PRODUCT_H

#include <functional>
#include <iostream>
#include "Category.h"
#include "Date.h"
using DateRef = std::reference_wrapper<Date>;

class Product
{
private:
    std::string _id;
    Category _category;
    float _price;
    std::string _brand;
    DateRef _date;

public:
    Product(/* args */) = default;
    Product(const Product &) = delete;
    Product(Product &&) = default;
    Product &operator=(const Product &) = delete;
    Product &operator=(Product &&) = delete;
    ~Product() = default;

    Product(std::string id,
            Category category,
            float price,
            std::string brand,
            DateRef date);

    std::string id() const { return _id; }

    Category category() const { return _category; }
    void setCategory(const Category &category) { _category = category; }

    float price() const { return _price; }
    void setPrice(float price) { _price = price; }

    std::string brand() const { return _brand; }

    DateRef date() const { return _date; }
    void setDate(const DateRef &date) { _date = date; }

    friend std::ostream &operator<<(std::ostream &os, const Product &rhs);
};

#endif // PRODUCT_H
