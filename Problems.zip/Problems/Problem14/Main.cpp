#include "Functionalities.h"

int main()
{
    ProductContainer data;
    DateContainer dates;
    CreateObjProducts(data, dates);
    ProductRef products(data);

    FnCotainer functions;
    MakeLamda(functions);

    Adaptor(products, functions);

    std::cout << "Average " << AVerageOfAllCategory(data, Category::CLOTHING) << std::endl;
    DisplayNBrand(data, 2);

    for (ProductPointer product : PriceAboveThresold(data, 100))
    {
        std::cout << product << std::endl;
    }

    // auto Bind_function = std::bind(DisplayNBrand, std::ref(data), 3);

    // Bind_function();

   // BindFunctionDisplayNBrand(std::ref(data),3);
}