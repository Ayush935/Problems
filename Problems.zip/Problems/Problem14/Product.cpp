#include "Product.h"
std::ostream &operator<<(std::ostream &os, const Product &rhs) {
    os << "_id: " << rhs._id
       << " _category: " << static_cast<int>(rhs._category)
       << " _price: " << rhs._price
       << " _brand: " << rhs._brand
       << " _date: " << rhs._date.get();
    return os;
}

Product::Product(std::string id, Category category, float price, std::string brand, DateRef date)
    : _id{id},_category{category},_price{price},_brand{brand},_date{date}
{
}