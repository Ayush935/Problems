#ifndef VEHICLEENGINETYPE_H
#define VEHICLEENGINETYPE_H

enum class VehicleEngineType{
      PETROL,
      DIESEL,
      HYBRID
};

#endif // VEHICLEENGINETYPE_H
