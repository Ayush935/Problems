#include "TouristVehicle.h"
std::ostream &operator<<(std::ostream &os, const TouristVehicle &rhs) {
    os << "m_register_number: " << rhs.m_register_number
       << " m_vehicle_price: " << rhs.m_vehicle_price
       << " m_vehicle_type: " << static_cast<int>(rhs.m_vehicle_type)
       << " m_permit: " << rhs.m_permit.get();
    return os;
}

TouristVehicle::TouristVehicle(std::string register_number, float vehicle_price, TouristVehicleType vehicle_type, PermitRef permit)
   : m_register_number{register_number},m_vehicle_price{vehicle_price},m_vehicle_type{vehicle_type},m_permit{permit}
{
}

float TouristVehicle::CalculatePermitRenewableCost()
{
    if(m_vehicle_type==TouristVehicleType::BUS || m_vehicle_type==TouristVehicleType::CAB){
        return 0.15*m_vehicle_price;
    }

    return 0.1*m_vehicle_price;
}
