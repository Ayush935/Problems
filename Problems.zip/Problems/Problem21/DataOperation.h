/*
  Create the following functionalities in the class Operations
    a) CreateObjects member function which creates 2 objects of type PrivateVehicle and 3 objects of type
       PrivateVehicle and at least 3 objects of type TouristVehicle on the heap (managed by smart pointer).
       These objects need to be stored in the same container which is a data member of class Operations (called : m_data)
        The container should be a list container.
    b) A function to return the average _vehicle_price of all TouristVehicle instances from m_data.
    c) A function to return a boolean to indicate whether all instances have a _vehicle_price above 50000.0f (5 lackh)
    d) A function to return a container of PrivateVehicle smart pointer from relavant instances in the m_data container
*/



#ifndef DATAOPERATION_H
#define DATAOPERATION_H

#include "PrivateVehicle.h"
#include "TouristVehicle.h"
#include <variant>
#include <memory>
#include <list>
using PrivateVehiclePtr = std::shared_ptr<PrivateVehicle>;
using TouristVehiclePtr = std::shared_ptr<TouristVehicle>;
using VType = std::variant<PrivateVehiclePtr,TouristVehiclePtr>;
using ContainerPrivateTourist = std::list<VType>;
using ContainerPrivate = std::list<PrivateVehicle>;
using ContainerPrivatePtr = std::list<PrivateVehiclePtr>;
using PermitContainer = std::list<Permit>;
class DataOperation
{
private:
    ContainerPrivateTourist m_data;
    PermitContainer ref;
    
    DataOperation(/* args */) = default;
    DataOperation(const DataOperation &) = delete;
    DataOperation(DataOperation &&) = delete;
    DataOperation &operator=(const DataOperation &) = delete;
    DataOperation &operator=(DataOperation &&) = delete;
    static DataOperation* _only_object;
public:
    
    ~DataOperation() = default;
    static DataOperation* GetInstance();
    void CreateObjects();
    float AverageVehicePrice();
    bool AllVehicleHavePriceAbove50K();
    std::optional<ContainerPrivatePtr> FindPrivetInstances();
};

#endif // DATAOPERATION_H
