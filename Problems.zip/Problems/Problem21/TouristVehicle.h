#ifndef TOURISTVEHICLE_H
#define TOURISTVEHICLE_H

/*
  create a class TouristVehicle with the following attributes
    - _register_number of type string
    - _vehicle_price of type float
    - _vehicle_type which is either CAB, BUS, or OTHER
    - _permit which a refrence wrapper to an instance of type _permit
    - A member function that can calculate permit renewal cost based on the following criteria
        - for CAB and BUS type of vehicle, cost is 15% of _vehicle_price 
        - for OTHER type of vehicles, cost is 10% of _vehicle_price
    -operator << to display the parameter
    -getters and setters for relavant data members
*/

#include <iostream>
#include "TouristVehicleType.h"
#include "Permit.h"
#include <functional>
using PermitRef = std::reference_wrapper<Permit>;
class TouristVehicle
{
private:
    std::string m_register_number;
    float m_vehicle_price;
    TouristVehicleType m_vehicle_type;
    PermitRef m_permit;
public:
    TouristVehicle(/* args */) = default;
    TouristVehicle(const TouristVehicle &) = delete;
    TouristVehicle(TouristVehicle &&) = delete;
    TouristVehicle &operator=(const TouristVehicle &) = delete;
    TouristVehicle &operator=(TouristVehicle &&) = delete;
    ~TouristVehicle() = default;
    
    TouristVehicle(std::string register_number,
    float vehicle_price,
    TouristVehicleType vehicle_type,
    PermitRef permit);
    float CalculatePermitRenewableCost();

    std::string registerNumber() const { return m_register_number; }

    float vehiclePrice() const { return m_vehicle_price; }

    TouristVehicleType vehicleType() const { return m_vehicle_type; }

    PermitRef permit() const { return m_permit; }

    friend std::ostream &operator<<(std::ostream &os, const TouristVehicle &rhs);
};

#endif // TOURISTVEHICLE_H
