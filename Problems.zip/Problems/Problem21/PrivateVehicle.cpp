#include "PrivateVehicle.h"
std::ostream &operator<<(std::ostream &os, const PrivateVehicle &rhs) {
    os << "m_register_number: " << rhs.m_register_number
       << " m_vehicle_price: " << rhs.m_vehicle_price
       << " m_vehicle_engine_type: " << static_cast<int>(rhs.m_vehicle_engine_type);
    return os;
}

PrivateVehicle::PrivateVehicle(std::string register_number, float vehicle_price, VehicleEngineType vehicle_engine_type)
    : m_register_number{register_number},m_vehicle_price{vehicle_price},m_vehicle_engine_type{vehicle_engine_type}
{
}

float PrivateVehicle::CalculateGST()
{
    return 0.05*m_vehicle_price;
}
