#ifndef PERMIT_H
#define PERMIT_H

#include <string>
#include <ostream>

class Permit
{
private:
    std::string m_permit_member;
    unsigned int m_permit_expiry_year;

public:
    Permit(/* args */) = default;
    Permit(const Permit &) = delete;
    Permit(Permit &&) = default;
    Permit &operator=(const Permit &) = delete;
    Permit &operator=(Permit &&) = delete;
    ~Permit() = default;

    Permit(std::string permit_member,
    unsigned int permit_expiry_year);

    std::string permitMember() const { return m_permit_member; }

    unsigned int permitExpiryYear() const { return m_permit_expiry_year; }

    friend std::ostream &operator<<(std::ostream &os, const Permit &rhs);
};

#endif // PERMIT_H
