#ifndef TOURISTVEHICLETYPE_H
#define TOURISTVEHICLETYPE_H

enum class TouristVehicleType{
    CAB, 
    BUS, 
    OTHER
};

#endif // TOURISTVEHICLETYPE_H
