#include "Permit.h"
std::ostream &operator<<(std::ostream &os, const Permit &rhs) {
    os << "m_permit_member: " << rhs.m_permit_member
       << " m_permit_expiry_year: " << rhs.m_permit_expiry_year;
    return os;
}

Permit::Permit(std::string permit_member, unsigned int permit_expiry_year)
   : m_permit_member{permit_member}
{
    if(permit_expiry_year >= 2004 && permit_expiry_year<=2099){
        m_permit_expiry_year=permit_expiry_year;
    }
}