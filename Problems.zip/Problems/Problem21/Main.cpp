#include "DataOperation.h"
#include <future>

int main(){
    DataOperation* ptr = DataOperation::GetInstance();
    PermitContainer ref;
    ptr->CreateObjects();

    std::future<float> average = std::async(&DataOperation::AverageVehicePrice,ptr);

    std::future<bool> flag = std::async(&DataOperation:: AllVehicleHavePriceAbove50K,ptr);

    std::future<std::optional<ContainerPrivatePtr>> container = std::async(&DataOperation::FindPrivetInstances,ptr);
    
    try
    {
        float avg = average.get();
        std::cout<<"Average of all tourist vehicle price "<<avg<<std::endl;

        std::optional<ContainerPrivatePtr> cont = container.get();
        if(cont.has_value()){
            ContainerPrivatePtr privateCont = cont.value();
            std::cout<<"Private Vehicle Containers "<<std::endl;
            for(PrivateVehiclePtr ptr: privateCont){
                std::cout<<*ptr<<std::endl;
            }
        }
        
        if(flag.get()){
            std::cout<<"All Vehilcles have average price above 50k"<<std::endl;
        }
        else{
            std::cout<<"Not All Vehicles have average price above 50k"<<std::endl;
        }

    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    
}