#include "DataOperation.h"

DataOperation *DataOperation::_only_object{nullptr};

DataOperation *DataOperation::GetInstance()
{
    if (_only_object)
    {
        return _only_object;
    }
    else
    {
        _only_object = new DataOperation();
        return _only_object;
    }
}

void DataOperation::CreateObjects()
{

    ref.emplace_back(Permit("123", 2030));
    ref.emplace_back(Permit("124", 2031));
    ref.emplace_back(Permit("125", 2032));
    // Permit p("asdasd",2030);

    auto itr = ref.begin();
    if (itr != ref.end()){
    m_data.push_back(std::make_shared<TouristVehicle>("MH123", 23.94f, TouristVehicleType::BUS, *itr));

    }
    if (itr != ref.end()){
    m_data.push_back(std::make_shared<TouristVehicle>("MH124", 53.94f, TouristVehicleType::CAB, *itr++));

    }
    if (itr != ref.end()){
    m_data.push_back(std::make_shared<TouristVehicle>("MH125", 56.94f, TouristVehicleType::OTHER, *itr++));

    }
    m_data.push_back(std::make_shared<PrivateVehicle>("MH126", 132.87f, VehicleEngineType::DIESEL));
    m_data.emplace_back(std::make_shared<PrivateVehicle>("MH127", 232.87f, VehicleEngineType::HYBRID));
    m_data.emplace_back(std::make_shared<PrivateVehicle>("MH128", 152.87f, VehicleEngineType::PETROL));
}

float DataOperation::AverageVehicePrice()
{
    if(m_data.empty()){
        throw ;
    }
    float sum = 0.0f;
    int count = 0;
    for(VType v: m_data){
        if(std::holds_alternative<TouristVehiclePtr>(v)){
            sum+=std::get<TouristVehiclePtr>(v)->vehiclePrice();
            count++;
        }
    }
    if(count==0){
        throw;
    }

    return sum/static_cast<float>(count);
}

bool DataOperation::AllVehicleHavePriceAbove50K()
{
    if(m_data.empty()){
        throw ;
    }

    float vehiclePrice {0.0f};
    for(VType v: m_data){
        std::visit(
            [&](auto && val){
               vehiclePrice = val->vehiclePrice();
            },v
        );
        if(vehiclePrice<50000){
            return false;
        }
    }

    return true;
}

std::optional<ContainerPrivatePtr> DataOperation::FindPrivetInstances()
{
    if(m_data.empty()){
        throw ;
    }
    ContainerPrivatePtr privateVehicles;
    for(VType v: m_data){
        if(std::holds_alternative<PrivateVehiclePtr>(v)){
            privateVehicles.emplace_back(std::get<PrivateVehiclePtr>(v));
        }
    }

    if(privateVehicles.empty()){
        return std::nullopt;
    }

    return privateVehicles;
}

/*
  calling non-static functions

  1) static assertion error while invoking thread reason
     ---->  parameters passed to the function inside the thread constructor are invalid/
     incorrect/not-in-order/wrong type/not passesd by reference

     Solution/Tip : Always hover above the function name inside the thread/
     ----> forgot to pass address/pointer of an object of the class while invoking non-static member function
     of the class

     nver do answer.get() in cout , it will show error

     Tip CV:
     - all problems single producer, single consumer
*/