/*
 Create a class PrivateVehicle with the following attributes
    -registered_number of type string
    -vehicle_price of type float
    -vehicle_engine_type which is PETROL, DIESEL or HYBRID
    -A member function that can calculate GST cost for vehicle as 5% of the _vehicle_price
    -operator << to display the parameter
    -getters and setters for relavant data members
*/

#ifndef PRIVATEVEHICLE_H
#define PRIVATEVEHICLE_H

#include <iostream>
#include "VehicleEngineType.h"

class PrivateVehicle
{
private:
    std::string m_register_number;
    float m_vehicle_price;
    VehicleEngineType m_vehicle_engine_type;

public:
    PrivateVehicle(/* args */) = default;
    PrivateVehicle(const PrivateVehicle &) = delete;
    PrivateVehicle(PrivateVehicle &&) = delete;
    PrivateVehicle &operator=(const PrivateVehicle &) = delete;
    PrivateVehicle &operator=(PrivateVehicle &&) = delete;
    ~PrivateVehicle() = default;

    PrivateVehicle(std::string register_number,
    float vehicle_price,
    VehicleEngineType vehicle_engine_type);

    float CalculateGST();

    std::string registerNumber() const { return m_register_number; }

    float vehiclePrice() const { return m_vehicle_price; }

    VehicleEngineType vehicleEngineType() const { return m_vehicle_engine_type; }

    friend std::ostream &operator<<(std::ostream &os, const PrivateVehicle &rhs);

    
};


#endif // PRIVATEVEHICLE_H
