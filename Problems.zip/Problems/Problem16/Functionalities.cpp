#include "Functionalities.h"

void CreateStudentCourse(StudentContainer &students, CourseCOntainer &courses)
{
    students.push_back(std::make_shared<Student>("sas",12,Gender::MALE));
    students.push_back(std::make_shared<Student>("saers",14,Gender::MALE));

    courses.push_back(Course(123,"234","sdds",123,{std::make_shared<Student>("saers",14,Gender::MALE),std::make_shared<Student>("sas",12,Gender::MALE)}));
    
    StudentCourseEnrollContainer ep;
    for(Course course : courses ){
        ep.push_back(course);
    }
    
    for(StudentsPtr ptr : students){
        ptr->setCourseRef(ep);
    }
}

FnType1 CreateEnrollment = [](int id,int cid,StudentContainer&sty,CourseCOntainer&cst,EnrollmentContainer&enroll){
   
   for(Course course: cst){
    if(course.id()==cid){
        for(StuPtr stu: course.studentList()){
            if(stu->studentId()==id){
                enroll.push_back(std::make_shared<Enrollment>(123,2334,sty.begin(),cst.begin()));
            }
        }
    }
   }
};
 Fntype2 DeleteStudent = [](int enrollmentId,StudentContainer&data,CourseCOntainer&ctc){
        
    
 };
extern FnType3 DisplayCourse;
extern FnType4 ContainerOfstudent;