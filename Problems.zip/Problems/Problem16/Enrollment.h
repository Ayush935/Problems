#ifndef ENROLLMENT_H
#define ENROLLMENT_H

#include <iostream>
#include "Student.h"
#include <memory>
using StudentPtr = std::shared_ptr<Student>;
using CourseRefEnrollment = std::reference_wrapper<Course>;

class Enrollment
{
private:
    int _enrollment_id;
    std::string _enrollment_date;
    StudentPtr _student;
    CourseRefEnrollment _courses_enrolled;

public:
    Enrollment(/* args */) = default;
    Enrollment(const Enrollment &) = delete;
    Enrollment(Enrollment &&) = delete;
    Enrollment &operator=(const Enrollment &) = delete;
    Enrollment &operator=(Enrollment &&) = delete;
    ~Enrollment() = delete;

    Enrollment(int enrollment_id,
               std::string enrollment_date,
               StudentPtr student,
               CourseRefEnrollment courses_enrolled);

    int enrollmentId() const { return _enrollment_id; }

    std::string enrollmentDate() const { return _enrollment_date; }

    StudentPtr student() const { return _student; }

    CourseRefEnrollment coursesEnrolled() const { return _courses_enrolled; }

    friend std::ostream &operator<<(std::ostream &os, const Enrollment &rhs);
};

#endif // ENROLLMENT_H
