#include "Course.h"
std::ostream &operator<<(std::ostream &os, const Course &rhs) {
    os << "_id: " << rhs._id
       << " _course_name: " << rhs._course_name
       << " _instructor_name: " << rhs._instructor_name
       << " _maximum_cap: " << rhs._maximum_cap
       << " _student_list: " ;

       for(StuPtr stu: rhs._student_list){
             std::cout<<stu<<std::endl;
       }
    return os;
}

Course::Course(int id, std::string course_name, std::string instructor_name, int maximum_cap, Container student_list)
      : _id{id},_course_name{course_name},_instructor_name{instructor_name},_maximum_cap{maximum_cap},_student_list{student_list}
{
}