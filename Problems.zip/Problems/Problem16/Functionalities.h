#include "Student.h"
#include "Course.h"
#include "Enrollment.h"

using StudentsPtr = std::shared_ptr<Student>;
using StudentContainer = std::list<StudentsPtr>;

using CourseCOntainer = std::list<Course>;

using EnrollmentPtr = std::shared_ptr<Enrollment>;
using EnrollmentContainer = std::list<EnrollmentPtr>;

void CreateStudentCourse(StudentContainer& students, CourseCOntainer& courses);

using FnType1 = std::function<void(int id,int cid,StudentContainer&sty,CourseCOntainer&cst,EnrollmentContainer&enroll)>;
using Fntype2 = std::function<void(int enrollmentId,StudentContainer&,CourseCOntainer&)>;
using FnType3 = std::function<void(StudentContainer&,int studentId)>;
using FnType4 = std::function<StudentContainer(StudentContainer&,int courseId)>;

extern FnType1 CreateEnrollment;
extern Fntype2 DeleteStudent;
extern FnType3 DisplayCourse;
extern FnType4 ContainerOfstudent;