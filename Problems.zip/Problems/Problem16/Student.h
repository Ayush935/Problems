#ifndef STUDENT_H
#define STUDENT_H

#include "Gender.h"
#include <iostream>
#include <list>
#include "Course.h"
#include <functional>
using CourseRef = std::reference_wrapper<Course>;
using StudentCourseEnrollContainer = std::list<CourseRef>;

class Student
{
private:
    static int id;
    int _student_id;
    std::string _name;
    unsigned int _age;
    Gender _gender;
    StudentCourseEnrollContainer _course_ref;

public:
    Student(/* args */) = default;
    Student(const Student &) = delete;
    Student(Student &&) = default;
    Student &operator=(const Student &) = delete;
    Student &operator=(Student &&) = delete;
    ~Student() = default;

    Student(
        std::string name,
        unsigned int age,
        Gender gender);

    Student(
        std::string name,
        unsigned int age,
        Gender gender,
        StudentCourseEnrollContainer course_ref);

    int studentId() const { return _student_id; }

    std::string name() const { return _name; }

    std::string name() const { return _name; }
    void setName(const std::string &name) { _name = name; }

    Gender gender() const { return _gender; }

    StudentCourseEnrollContainer courseRef() const { return _course_ref; }

    void setCourseRef(const StudentCourseEnrollContainer &course_ref) { _course_ref = course_ref; }

    friend std::ostream &operator<<(std::ostream &os, const Student &rhs);

        
};

#endif // STUDENT_H
