#include "Student.h"
std::ostream &operator<<(std::ostream &os, const Student &rhs) {
    os << "_student_id: " << rhs._student_id
       << " _name: " << rhs._name
       << " _age: " << rhs._age
       << " _gender: " << static_cast<int>(rhs._gender)
       << " _course_ref: " ;
       for(CourseRef course:  rhs._course_ref){
           std::cout<<course.get()<<std::endl;
       }
    return os;
}

Student::Student(std::string name, unsigned int age, Gender gender)
   : _name{name},_age{age},_gender{gender}
{
}

Student::Student(std::string name, unsigned int age, Gender gender, StudentCourseEnrollContainer course_ref)
   : Student(name,age,gender)
{
    _course_ref = course_ref; 
}
