#include "Enrollment.h"
std::ostream &operator<<(std::ostream &os, const Enrollment &rhs) {
    os << "_enrollment_id: " << rhs._enrollment_id
       << " _enrollment_date: " << rhs._enrollment_date
       << " _student: " << *(rhs._student)
       << " _courses_enrolled: " << rhs._courses_enrolled.get();
    return os;
}

Enrollment::Enrollment(int enrollment_id, std::string enrollment_date, StudentPtr student, CourseRefEnrollment courses_enrolled)
    : _enrollment_id{enrollment_id},_enrollment_date{enrollment_date},_student{student},_courses_enrolled{courses_enrolled}
{
}