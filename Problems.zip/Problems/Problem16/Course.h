#ifndef COURSE_H
#define COURSE_H

#include <iostream>
#include "Student.h"
#include <list>
#include <memory>
using StuPtr = std::shared_ptr<Student>; 
using Container = std::list<StuPtr>;
class Course
{
private:
    int _id;
    std::string _course_name;
    std::string _instructor_name;
    int _maximum_cap;
    Container _student_list;

public:
    Course(/* args */) = default;
    Course(const Course &) = default;
    Course(Course &&) = default;
    Course &operator=(const Course &) = delete;
    Course &operator=(Course &&) = delete;
    ~Course() = default;

    Course(int id,
           std::string course_name,
           std::string instructor_name,
           int maximum_cap,
           Container student_list);

    std::string courseName() const { return _course_name; }

    std::string instructorName() const { return _instructor_name; }

    int id() const { return _id; }

    int maximumCap() const { return _maximum_cap; }

    Container studentList() const { return _student_list; }
    void setStudentList(const Container &student_list) { _student_list = student_list; }

    friend std::ostream &operator<<(std::ostream &os, const Course &rhs);
};

#endif // COURSE_H
