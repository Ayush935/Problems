#include "DataHandler.h"
#include <future>

int main()
{
    DataContainer arr = {1, 2, 3, 4, 5};
    DataHandler *p = DataHandler::GetInstance(arr);
    
    //  p->MapThreadToFunctions();
    // p->JoinThreads();

    // p->ComputerSquare();
    // p->DisplayCube();
    // p->DisplayResult();

    // std::thread t1(&DataHandler::DisplayCube,p);
    // if(t1.joinable()){
    //     t1.join();
    // }
    // std::thread t2(&DataHandler::FilterData,[](int num){return num%4==0;},p);
    // if(t2.joinable()){
    //     t2.join();
    // }

    p->FilterData([](int num){return num%4==0;});

    // std::thread t3(&DataHandler::ComputerSquare,p);
    // if(t3.joinable()){
    //     t3.join();
    // }
    // std::thread t4(&DataHandler::DisplayResult,p);
    // if(t4.joinable()){
    //     t4.join();
    // }
    // std::thread t5(&DataHandler::SumOfEvenNumbers,p);
    // if(t5.joinable()){
    //     t5.join();
    // }
    //  ThreadContainer th;
    // auto itr = th.begin();
    // *itr++ = std::thread (&DataHandler::DisplayCube,p);
    // *itr++ = std::thread (&DataHandler::FilterData,p,[](int num){return num%4==0;});
    // *itr++ = std::thread (&DataHandler::ComputerSquare,p);
    // *itr++ = std::thread (&DataHandler::DisplayResult,p);
    // *itr++ = std::thread (&DataHandler::SumOfEvenNumbers,p);

    //  ThreadContainer1 th;
    // auto itr = th.begin();
    // th[0] = std::thread (&DataHandler::DisplayCube,p);
   
    // th[1] = std::thread (&DataHandler::FilterData,p,[](int num){return num%4==0;});
    // th[2] = std::thread (&DataHandler::ComputerSquare,p);
    // th[3] = std::thread (&DataHandler::DisplayResult,p);
    // th[4] = std::thread (&DataHandler::SumOfEvenNumbers,p);
     
    // for(std::thread &t: th){
    //     if(t.joinable()){
    //         t.join();
    //     }
    // }

    std::future<void> res = std::async(&DataHandler::DisplayCube,p);
    res.wait();
}