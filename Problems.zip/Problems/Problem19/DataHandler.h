#ifndef DATAHANDLER_H
#define DATAHANDLER_H

#include <iostream>
#include <array>
#include <condition_variable>
#include <mutex>
#include <functional>
#include <thread>
#include <list>
#include "ContainerEmptyDataException.h"
using DataContainer = std::array<int,5>;
using ThreadContainer = std::list<std::thread>;
using ThreadContainer1 = std::array<std::thread,5>;


class DataHandler
{
private:
    DataContainer _data;
    DataContainer _result{0};
    std::mutex m1;
    bool flag{false};
    
    std::condition_variable cv;
    DataHandler(/* args */) = default;
    DataHandler(const DataHandler&) = delete;
    DataHandler(DataHandler&&) = delete;
    DataHandler& operator=(const DataHandler&) = delete;
    DataHandler& operator=(DataHandler&&) = delete;
    static DataHandler* _only_object;
public:
    DataHandler(DataContainer data);
    ~DataHandler() = default;
    static DataHandler* GetInstance(DataContainer &data);
    void FilterData(std::function<bool(int)>fns);
    void SumOfEvenNumbers();
    void ComputerSquare();
    void DisplayResult();
    void DisplayCube();
    void MapThreadToFunctions();
    void JoinThreads();
    friend std::ostream &operator<<(std::ostream &os, const DataHandler &rhs);
};

#endif // DATAHANDLER_H
