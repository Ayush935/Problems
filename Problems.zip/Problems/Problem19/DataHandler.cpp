#include "DataHandler.h"

DataHandler* DataHandler::_only_object {nullptr};

std::ostream &operator<<(std::ostream &os, const DataHandler &rhs) {
    os << "_data: " ;
    for(int val: rhs._data){
        os<<val<<" ";
    };
    os  << " _result: ";
    for(int val1: rhs._result){
        os<<val1<<" ";
    };
    return os;
}

DataHandler::DataHandler(DataContainer data)
    : _data{data}
{
}

DataHandler *DataHandler::GetInstance(DataContainer& data)
{
    if(_only_object){
        return _only_object;
    }
    else{
        DataHandler *_only_object = new DataHandler(data);
        return _only_object;
    }
}

void DataHandler::FilterData(std::function<bool(int)> fns)
{
     std::unique_lock<std::mutex>ul(m1);
    if(_data.empty()){
        throw ContainerEmptyDataException("Data is empty");
    }

    for(int val: _data){
        if(fns(val)){
            //std::lock_guard<std::mutex>ul(m1);
            std::cout<<val<<" ";
        }
    }
    std::cout<<std::endl;
}

void DataHandler::SumOfEvenNumbers()
{
     std::unique_lock<std::mutex>ul(m1);
    if(_data.empty()){
        throw ContainerEmptyDataException("Data is empty");
    }

    int sum =0 ;
    for(int val: _data){
        if(val%2==0){
            sum+=val;
        }
    }
    //std::lock_guard<std::mutex>ul(m1);
    std::cout<<"Sum of All even numbes "<<sum<<std::endl;
}

void DataHandler::ComputerSquare()
{
    if(_data.empty()){
        throw ContainerEmptyDataException("Data is empty");
    }

    int count = 0;
    for(int val : _data){
        _result[count] = val*val;
        count++;
    }
    flag = true;
    cv.notify_one();
}

void DataHandler::DisplayResult()
{   
    std::unique_lock<std::mutex>ul(m1);
    cv.wait(ul,[&](){return flag;});
    if(_result.empty()){
        throw ContainerEmptyDataException("Data is empty");
    }
    for(int val: _result){
        std::cout<<val<<" ";
    }
    std::cout<<std::endl;
}

void DataHandler::DisplayCube()
{
    std::unique_lock<std::mutex>ul(m1);
    if(_data.empty()){
        throw ContainerEmptyDataException("Data is empty");
    }
    
    for(int val : _data){
        // std::lock_guard<std::mutex>ul(m1);
        std::cout<<val*val*val<<" ";
    }
    std::cout<<std::endl;
}

// void DataHandler::MapThreadToFunctions()
// {
//     auto itr = th.begin();
//     *itr++ = std::thread([this](){ FilterData([](int val){ return val % 4 == 0; }); });
//     *itr++ = std::thread([this](){ SumOfEvenNumbers(); });
//     *itr++ = std::thread([this](){ ComputerSquare(); });
//     *itr++ = std::thread([this](){ DisplayResult(); });
//     *itr++ = std::thread([this](){ DisplayCube(); });
// }

// void DataHandler::JoinThreads()
// {
//     for(std::thread& t: th){
//         if(t.joinable()){
//             t.join();
//         }
//     }
// }
