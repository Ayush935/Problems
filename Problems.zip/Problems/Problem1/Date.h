#ifndef DATE_H
#define DATE_H

#include <iostream>

class Date
{
private:
    int _date;
    int _month;
    int _year;
public:
    Date() = default;
    Date(const Date&) = delete;
    Date& operator =(const Date&) = delete;
    Date(Date &&)=delete;
    Date& operator =(Date &&) = delete;
    ~Date() = default;

    Date(int date,int month,int year);

    int date() const { return _date; }
    void setDate(int date) { _date = date; }

    int month() const { return _month; }
    void setMonth(int month) { _month = month; }

    int year() const { return _year; }
    void setYear(int year) { _year = year; }

    friend std::ostream &operator<<(std::ostream &os, const Date &rhs);
};

#endif // DATE_H
