#ifndef FUNCTIONALITIES1_H
#define FUNCTIONALITIES1_H

#include <iostream>
#include <list>
#include "Book.h"
#include "LibraryMember.h"
#include "LibraryTransaction.h"

using Container1 = std::list<Book *>;
using Container2 = std::list<LibraryMember *>;
using Container3 = std::list<LibraryTransaction*>;
using Container  = std::list<std::string>;

void CreateBookObj(Container1 &data1);

void CreateLibraryMemberObj(Container2 &data2);

void BorrowBook(int memberID,int isbn, Container1 &data1, Container2 &data2, Container3 &data3);

void ReturnBook(int transactionID,Container1 &data1, Container2 &data2,Container3 &data3);

void DisplayBorrowedBooks(int memberID,Container2 &data2);


#endif // FUNCTIONALITIES1_H
