#include "Book.h"

std::ostream &operator<<(std::ostream &os, const Book &rhs) {
    os << "_title: " << rhs._title
       << " _author: " << rhs._author
       << " _type: " << static_cast<int>(rhs._type)
       << " _ISBN: " << rhs._ISBN
       << " _available: " << rhs._available;
    return os;
}

// std::istream &operator>>(std::istream &is, Book &rhs)
// {   
//     std::cout<<"Enter the title of the book ";
//     is>>rhs._title;
//     std::cout<<"Enter the author of the book ";
//     is>>rhs._author;
//     std::cout<<"Enter the Genre of the book Action - 0 , Fantasy - 1, Fanfic - 2";
//     is>>rhs._title;
//     std::cout<<"Enter the ISBN of the book ";
//     is>>rhs._ISBN;
//     std::cout<<"Enter the availability of the book 0 for not available and 1 is for true";
//     is>>rhs._available;
//     return is;
// }

// std::istream &operator>>(std::istream &is, Book &rhs) {
//     is>>rhs._title;
//     return is;
// }


Book::Book(std::string title, std::string author, Genre type, int ISBN, bool available)
    :_title{title}, _author{author}, _type{type}, _ISBN{ISBN}, _available{available}
{
}