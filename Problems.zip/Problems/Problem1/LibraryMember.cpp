#include "LibraryMember.h"

int LibraryMember:: _numbers = 10000;

std::ostream &operator<<(std::ostream &os, const LibraryMember &rhs) {
    os << "_numbers: " << rhs._numbers
       << " _name: " << rhs._name
       << " _address: " << rhs._address
       << " _booksBorrowed: ";
       for(std::string ptr: rhs._booksBorrowed){
        os<<ptr<<" ";
       }
    return os;
}

LibraryMember::LibraryMember(std::string name, std::string address, Container booksBorrowed )
    : _name{name}, _address{address}, _booksBorrowed{booksBorrowed}, _memberID{_numbers++}
{
}