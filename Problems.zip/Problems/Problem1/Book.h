#ifndef BOOK_H
#define BOOK_H

#include <iostream>
#include "Genre.h"

class Book
{
private:
    std::string _title{""};
    std::string _author{""};
    Genre _type;
    int _ISBN{110};
    bool _available{false};
public:
    Book() = default;
    Book(const Book&) = delete;
    Book& operator =(const Book&) = delete;
    Book(Book &&)=delete;
    Book& operator =(Book &&) = delete;
    ~Book() = default;

    Book(std::string title,std::string author,Genre type,int ISBN, bool available);

    std::string title() const { return _title; }

    std::string author() const { return _author; }

    Genre type() const { return _type; }

    int iSBN() const { return _ISBN; }

    bool available() const { return _available; }
    void setAvailable(bool available) { _available = available; }

    void setType(const Genre &type) { _type = type; }

    friend std::istream &operator>>(std::istream &is,  Book &rhs);
    friend std::ostream &operator<<(std::ostream &os, const Book &rhs);

    
};

#endif // BOOK_H
