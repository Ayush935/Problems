#ifndef LIBRARYTRANSACTION_H
#define LIBRARYTRANSACTION_H

#include <iostream>
#include "Date.h"
#include "Book.h"
#include "LibraryMember.h"

class LibraryTransaction
{
private:
    static int idd;
    int _transactionID{100};
    Date *_date;
    Book *_book;
    LibraryMember *_member;

public:
    LibraryTransaction() = default;
    LibraryTransaction(const LibraryTransaction&) = delete;
    LibraryTransaction& operator =(const LibraryTransaction&) = delete;
    LibraryTransaction(LibraryTransaction &&)=delete;
    LibraryTransaction& operator =(LibraryTransaction &&) = delete;
    ~LibraryTransaction() = default;
    
    LibraryTransaction(Date *date,Book *book,  LibraryMember *member);

    
    Date *date() const { return _date; }
    void setDate(Date *date) { _date = date; }

    Book *book() const { return _book; }

    LibraryMember *member() const { return _member; }
    void setMember(LibraryMember *member) { _member = member; }

    int transactionID() const { return _transactionID; }

    friend std::ostream &operator<<(std::ostream &os, const LibraryTransaction &rhs);

};

#endif // LIBRARYTRANSACTION_H
