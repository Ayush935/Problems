#ifndef GENRE_H
#define GENRE_H

enum class Genre{
    Action,
    Fantasy,
    Fanfic
};

#endif // GENRE_H
