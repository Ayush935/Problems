#include "LibraryTransaction.h"

int LibraryTransaction::idd = 100;

std::ostream &operator<<(std::ostream &os, const LibraryTransaction &rhs)
{
    os << "_transactionID: " << rhs._transactionID
       << " _date: " << *(rhs._date)
       << " _book: " << *(rhs._book)
       << " _member: " << *(rhs._member);
    return os;
}

LibraryTransaction::LibraryTransaction( Date *date, Book *book, LibraryMember *member)
    : _transactionID{idd++}, _date{date}, _book{book}, _member{member}
{
}