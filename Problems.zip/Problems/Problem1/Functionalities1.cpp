#include "Functionalities1.h"
#include "LibraryTransaction.h"

void CreateBookObj(Container1 &data1)
{
    data1.push_back(new Book("BTTH", "Xiao Yan", Genre::Fantasy, 123, true));
    data1.push_back(new Book("TODG", "Daoist", Genre::Fantasy, 623, true));
    data1.push_back(new Book("Villain", "Jay", Genre::Fanfic, 163, true));
    data1.push_back(new Book("Apocalypse", "John", Genre::Action, 143, true));
    data1.push_back(new Book("One Piece", "Oda", Genre::Action, 193, true));
}

void CreateLibraryMemberObj(Container2 &data2)
{
    data2.push_back(new LibraryMember("Bob", "lane 1", {}));
    data2.push_back(new LibraryMember("Bobby", "lane 2", {}));
    data2.push_back(new LibraryMember("Boss", "lane 3", {}));
}

void BorrowBook(int memberID, int isbn, Container1 &data1, Container2 &data2, Container3 &data3)
{
    if(data1.empty()){
        throw std::runtime_error("Data 1 is empty, there are no books available");
    }
    if(data2.empty()){
        throw std::runtime_error("Data 2 is empty there are no members availabe");
    }
    std::string bookTitle= "";
    for(Book* ptr: data1){
        if(ptr && ptr->iSBN()==isbn && ptr->available()==true){
            std::cout<<"Book is available"<<"\n";
            bookTitle = ptr->title();
            break;
        }
        else{
            throw std::runtime_error("Book is not availabe try again next time");
            
        }

    }
    std::cout<<"\n";
    Container BooksBorrowed;
    std::cout<<"Enter date month and year"<<"\n";
    int date,month,year;
    std::cin>> date >> month >>year;
    
    for(LibraryMember* ptr: data2){
        if(ptr && ptr->_membermemberID()==memberID){
            std::cout<<"You are a member you can borrow the book"<<"\n";
             std::cout<<"\n";
            BooksBorrowed.push_back(bookTitle);
            ptr->setBooksBorrowed(BooksBorrowed);
            for(Book* ptr1: data1){
                if(ptr1 && ptr1->title()==bookTitle){
                    data3.push_back(new LibraryTransaction(new Date(date,month,year),ptr1,ptr));
                    std::cout<<"Transaction generated"<<"\n";
                    ptr1->setAvailable(false);
                }
            
            }
            break;
        }
        else{
            throw std::runtime_error("Sorry you are not a member you cant borrow the book ");
            
        }
    }

    for(LibraryTransaction* ptr:data3 ){
        std::cout<<*ptr<<std::endl;
    }
    std::cout<<"\n";

    
}

void ReturnBook(int transactionID, Container1 &data1, Container2 &data2,Container3 &data3)
{
    if(data1.empty()){
        throw std::runtime_error("Data 1 is empty, there are no books available");
    }
    if(data2.empty()){
        throw std::runtime_error("Data 2 is empty there are no members availabe");
    }
    if(data3.empty()){
        throw std::runtime_error("Data 3 is empty there are no transactions availabe");
    }
    
    std::string bookTitle = "";
    for(LibraryTransaction *ptr: data3){
        if(ptr->transactionID()==transactionID){
            bookTitle = ptr->book()->title();
            ptr->book()->setAvailable(true);
            ptr->member()->setBooksBorrowed({});
        }
    }
    data3.pop_back();

    std::cout<<"Thank You Book "<<bookTitle<<"is returned"<<std::endl;
    
}

void DisplayBorrowedBooks(int memberID,Container2 &data2)
{
    for(LibraryMember* ptr: data2){
        if(ptr->_membermemberID()==memberID){
            for(std::string ptr1: ptr->booksBorrowed()){
                std::cout<<ptr1<<std::endl;
            }
        }
   
    }
}
