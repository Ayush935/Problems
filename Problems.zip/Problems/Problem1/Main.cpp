#include <iostream>
#include "Functionalities1.h"


int main(){
    Container1 data1;
    CreateBookObj(data1);

    Container2 data2;
    CreateLibraryMemberObj(data2);

    std::cout<<"Enter member ID"<<"\n";
    int memberID;
    std::cin>>memberID;

    std::cout<<"Enter ISBN number"<<"\n";
    int isbn;
    std::cin>>isbn;

    Container3 data3;

    BorrowBook(memberID,isbn,data1,data2,data3);


    std::cout<<"following are borrowed books"<<"\n";
    

    DisplayBorrowedBooks(memberID,data2);

    std::cout<<"Enter Transaction ID"<<"\n";
    int TransactionID;
    std::cin>>TransactionID;

    ReturnBook(TransactionID, data1, data2,data3);


}