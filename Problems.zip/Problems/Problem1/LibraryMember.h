#ifndef LIBRARYMEMBER_H
#define LIBRARYMEMBER_H

#include <iostream>
#include <list>
using Container = std::list<std::string>;

class LibraryMember
{
private:
    static int _numbers;
    int _memberID;
    std::string _name{""};
    std::string _address{""};
    Container _booksBorrowed{0};

public:
    LibraryMember() = default;
    LibraryMember(const LibraryMember&) = delete;
    LibraryMember& operator =(const LibraryMember&) = delete;
    LibraryMember(LibraryMember &&)=delete;
    LibraryMember& operator =(LibraryMember &&) = delete;
    ~LibraryMember() = default;

    LibraryMember(std::string name,std::string address,Container booksBorrowed );

    std::string name() const { return _name; }
    void setName(const std::string &name) { _name = name; }

    std::string address() const { return _address; }
    void setAddress(const std::string &address) { _address = address; }

    int _membermemberID() const { return _memberID; }

    Container booksBorrowed() const { return _booksBorrowed; }
    void setBooksBorrowed(const Container &booksBorrowed) { _booksBorrowed = booksBorrowed; }

    friend std::ostream &operator<<(std::ostream &os, const LibraryMember &rhs);

    
};

#endif // LIBRARYMEMBER_H
