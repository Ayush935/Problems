#ifndef CUSTOMERTYPE_H
#define CUSTOMERTYPE_H

enum class CustomerType{
    REGULAR=1,
    PREMIUM=2,
    VIP=3
};

#endif // CUSTOMERTYPE_H
