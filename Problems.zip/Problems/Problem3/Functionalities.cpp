#include "Functionalities.h"
#include <limits.h>

void CreateObjects(Container &data)
{
    int arr1[5]={10,20,30,40,50};
    data.push_back(new Customer(123,"Ayush",CustomerType::PREMIUM,arr1,100.9f));
    int arr2[5]={10,50,30,40,50};
    data.push_back(new Customer(133,"Bob",CustomerType::REGULAR,arr2,160.9f));
    int arr3[5]={10,60,30,40,50};
    data.push_back(new Customer(323,"Bobby",CustomerType::VIP,arr3,200.9f));
    int arr4[5]={10,70,30,40,50};
    data.push_back(new Customer(13,"Jay",CustomerType::PREMIUM,arr4,150.9f));

}

int CustomerIDMaxTransactions(const Container &data)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }
    int max = 0;
    int sum = 0;
    int CustomerId = 0;
    for(Customer*ptr : data){
        if(ptr){
            sum = 0;
            for(int i=0;i<5;i++){
                sum = sum + ptr->customerTransactionAmount()[i];
            }
            if(max<sum){
                max = sum;
                CustomerId = ptr->customerId();
            }
        }
    }
    return CustomerId;
}

Container FindCustomerTypeMatch(const Container &data, const CustomerType type)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }

    Container result;

    for(Customer* ptr: data){
      // std::cout<<static_cast<int>(ptr->type())<<std::endl;
        if(ptr && ptr->type()==type){
           
            result.push_back(ptr);
        }
    }

    if(result.empty()){
        throw std::runtime_error("Result is empty");
    }

    // if(result.size()<0 || result.size()>data.size()){
    //     throw std::runtime_error("THere are no such customers");
    // }

    return result;
}

Container ScoreCreditsBetween(const Container &data)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }

    Container result;
    for(Customer *ptr : data){
        if(ptr && (ptr->customerScoreCredits()>=100.0f && ptr->customerScoreCredits()<=200.0f)){
            result.push_back(ptr);
        }
    }

    // if(result.empty()){
    //     throw std::runtime_error("THere are no customers who matches with the type");
    // }

    return result;
}

void ScoreCreditsAdd(const Container &data)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }
    
    float lowestScoreCredits = INT_MAX;
    float HighestScoreCredits = INT_MIN;
    for(Customer *ptr : data){
        if(ptr && lowestScoreCredits>ptr->customerScoreCredits()){
            lowestScoreCredits = ptr->customerScoreCredits();
        }
        if(ptr && HighestScoreCredits<ptr->customerScoreCredits()){
            HighestScoreCredits = ptr->customerScoreCredits();
        }
    }
    
    std::cout<<"Addition of highest and lowest CustomerScore Credits "<<lowestScoreCredits+HighestScoreCredits<<std::endl;
}

float AVerageCustomerScoreCredits(const Container &data, const CustomerType type)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }

    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }
    
    int sum = 0;
    for(Customer *ptr:data){
        if(ptr && ptr->type()==type){
            sum = sum + ptr->customerScoreCredits();
        }
    }
    return sum/data.size();
}

void FindCustomerINstance(const Container &data, const CustomerType type)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }

    for(Customer* ptr: data){
         if(ptr && ptr->type()==type){
            std::cout<<*ptr<<std::endl;
        }
    }
}
