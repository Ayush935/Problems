#include "Customer.h"

std::ostream &operator<<(std::ostream &os, const Customer &rhs) {
    os << "_customerId: " << rhs._customerId
       << " _customer_name: " << rhs._customer_name
       << " _type: " << static_cast<int>(rhs._type)
       << " _customer_transaction_amount: " ;
       for(int i=0;i<5;i++){
        os<<rhs._customer_transaction_amount[i]<<" ";
       }
    os   << " _customer_score_credits: " << rhs._customer_score_credits;
    return os;
}

Customer::Customer(int customerId, std::string customer_name, CustomerType type, int customer_transaction_amount[5], float customer_score_credits)
    : _customerId{customerId},_customer_name{customer_name},_customer_score_credits{customer_score_credits},_type{type}
{
    for(int i=0;i<5;i++){
        _customer_transaction_amount[i] = customer_transaction_amount[i];
    }
}

Customer::Customer(int customerId)
    : _customerId{customerId}
{
}

float Customer::operator+(const Customer &rhs)
{
    Customer temp;
    temp._customer_score_credits = this->customerScoreCredits() + rhs._customer_score_credits;
    return temp._customer_score_credits;
}
