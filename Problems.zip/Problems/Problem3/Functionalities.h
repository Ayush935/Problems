#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <iostream>
#include "Customer.h"
#include <list>
using Container = std::list<Customer*>;

void CreateObjects(Container& data);

int CustomerIDMaxTransactions(const Container &data);

Container FindCustomerTypeMatch(const Container& data,const CustomerType type);

Container ScoreCreditsBetween(const Container& data);

void ScoreCreditsAdd(const Container& data);

float AVerageCustomerScoreCredits(const Container& data, const CustomerType type);

void FindCustomerINstance(const Container& data,const CustomerType type);


#endif // FUNCTIONALITIES_H
