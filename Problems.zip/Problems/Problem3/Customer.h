#ifndef CUSTOMER_H
#define CUSTOMER_H

#include "CustomerType.h"
#include <iostream>

class Customer
{
private:
    int _customerId;
    std::string _customer_name{"Ayush"};
    CustomerType _type{CustomerType::PREMIUM};
    int _customer_transaction_amount[5];
    float _customer_score_credits{0.0f};
public:
    Customer() = default;
    Customer(const Customer&) = default;
    Customer(Customer&&) = delete;
    Customer& operator=(const Customer&) = default;
    Customer& operator=(const Customer&&) = delete;
    explicit Customer(int customerId,std::string customer_name,CustomerType type,int customer_transaction_amount[5],float customer_score_credits);
    explicit Customer(int customerId);
    ~Customer() = default;

    int customerId() const { return _customerId; }

    std::string customerName() const { return _customer_name; }
    void setCustomerName(const std::string &customer_name) { _customer_name = customer_name; }

    CustomerType type() const { return _type; }
    void setType(const CustomerType &type) { _type = type; }

    const int* customerTransactionAmount() const { return _customer_transaction_amount; }

    float customerScoreCredits() const { return _customer_score_credits; }

    friend std::ostream &operator<<(std::ostream &os, const Customer &rhs);

    float operator+(const Customer &);
};
#endif // CUSTOMER_H
