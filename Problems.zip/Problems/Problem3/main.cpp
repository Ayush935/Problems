#include "Functionalities.h"
#include <iostream>

int main()
{
  Container data;
 

  int n;
  bool check = false;
  while (!check)
  {
    try
    {
      std::cin >> n;

      if (n < 1|| n > 3)
      {
        throw std::runtime_error("Invalid value");
      }

      check = true;
    }
    catch (std::runtime_error &ex)
    {
      std::cerr << ex.what() << std::endl;
    }
  }
  CustomerType type;
  switch (n)
  {
  case 1:
    type = CustomerType::REGULAR;
    break;
  case 2:
    type = CustomerType::PREMIUM;
    break;
  case 3:
    type = CustomerType::VIP;
    break;

  default:
    type = CustomerType::PREMIUM;
    
  }

  CreateObjects(data);
  try
  {
    std::cout << "Customer with maximum transactions ";
    std::cout << CustomerIDMaxTransactions(data) << std::endl;

    Container answer;
    std::cout << "Customer matches with the type" << std::endl;
    answer = FindCustomerTypeMatch(data, type);
    for (Customer *ptr : answer)
    {
      std::cout << *ptr << std::endl;
    }

    std::cout << "Customer score credits between 100 and 200" << std::endl;
    answer = ScoreCreditsBetween(data);
    for (Customer *ptr : answer)
    {
      std::cout << *ptr << std::endl;
    }

    std::cout << "Average of score credits of customers" << std::endl;
    std::cout << AVerageCustomerScoreCredits(data, type);

    std::cout << "Customer matches with type" << std::endl;
    FindCustomerINstance(data, type);
  }
  catch (const std::exception &e)
  {
    std::cerr << e.what() << '\n';
  }
}