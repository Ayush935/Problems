#include "Employee.h"
#include "FullTimeEmployee.h"
#include <variant>
#include <list>
#include <future>
using EmployeePtr = std::shared_ptr<Employee>;
using FullTimeEmployeePtr = std::shared_ptr<FullTimeEmployee>;
using VType = std::variant<EmployeePtr,FullTimeEmployeePtr>;
using Container = std::list<VType>;

void CreatObjEmplyoyee(Container &data);

/*
  Display CalculateBonus for all the functions in the container
*/
void DisplayCalculateBonusForAllInstances(const Container &data);

/*
  Function to display whether all the Emplyess in the Contaiuner have salary above 500000
*/
bool EmployeesSalaryAboveGivenSalary(const Container&data);

/*
  Find and Display all the department instances of all full time emplyoees
  - whose grade matches with the given grade
*/
void DisplayDepartments(const Container&data,std::future<Grade>& _grade );

/*
  Return the project name of employees whose ID mathches with given id
*/
std::string FindProjectName(const Container&data, std::future<std::string> &employeeId);

/*
  Delete THe objects in the container
*/
// void DeleteObj(Container &data);
