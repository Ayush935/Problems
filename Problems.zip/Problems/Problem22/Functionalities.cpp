#include "Functionalities.h"

void CreatObjEmplyoyee(Container &data)
{
    data.emplace_back(std::make_shared<Employee>("Aysuh", "213", 23.45f, std::make_shared<Department>("11", 23)));
    data.emplace_back(std::make_shared<Employee>("Aysuh", "213", 23.45f, std::make_shared<Department>("11", 23)));
    data.emplace_back(std::make_shared<Employee>("Aysuh", "213", 23.45f, std::make_shared<Department>("11", 23)));
    data.emplace_back(std::make_shared<FullTimeEmployee>("PX12", "Pune", Grade::A, 23));
    data.emplace_back(std::make_shared<FullTimeEmployee>("PX12", "Pune", Grade::A, 23));
    data.emplace_back(std::make_shared<FullTimeEmployee>("PX12", "Pune", Grade::A, 23));
}

void DisplayCalculateBonusForAllInstances(const Container &data)
{
    if (data.empty())
    {
        throw;
    }

    for (VType v : data)
    {
        std::visit(
            [&](auto &&val)
            {
                val->CalculateBonus();
            },
            v);
    }
}

bool EmployeesSalaryAboveGivenSalary(const Container &data)
{
    if (data.empty())
    {
        throw;
    }
    float lsalary{0.0f};
    for (VType v : data)
    {
        if (std::holds_alternative<EmployeePtr>(v))
        {
            lsalary = std::get<EmployeePtr>(v)->salary();
        }

        if (lsalary < 50000)
        {
            return true;
        }
    }

    return false;
}

void DisplayDepartments(const Container &data,  std::future<Grade>& _grade)
{
    if (data.empty())
    {
        throw;
    }

    DepartmentPtr ptr;

    for (VType v : data)
    {
        if (std::holds_alternative<EmployeePtr>(v))
        {
            ptr = std::get<EmployeePtr>(v)->department();
            std::cout << *ptr << std::endl;
        }
    }
}

std::string FindProjectName(const Container &data, std::future<std::string>& employeeId)
{
    if (data.empty())
    {
        throw;
    }
    
    std::string id;
    std::string name;
    std::string id1 = employeeId.get();
    for (VType v : data)
    {
        if (std::holds_alternative<EmployeePtr>(v))
        {
            id = std::get<EmployeePtr>(v)->id();
            if(id==id1){
                 name = std::get<EmployeePtr>(v)->name();
                 
                 break;
            }
            
        }
    }

    return name;
}
