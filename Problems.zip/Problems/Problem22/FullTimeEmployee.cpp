#include "FullTimeEmployee.h"

FullTimeEmployee::FullTimeEmployee(std::string project_name, std::string employee_location, Grade grade, int bonus_prsent)
      : _project_name{project_name},_employee_location{employee_location},_grade{grade},_bonus_prsent{bonus_prsent}
{
}
std::ostream &operator<<(std::ostream &os, const FullTimeEmployee &rhs) {
    os << "_project_name: " << rhs._project_name
       << " _employee_location: " << rhs._employee_location
       << " _grade: " << static_cast<int>(rhs._grade)
       << " _bonus_prsent: " << rhs._bonus_prsent;
    return os;
}

void FullTimeEmployee::CalculateBonus()
{
    float ans = 20000*0.01;
    std::cout<<"Calculated Bonus"<<ans<<std::endl;
}
