#include "Employee.h"
std::ostream &operator<<(std::ostream &os, const Employee &rhs) {
    os << "_name: " << rhs._name
       << " _id: " << rhs._id
       << " _salary: " << rhs._salary
       << " _department: " << rhs._department;
    return os;
}

Employee::Employee(std::string name, std::string id, float salary, DepartmentPtr department)
    : _name{name},_id{id},_salary{salary},_department{department}
{
}

void Employee::CalculateBonus()
{
    float ans = _salary*0.01;
    std::cout<<"Calculated Bonus"<<ans<<std::endl;
}
