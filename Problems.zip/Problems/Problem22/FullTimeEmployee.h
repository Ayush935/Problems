#ifndef FULLTIMEEMPLOYEE_H
#define FULLTIMEEMPLOYEE_H

#include <iostream>
#include "Grade.h"

class FullTimeEmployee
{
private:
    std::string _project_name;
    std::string _employee_location;
    Grade _grade;
    int _bonus_prsent;

public:
    FullTimeEmployee(/* args */) = default;
    FullTimeEmployee(const FullTimeEmployee &) = delete;
    FullTimeEmployee(FullTimeEmployee &&) = delete;
    FullTimeEmployee &operator=(const FullTimeEmployee &) = delete;
    FullTimeEmployee &operator=(FullTimeEmployee &&) = delete;
    ~FullTimeEmployee() = default;

    FullTimeEmployee(std::string project_name,
                     std::string employee_location,
                     Grade ugrade,
                     int _bonus_prsent);

    std::string projectName() const { return _project_name; }

    std::string employeeLocation() const { return _employee_location; }

    Grade grade() const { return _grade; }

    int bonusPrsent() const { return _bonus_prsent; }

    friend std::ostream &operator<<(std::ostream &os, const FullTimeEmployee &rhs);

    void CalculateBonus();
};

#endif // FULLTIMEEMPLOYEE_H
