#include "Functionalities.h"
#include <future>
#include "ContainerEmptyDataException.h"

int main(){
    Container data;
    CreatObjEmplyoyee(data);

    std::future<void> res1 = std::async(&DisplayCalculateBonusForAllInstances,std::ref(data));
    std::future<bool> check = std::async(&EmployeesSalaryAboveGivenSalary,std::ref(data));

    std::promise<Grade> pr;
    std::future<Grade> ft = pr.get_future();
    std::future<void> res2 = std::async(&DisplayDepartments,std::ref(data),std::ref(ft));

    std::promise<std::string> pr1;
    std::future<std::string> ft1 = pr1.get_future();
    std::future<std::string> res3 = std::async(&FindProjectName,std::ref(data),std::ref(ft1));

    try
    {
        /* code */
        res1.get();

        if(check.get()){
            std::cout<<"All have salary greater than 50k"<<std::endl;
        }
        else{
            std::cout<<"Not all have salary above 50k"<<std::endl;
        }

        pr.set_value(Grade::A);
        res2.get();

        pr1.set_value("213");
        std::string result = res3.get();
        std::cout<<"ANs is "<<result<<std::endl;
    }
    catch(ContainerEmptyException& e)
    {
        std::cerr << e.what() << '\n';
    }
    
}