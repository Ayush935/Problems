#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <iostream>
#include "Department.h"
#include <memory>
using DepartmentPtr = std::shared_ptr<Department>;

class Employee
{
private:
    std::string _name;
    std::string _id;
    float _salary;
    DepartmentPtr _department;

public:
    Employee(/* args */) = default;
    Employee(const Employee &) = delete;
    Employee(Employee &&) = delete;
    Employee &operator=(const Employee &) = delete;
    Employee &operator=(Employee &&) = delete;
    ~Employee() = default;

    Employee(std::string name,
             std::string id,
             float salary,
             DepartmentPtr department);

    std::string name() const { return _name; }

    std::string id() const { return _id; }

    float salary() const { return _salary; }

    DepartmentPtr department() const { return _department; }

    void CalculateBonus();

    friend std::ostream &operator<<(std::ostream &os, const Employee &rhs);
};

#endif // EMPLOYEE_H
