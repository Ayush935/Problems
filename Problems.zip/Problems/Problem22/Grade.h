#ifndef GRADE_H
#define GRADE_H

enum class Grade
{
    A,
    B,
    C
};

#endif // GRADE_H
