#include "Operations.h"
#include <array>
#include <iostream>
#include <functional>

using ThArray = std::array<std::thread,4>;
using FnType = std::function<void()>;
using FnContainer = std::array<FnType,4>;

void MapToThreads(ThArray& array, FnContainer& fns){
    auto itr = fns.begin();
    for(std::thread& th: array){
      th = std::thread((&(*itr++)));
    }
}

void JoinThreads(ThArray& arr){
    for(std::thread& th : arr){
        if(th.joinable()){
            th.join();
        }
    }
}

int main(){
    SmartPointer ptr = Operations::Getinstance();
    ThArray arr;
    FnContainer fns{
       std::bind(&Operations::TakeInput,*ptr),
       std::bind(&Operations::First10NNaturalNumbersSquare,*ptr),
       std::bind(&Operations::First5OddNumbersDivisibleBy3,*ptr),
       std::bind(&Operations::FirstNNaturalNumberSum,*ptr)
        
    };

    MapToThreads(arr,fns);
    JoinThreads(arr);

    ptr->Display(ptr->firstNSum(),1);
    ptr->Display(ptr->squareResults(),10);
}

/*
   start----> GetInstance() -------> array_of_threads
*/