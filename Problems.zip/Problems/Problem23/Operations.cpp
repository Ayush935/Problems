#include "Operations.h"

//ssmartpointer with nullptr
SmartPointer Operations:: m_instance{nullptr};
//[ mptr[nullptr] ]
//<-------shared_ptr------------------>
SmartPointer Operations::Getinstance()
{
    if(m_instance){
        return m_instance;
    }
    else{
        //what happened to the null pointer
        //old pointer was nullptr
        //m_instance = std::shared_ptr<Operations>();//copy assigning a new shared ptr to an old shared ptr
        m_instance.reset(new Operations());
    }
    return m_instance;
}

void Operations::TakeInput()
{
    unsigned int val{0};
    while (val<=0){
        std::cin>>val;
    }
    m_N = val;
    m_flag = true;
    m_cv.notify_one();
}

void Operations::FirstNNaturalNumberSum()
{
    m_first_N_sum = new int(0);
    std::unique_lock<std::mutex>ul(m_mt);
    m_cv.wait(ul, [&](){return m_flag;});

    for(int i=1;i<=m_N;i++){
        *m_first_N_sum+=i;  //uptdating value
    }

}

void Operations::First5OddNumbersDivisibleBy3()
{
    std::size_t counter{0};
    int checker{3};

    while(counter!=5){
        std::cout<<checker<<"\n";
        checker+=6;
        counter++;
    }

    
}

void Operations::First10NNaturalNumbersSquare()
{
    m_square_results = new int[10];
    for(int i=1;i<=10;i++){
        m_square_results[i-1] = i*i;
    }
}

void Operations::Display(const int *ptr, const int size)
{
    if(ptr){
        for(int i=0;i<size;i++){
            std::cout<<ptr[i]<<std::endl;
        }
    }
}

Operations::~Operations()
{
     if(m_first_N_sum){
            delete m_first_N_sum;
        }

        if(m_square_results){
            delete m_square_results;
        }

        delete this;
}
/*

   m_instance
   [nullptr]

   if--------
   m_instance
   [0x999H]        ------- change m_instance here -- reset function is used

   GetInstance

   
*/