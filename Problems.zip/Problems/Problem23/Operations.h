#ifndef OPERATIONS_H
#define OPERATIONS_H

#include <thread>
#include <iostream>
#include <future>
#include <memory>
#include <condition_variable>
#include <mutex>
class Operations;

using SmartPointer = std::shared_ptr<Operations>;

class Operations
{
private:
    /* data */
    static SmartPointer m_instance;
    std::condition_variable m_cv;
    bool m_flag{false};
    unsigned int m_N{0};
    std::mutex m_mt;
    int *m_square_results{nullptr};
    int *m_first_N_sum{nullptr};
    Operations(/* args */) = default;
    Operations(const Operations&) = delete;
    Operations(Operations&&) = delete;
    Operations& operator=(Operations&&) = delete;
    Operations& operator=(const Operations&)= delete;
public:
    static SmartPointer Getinstance();
    void TakeInput();
    void FirstNNaturalNumberSum();//display single value
    void First5OddNumbersDivisibleBy3();
    void First10NNaturalNumbersSquare();//display multiple values
    void Display(const int*ptr, const int size);
    ~Operations() ;

    int *squareResults() const { return m_square_results; }

    int *firstNSum() const { return m_first_N_sum; }
};

#endif // OPERATIONS_H
