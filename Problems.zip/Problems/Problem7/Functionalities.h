#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <iostream>
#include "Room.h"
#include "Guest.h"
#include "Date.h"
#include "Reservation.h"
#include <list>

using Container1 = std::list<Room*>;
using Container2 = std::list<Guest*>;
using Container3 = std::list<Reservation*>;

void CreateObjRoom(Container1 &data1);

void CreateObjGuest(Container2 &data2);

void CreateReservation(const int guestId,const int roomNumber, Date* date1_checkIn, Date* date2_checkOut,const Container1 &data1,const Container2 &data2, Container3 &data3);

void DisplayReservation(const int guestId,const Container3& data3);

void AvailableRooms(const Container1 &data1,const Date* date1_checkIn,const Date* date2_checkOut);

void DeleteObjects(Container1 &data1,Container2 &data2, Container3 &data3);
#endif // FUNCTIONALITIES_H
