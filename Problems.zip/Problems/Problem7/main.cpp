#include "Functionalities.h"

int main(){
    Container1 data1;
    CreateObjRoom(data1);

    Container2 data2;
    CreateObjGuest(data2);

    Container3 data3;

    std::cout<<"Enter the Check in dates "<<std::endl;
    int date,month,year;
    std::cin>>date>>month>>year;

    Date *checkIn = new Date(date,month,year);

    std::cout<<"Enter the Check out dates "<<std::endl;
    int date1,month1,year1;
    std::cin>>date1>>month1>>year1;

    Date *checkOut = new Date(date,month,year);
    
    std::cout<<"Enter the guestId"<<std::endl;
    int guestId;
    std::cin>>guestId;

    std::cout<<"Enter the room number"<<std::endl;
    int roomNumber;
    std::cin>>roomNumber;
    CreateReservation(guestId,roomNumber,checkIn,checkOut,data1,data2 ,data3);

    DisplayReservation( guestId, data3);

    AvailableRooms(data1,checkIn,checkOut);

    DeleteObjects(data1,data2,data3);
}