#ifndef GUEST_H
#define GUEST_H

#include <iostream>

class Guest
{
private:
    static int _id;
    int _guest_id;
    std::string _name;
    unsigned int _guest_number;
    std::string _email_address;

public:
    Guest() = default; 
    Guest(const Guest&) =  delete;
    Guest operator=(const Guest&) = delete;
    Guest(Guest&&) =  delete;
    Guest operator=(Guest&&) = delete;
    ~Guest() = default;

    Guest(std::string name,unsigned int guest_number,std::string email_address);

    int guestId() const { return _guest_id; }

    std::string name() const { return _name; }
    void setName(const std::string &name) { _name = name; }

    unsigned int guestNumber() const { return _guest_number; }
    void setGuestNumber(unsigned int guest_number) { _guest_number = guest_number; }

    std::string emailAddress() const { return _email_address; }

    friend std::ostream &operator<<(std::ostream &os, const Guest &rhs);

    
};

#endif // GUEST_H
