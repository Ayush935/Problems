#include "Functionalities.h"

void CreateObjRoom(Container1 &data1)
{
    data1.push_back(new Room(RoomType::DOUBLE,true,100.05f));
    data1.push_back(new Room(RoomType::SINGLE,true,50.05f));
    data1.push_back(new Room(RoomType::SUITE,true,200.05f));
    data1.push_back(new Room(RoomType::DOUBLE,true,100.05f));
    data1.push_back(new Room(RoomType::SUITE,true,200.05f));
}

void CreateObjGuest(Container2 &data2)
{
    data2.push_back(new Guest("Ayush",436237,"asda@gmail.com"));
    data2.push_back(new Guest("Bob",4362347,"a23da@gmail.com"));
    data2.push_back(new Guest("Bobby",43623237,"adsfsda@gmail.com"));
}

void CreateReservation(const int guestId, const int roomNumber,  Date *date1_checkIn,  Date *date2_checkOut, const Container1 &data1,const Container2 &data2 ,Container3 &data3)
{
    if(data1.empty()){
        throw std::runtime_error("data is empty");
    }

    if(data2.empty()){
        throw std::runtime_error("data is empty");
    }


    Guest* guest;
    for(Guest *ptr: data2){
        if(ptr && ptr->guestId()==guestId){
              guest = ptr;
        }
    }
    for(Room*ptr: data1){
        if(ptr && ptr->roomNumber()==roomNumber&& ptr->available()==true){
            data3.push_back(new Reservation(date1_checkIn,date2_checkOut,ptr,guest));
            ptr->setAvailable(false);
            break;
        }
    }

    
}

void DisplayReservation(const int guestId, const Container3& data3)
{
    if(data3.empty()){
        throw std::runtime_error("data3 is empty");
    }

    for(Reservation* ptr: data3){
        if(ptr && ptr->guest()->guestId()==guestId){
            std::cout<<*ptr<<std::endl;
        }
    }
}

void AvailableRooms(const Container1 &data1, const Date *date1_checkIn, const Date *date2_checkOut)
{
    if(data1.empty()){
        throw std::runtime_error("data is empty");
    }

    for(Room* ptr: data1){
        if(ptr && ptr->available()==true){
            std::cout<<*ptr<<std::endl;
        }
    }
}

void DeleteObjects(Container1 &data1, Container2 &data2, Container3 &data3)
{
    if(data1.empty()){
        throw std::runtime_error("data is empty");
    }

    if(data2.empty()){
        throw std::runtime_error("data is empty");
    }

    if(data3.empty()){
        throw std::runtime_error("data3 is empty");
    }

    for(Reservation* ptr: data3){
        if(ptr){
            delete ptr->checkIn();
            delete ptr->checkOut();
            
        }
        delete ptr;
    }

    for(Room*ptr : data1){
        if(ptr){
            delete ptr;
        }
    }

    for(Guest*ptr : data2){
        if(ptr){
            delete ptr;
        }
    }

}
