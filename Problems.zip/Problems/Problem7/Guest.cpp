#include "Guest.h"

int Guest::_id = 100;

std::ostream &operator<<(std::ostream &os, const Guest &rhs) {
    os << "_guest_id: " << rhs._guest_id
       << " _name: " << rhs._name
       << " _guest_number: " << rhs._guest_number
       << " _email_address: " << rhs._email_address;
    return os;
}

Guest::Guest(std::string name, unsigned int guest_number, std::string email_address)
    : _name{name}, _guest_number{guest_number}, _email_address{email_address},_guest_id{_id++}
{
}