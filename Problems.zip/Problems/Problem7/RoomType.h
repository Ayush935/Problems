#ifndef ROOMTYPE_H
#define ROOMTYPE_H

enum class RoomType{
     SINGLE,
     DOUBLE,
     SUITE
};

#endif // ROOMTYPE_H
