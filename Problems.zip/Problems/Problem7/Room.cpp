#include "Room.h"

int Room::_number = 1;

std::ostream &operator<<(std::ostream &os, const Room &rhs) {
    os << "_room_number: " << rhs._room_number
       << " _room_type: " << static_cast<int>(rhs._room_type)
       << " _available: " << rhs._available
       << " _cost_per_night: " << rhs._cost_per_night;
    return os;
}

Room::Room(RoomType room_type, bool available, float cost_per_night)
    : _room_type{room_type}, _available{available}, _cost_per_night{cost_per_night},_room_number{_number++}
{
}