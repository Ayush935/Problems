#include "Reservation.h"

int Reservation::_id_r = 100;

std::ostream &operator<<(std::ostream &os, const Reservation &rhs) {
    os << "_registration_id: " << rhs._registration_id
       << " _check_in: " << *(rhs._check_in)
       << " _check_out: " << *(rhs._check_out)
       << " _room: " << *(rhs._room)
       << " _guest: " << *(rhs._guest);
    return os;
}

Reservation::Reservation(Date *check_in, Date *check_out, Room *room, Guest *guest)
    : _check_in{check_in}, _check_out{check_out}, _room{room}, _guest{guest},_registration_id{_id_r}
{
}