#ifndef RESERVATION_H
#define RESERVATION_H

#include "Date.h"
#include "Room.h"
#include "Guest.h"
#include <ostream>

class Reservation
{
private:
    static int _id_r;
    int _registration_id;
    Date *_check_in;
    Date *_check_out;
    Room *_room;
    Guest *_guest;

public:
    Reservation() = default; 
    Reservation(const Reservation&) =  delete;
    Reservation operator=(const Reservation&) = delete;
    Reservation(Reservation&&) =  delete;
    Reservation operator=(Reservation&&) = delete;
    ~Reservation() = default;
    
    Reservation(Date *check_in,Date *check_out,Room *room,Guest *guest);

    int registrationId() const { return _registration_id; }

    Date *checkIn() const { return _check_in; }

    Date *checkOut() const { return _check_out; }

    Room *room() const { return _room; }

    Guest *guest() const { return _guest; }

    void setCheckIn(Date *check_in) { _check_in = check_in; }

    void setCheckOut(Date *check_out) { _check_out = check_out; }

    friend std::ostream &operator<<(std::ostream &os, const Reservation &rhs);

    
};

#endif // RESERVATION_H
