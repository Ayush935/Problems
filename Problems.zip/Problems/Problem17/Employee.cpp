#include "Employee.h"

int Employee::id = 100;

Employee::Employee(std::string name, std::string location, int salary, ProjectRef ref)
    : _name{name},_location{location},_salary{salary},_ref{ref},_employee_id{id++}
{
}
std::ostream &operator<<(std::ostream &os, const Employee &rhs) {
    os << "_employee_id: " << rhs._employee_id
       << " _name: " << rhs._name
       << " _location: " << rhs._location
       << " _salary: " << rhs._salary
       << " _ref: " << rhs._ref.get();
    return os;
}
