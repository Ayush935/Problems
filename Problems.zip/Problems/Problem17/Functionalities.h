#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include "Employee.h"
#include "Project.h"
#include <memory>
#include <vector>

using EmployeePtr = std::shared_ptr<Employee>;
using EmployeeContainer = std::vector<EmployeePtr>;
using ProjectContainer = std::vector<Project>;
using ProjectRefContainer = std::vector<ProjectRef>;
void CreateObjectEmployeeProject(EmployeeContainer& employeeData, ProjectContainer& projectData);

void PrintEmployees(const EmployeeContainer& employeeData);

EmployeeContainer SalaryGreaterThan10k(const EmployeeContainer &employeeData);

ProjectRefContainer TypeMatches(const EmployeeContainer &employeeDat);

ProjectContainer MatchesId(const EmployeeContainer &employeeDat);

using Fntype = std::function<EmployeeContainer(const EmployeeContainer&)>;
extern Fntype BindFunction;

#endif // FUNCTIONALITIES_H
