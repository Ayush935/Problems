#include "Functionalities.h"

int main(){
    EmployeeContainer employees;
    ProjectContainer projects;
    CreateObjectEmployeeProject(employees,projects);

    try
    {
        PrintEmployees(employees);

        for(EmployeePtr &employee : SalaryGreaterThan10k(employees)){
            std::cout<<*employee<<std::endl;
        }

        ProjectRefContainer result =  TypeMatches(employees);
        for(ProjectRef ref: result){
            std::cout<<ref.get()<<std::endl;
        }

        ProjectContainer projects = MatchesId(employees);

        for(Project &proj : projects){
            std::cout<<proj<<std::endl;
        }

        Project p(123,ProjectType::AWS);
        FunctionContainer fns {
            &Project::Square,
            &Project::Cube
        };

        Project::Adaptor(p.projectId(),fns,1);
        
        auto BindFun = std::bind(&Project::Adaptor,std::placeholders::_1,std::placeholders::_2,0);
        BindFun(p.projectId(),fns);

        for(EmployeePtr & emp : BindFunction(employees)){
              std::cout<<*emp<<std::endl;
        }
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    
}