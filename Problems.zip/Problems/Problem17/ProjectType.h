#ifndef PROJECTTYPE_H
#define PROJECTTYPE_H

enum class ProjectType{
    ML,
    AWS,
    FULLSTACK
};

#endif // PROJECTTYPE_H
