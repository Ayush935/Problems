#include "Functionalities.h"

void CreateObjectEmployeeProject(EmployeeContainer &employeeData, ProjectContainer &projectData)
{
    projectData.push_back(Project(123,ProjectType::AWS));
    projectData.push_back(Project(124,ProjectType::FULLSTACK));
    projectData.push_back(Project(125,ProjectType::ML));

    employeeData.push_back(std::make_shared<Employee>("Ayush","Pune",3234,projectData[0]));
    employeeData.push_back(std::make_shared<Employee>("Bob","Mumbai",32344,projectData[1]));
    employeeData.push_back(std::make_shared<Employee>("Bobby","Delhi",323344,projectData[2]));
}

void PrintEmployees(const EmployeeContainer &employeeData)
{
    if(employeeData.empty()){
        throw std::runtime_error("data is empty");
    }

    for(const EmployeePtr &employee : employeeData){
        std::cout<<*employee<<std::endl;
    }
}

EmployeeContainer SalaryGreaterThan10k(const EmployeeContainer &employeeData)
{
    if(employeeData.empty()){
        throw std::runtime_error("data is empty");
    }
    
    EmployeeContainer result;
    for(const EmployeePtr &employee : employeeData){
        if(employee && employee->salary()>10000){
            result.push_back(employee);
        }
        
    }

    return result;
}

ProjectRefContainer TypeMatches(const EmployeeContainer &employeeData)
{
    if(employeeData.empty()){
        throw ;
    }
    
    ProjectRefContainer result;
    for(const EmployeePtr &employee : employeeData){
        if(employee && employee->ref().get().type()==ProjectType::AWS){
            result.push_back(employee->ref());
        }
        
    }

    return result;
}

ProjectContainer MatchesId(const EmployeeContainer &employeeData)
{
    if(employeeData.empty()){
        throw ;
    }
    
    ProjectContainer result;
    for(const EmployeePtr &employee : employeeData){
        if(employee && employee->ref().get().type()==ProjectType::AWS){
            result.push_back(employee->ref().get());
        }
        
    }

    return result;
}

Fntype BindFunction = std::bind(SalaryGreaterThan10k,std::placeholders::_1);