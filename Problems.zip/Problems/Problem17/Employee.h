#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <iostream>
#include "Project.h"
#include <functional>
using ProjectRef = std::reference_wrapper<Project>;
class Employee
{
private:
    static int id;
    int _employee_id;
    std::string _name;
    std::string _location;
    int _salary;
    ProjectRef _ref;

public:
    Employee(/* args */) = default;
    Employee(const Employee &) = delete;
    Employee(Employee &&) = delete;
    Employee &operator=(const Employee &) = delete;
    Employee &operator=(Employee &&) = delete;
    ~Employee() = default;
    Employee(std::string name,
             std::string location,
             int salary,
             ProjectRef ref);

    int employeeId() const { return _employee_id; }

    std::string name() const { return _name; }

    std::string location() const { return _location; }

    int salary() const { return _salary; }

    ProjectRef ref() const { return _ref; }

    friend std::ostream &operator<<(std::ostream &os, const Employee &rhs);
};

#endif // EMPLOYEE_H
