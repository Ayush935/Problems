#ifndef PROJECT_H
#define PROJECT_H

#include "ProjectType.h"
#include <iostream>
#include <vector>
#include <functional>
using FunctionContainer = std::vector<std::function<void(int)>>;

class Project
{
private:
    int _project_id;
    ProjectType _type;
public:
    Project(/* args */) = default;
    Project(const Project&) = default;
    Project(Project&&) = default;
    Project& operator=(const Project&)=delete;
    Project& operator=(Project&&) = delete;
    ~Project() = default;

    Project(int project_id,ProjectType type);

    int projectId() const { return _project_id; }

    ProjectType type() const { return _type; }
    void setType(const ProjectType &type) { _type = type; }

    friend std::ostream &operator<<(std::ostream &os, const Project &rhs);

    static void Square(const int &num);
    static void Cube(const int &num);
    static void Adaptor(const int &num, const FunctionContainer &fns,const int &index);
};

#endif // PROJECT_H
