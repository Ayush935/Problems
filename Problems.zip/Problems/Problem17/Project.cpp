#include "Project.h"
std::ostream &operator<<(std::ostream &os, const Project &rhs) {
    std::string val = " ";
    if(rhs._type == ProjectType::AWS){
        val ="AWS";
    }
    else if(rhs._type == ProjectType::FULLSTACK){
        val = "FULLSTACK";
    }
    else if(rhs._type == ProjectType::ML){
        val = "ML";
    }
    os << "_project_id: " << rhs._project_id
       << " _type: " << val;
    return os;
}

Project::Project(int project_id, ProjectType type)
    : _project_id{project_id}, _type{type}
{
}

void Project::Square(const int &num)
{
    std::cout<<" Square is " << num*num<<"\n";
}

void Project::Cube(const int &num)
{
    std::cout<<" Cube is " << num*num*num<<"\n";
}

void Project::Adaptor(const int &num, const FunctionContainer &fns, const int &index)
{
    if(fns.empty()){
        throw;
    }

    fns[index](num);
}
