#include "Branch.h"

Branch::Branch(int BankNo, BranchType type,AccountRef ref)
   : _BankNo{BankNo},_type{type},_ref{ref}
{
}
std::ostream &operator<<(std::ostream &os, const Branch &rhs) {
    std::string val = "";
    if(rhs._type==BranchType::LOCAL){
        val = "LOCAL";
    }
    else if(rhs._type==BranchType::NATIONAL){
        val = "NATIONAL";
    }
    else if(rhs._type==BranchType::STATE){
        val = "State";
    }
    os << "_BankNo: " << rhs._BankNo
       << " _type: " << val
       << " _Account: "<<rhs._ref.get();
    return os;
}
