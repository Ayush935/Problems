#include "Functionalities.h"

void Square(std::vector<int> &datavector)
{
    for(int val: datavector){
        std::cout<<val*val<<" ";
    }
    std::cout<<std::endl;
}

void Cube(std::vector<int> &datavector2)
{
     for(int val: datavector2){
        std::cout<<val*val*val<<" ";
    }
    std::cout<<std::endl;
}

void Adaptor1(std::vector<int> &data, Containerfns& fns)
{
    for(std::function<void(std::vector<int>&)> fn : fns){
        fn(data);
    }

}

void Adaptor2(std::vector<int> &data, std::function<void(std::vector<int> &)> fns)
{
    fns(data);
}

void CreateObjBranchAccount(ContainerBranch &BranchData)
{   
    std::vector<int>s{1,2,3,4,5};
    std::vector<std::string>str{"asacdd","sdddddsscdd","dscdcdd"};
    Account A1(AccounType::JOINT);
    BranchData.push_back(std::make_shared<Branch>(1213,BranchType::NATIONAL,std::ref(A1)));
    //BranchData.push_back(std::make_shared<Branch>(1232,BranchType::LOCAL,std::ref(A1)));
}


FnType FindBranchWithType = [](ContainerBranch &BranchData){
    
    ContainerBranch result;
    for(BranchPtr ptr: BranchData){
        if(ptr && ptr->ref().get().accountType()==AccounType::JOINT){
              result.push_back(ptr);
        }

    }
    return result;
 };

 FnType1 MatchesTypeRefCont = [](ContainerBranch &BranchData){
    RefContainer ref;
    for(BranchPtr ptr: BranchData){
        if(ptr && ptr->ref().get().accountType()==AccounType::JOINT){
              ref.push_back(ptr->ref());
        }

    }

    return ref;
 };

 FnType2 MatchesAccNumCont = [](ContainerBranch &BranchData){
     
     AccountContainer account;
     for(BranchPtr ptr: BranchData){
        account.push_back(ptr->ref().get());
     }

     return account;
 };

 FnType1 BindFunctiomMatchesTypeRefCont = std::bind(MatchesTypeRefCont,std::placeholders::_1);
 FnType3 BindFunctionSquare = std::bind( Square,std::placeholders::_1);