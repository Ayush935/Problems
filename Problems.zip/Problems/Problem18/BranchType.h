#ifndef BRANCHTYPE_H
#define BRANCHTYPE_H

enum class BranchType{
     LOCAL,
     STATE,
     NATIONAL
};

#endif // BRANCHTYPE_H
