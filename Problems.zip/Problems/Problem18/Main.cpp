#include "Functionalities.h"

int main(){
    ContainerBranch data;
    RefContainer ref;
    AccountContainer acc;

    CreateObjBranchAccount(data);
    std::vector<int>s{1,2,3,4,5};
    std::vector<std::string>str{"asacdd","sdddddsscdd","dscdcdd"};
    Account A2(AccounType::JOINT);
    std::cout<<A2<<std::endl;
    std::vector<std::function<void(std::vector<std::string>&)>>fns{
        &Account::FunctionCheckVowels,
        &Account::FunctionFindPostfix,
        &Account::FunctionPrintFirst3andLast3
    };
    Account::Adaptor5(str,fns);
    
    Containerfns fnss{
        &Square,
        &Cube
    };

    Adaptor1(s,fnss);

    Adaptor2(s,BindFunctionSquare);

    // for(BranchPtr ptr: data){
    //     std::cout<<*ptr<<std::endl;
    // }

    // for(BranchPtr ptr: FindBranchWithType(data)){
    //     std::cout<<*ptr<<"\n";
    // }
       
       
    // for(AccountRef re: MatchesTypeRefCont(data)){
    //     std::cout<<re.get()<<"\n";
    // }

    // for(Account &acc: MatchesAccNumCont(data)){
    //     std::cout<<acc<<std::endl;
    // }
    
}