#ifndef ACCOUNT_H
#define ACCOUNT_H

#include "AccountType.h"
#include <vector>
#include <iostream>
#include <functional>
class Account
{
private:
    static int counter;
    int _number;
    AccounType _account_type;
    // std::vector<int> _intvector;
    // std::vector<std::string> _stringvector;

public:
    Account(/* args */) = default;
    Account(const Account &) = default;
    Account(Account &&) = default;
    Account &operator=(const Account &) = delete;
    Account &operator=(Account &&) = delete;
    ~Account() = default;

    Account(
            AccounType account_type);
            // std::vector<int> intvector,
            // std::vector<std::string> stringvector);

    static void FunctionCheckVowels(std::vector<std::string> &stringvector);
    static void FunctionPrintFirst3andLast3(std::vector<std::string> &stringvector);
    static void FunctionGreatestNumber(std::vector<int> &intvector);
    static void FunctionFindPostfix(std::vector<std::string> &stringvector);
    static void Adaptor5(std::vector<std::string>&,std::vector<std::function<void(std::vector<std::string>&)>>);
    int number() const { return _number; }

    AccounType accountType() const { return _account_type; }

    // std::vector<int> intvector() const { return _intvector; }

    // std::vector<std::string> stringvector() const { return _stringvector; }

    friend std::ostream &operator<<(std::ostream &os, const Account &rhs);
};

#endif // ACCOUNT_H
