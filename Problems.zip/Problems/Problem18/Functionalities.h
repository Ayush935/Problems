#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <vector>
#include "Branch.h"
#include <memory>

using BranchPtr = std::shared_ptr<Branch>;
using ContainerBranch = std::vector<BranchPtr>;
using RefContainer = std::vector<AccountRef>;
using AccountContainer = std::vector<Account>;
using FnType = std::function<ContainerBranch(ContainerBranch&)>;
using FnType1 = std::function<RefContainer(ContainerBranch&)>;
using FnType2 = std::function<AccountContainer(ContainerBranch&)>;
using Containerfns = std::vector<std::function<void(std::vector<int>&)>>;
using FnType3 = std::function<void(std::vector<int>&)>;
void Square(std::vector<int>& datavector);
void Cube(std::vector<int>& datavector2);
void Adaptor1(std::vector<int>& data,Containerfns& fns);
void Adaptor2(std::vector<int>& data,std::function<void(std::vector<int>&)> fns);


void CreateObjBranchAccount(ContainerBranch &BranchData);

extern FnType FindBranchWithType;
extern FnType1 MatchesTypeRefCont;
extern FnType2 MatchesAccNumCont;

extern FnType1 BindFunctiomMatchesTypeRefCont;
extern FnType3 BindFunctionSquare;


#endif // FUNCTIONALITIES_H
