#ifndef BRANCH_H
#define BRANCH_H

#include "BranchType.h"
#include <functional>
#include <iostream>
#include "Account.h"
using AccountRef = std::reference_wrapper<Account>;

class Branch
{
private:
    int _BankNo;
    BranchType _type;
    AccountRef _ref;

public:
    Branch(/* args */) = default;
    Branch(const Branch &) = delete;
    Branch(Branch &&) = delete;
    Branch &operator=(const Branch &) = delete;
    Branch &operator=(Branch &&) = delete;
    ~Branch() = default;

    Branch(int BankNo,
           BranchType type,
           AccountRef ref);

    int bankNo() const { return _BankNo; }

    BranchType type() const { return _type; }

    AccountRef ref() const { return _ref; }

    friend std::ostream &operator<<(std::ostream &os, const Branch &rhs);

    
};

#endif // BRANCH_H
