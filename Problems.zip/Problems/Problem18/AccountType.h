#ifndef ACCOUNTTYPE_H
#define ACCOUNTTYPE_H

enum class AccounType{
     JOINT,
     PRIVATE,
     PUBLIC
};

#endif // ACCOUNTTYPE_H
