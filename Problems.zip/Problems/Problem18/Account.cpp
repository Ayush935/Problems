#include "Account.h"

int Account::counter = 100;

Account::Account(AccounType account_type )//std::vector<int> intvector, std::vector<std::string> stringvector
    : _account_type{account_type},_number{counter++} //_intvector{intvector}, _stringvector{stringvector},_number{counter++}
{
}

void Account::FunctionCheckVowels(std::vector<std::string> &stringvector)
{
    for (std::string val : stringvector)
    {
        std::cout << val << " ";
        for (int i = 0; i < val.size(); i++)
        {
            if (val[i] == 'a' || val[i] == 'A')
            {
                std::cout << val[i] << " ";
            }
        }
        std::cout << std::endl;
    };
}

void Account::FunctionPrintFirst3andLast3(std::vector<std::string> &stringvector)
{

    for (std::string val : stringvector)
    {
        std::cout << val.substr(0, 3) << std::endl;
        std::cout << val.substr(val.size() - 3) << std::endl;
        std::cout << std::endl;
    };
}

std::ostream &operator<<(std::ostream &os, const Account &rhs)
{

    std::string val = "";
    if (rhs._account_type == AccounType::JOINT)
    {
        val = "JOINT";
    }
    else if (rhs._account_type == AccounType::PRIVATE)
    {
        val = "PRIVATE";
    }
    else if (rhs._account_type == AccounType::PUBLIC)
    {
        val = "PUBLIC";
    }

    os << "_number: " << rhs._number
       << " _account_type: " << val
       << " _intvector: ";
    // for (int value : rhs._intvector)
    // {
    //     os << value << " ";
    // };

    // os << " _stringvector: ";

    // for (std::string vali : rhs._stringvector)
    // {
    //     os << vali << " ";
    // };
    return os;
}

void Account::FunctionGreatestNumber(std::vector<int> &intvector)
{
    std::cout<<"No"<<std::endl;
}

void Account::FunctionFindPostfix(std::vector<std::string> &stringvector)
{
    for (std::string val : stringvector)
    {
        if ((val[val.size() - 3] == 'c' || val[val.size() - 3] == 'C') &&
            (val[val.size() - 2] == 'D' || val[val.size() - 2] == 'D') &&
            (val[val.size() - 1] == 'D' || val[val.size() - 1] == 'D'))
        {
            std::cout << "yes" << std::endl;
        }
    }
}

void Account::Adaptor5(std::vector<std::string> &str, std::vector<std::function<void(std::vector<std::string> &)>>fns)
{
    for(std::function<void(std::vector<std::string>&)> fn : fns ){
         fn(str);
    }

}
