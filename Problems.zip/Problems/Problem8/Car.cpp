#include "Car.h"
std::ostream &operator<<(std::ostream &os, const Car &rhs) {
    os << static_cast<const Vehicle &>(rhs)
       << " _car_type: " << static_cast<int>(rhs._car_type);
    return os;
}

Car::Car(std::string registration_number, std::string brand, float price, CarType car_type)
    : Vehicle{registration_number,brand,price},_car_type{car_type}
{
}

float Car::CalculateServicingCost()
{
    return price()*0.08;

}

float Car::TaxExemptopAmount()
{
    if(_car_type==CarType::COMMUTE){
        return price()*0.02;
    }
    return price()*0.15;
}
