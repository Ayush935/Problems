#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <iostream>
#include <vector>
#include "Vehicle.h"
#include "Car.h"
#include "bike.h"

using Container = std::vector<Vehicle*>;

void CreateObjects(Container &data);

void PrintCalculateServicingCost(const Container &data);

void PrintTaxExcemptionAmount(const Container&data);

void PrintBrandPrice(const Container &data,const std::string registrationNumber);

void DeleteObj(Container &data);

#endif // FUNCTIONALITIES_H
