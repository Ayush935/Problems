#include "bike.h"
std::ostream &operator<<(std::ostream &os, const bike &rhs) {
    os << static_cast<const Vehicle &>(rhs)
       << " _braking_syztem: " << static_cast<int>(rhs._braking_syztem);
    return os;
}

bike::bike(std::string registration_number, std::string brand, float price, BrakingSystem braking_system)
    : Vehicle(registration_number,brand, price), _braking_syztem{braking_system}
{
}

float bike::CalculateServicingCost()
{
    return (price()*0,25)+(0.08*(price()*0,25));
}