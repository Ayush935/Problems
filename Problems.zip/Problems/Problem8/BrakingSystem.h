#ifndef BRAKINGSYSTEM_H
#define BRAKINGSYSTEM_H

enum class BrakingSystem
{
    ABS,
    TRADITIONAL
};

#endif // BRAKINGSYSTEM_H
