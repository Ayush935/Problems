#include "Functionalities.h"

int main(){

    Container data;

    CreateObjects(data);

    try
    {
        PrintCalculateServicingCost(data);
        
        std::cout<<"Tax Exception about Car Instances"<<std::endl;
        PrintTaxExcemptionAmount(data);
        
        std::cout<<"Enter the registration number for Printing Tax Exemption Amount "<<std::endl;
        std::string registrationNumber;
        std::cin>>registrationNumber;
        PrintBrandPrice(data, registrationNumber);

        DeleteObj(data);


    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    
}