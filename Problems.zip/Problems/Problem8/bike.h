#ifndef BIKE_H
#define BIKE_H

#include "BrakingSystem.h"
#include "Vehicle.h"
#include <ostream>

class bike : public Vehicle
{
private:
    BrakingSystem _braking_syztem;
public:
    bike() = default;
    bike(const bike &) = delete;
    bike operator=(const bike&) = delete;
    bike(bike &&) = delete;
    bike operator=(bike&&) = delete;
    ~bike() = default;

    bike(std::string registration_number,std::string brand,float price,BrakingSystem braking_system);

    float CalculateServicingCost();

    friend std::ostream &operator<<(std::ostream &os, const bike &rhs);

};

#endif // BIKE_H
