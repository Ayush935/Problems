#include "Functionalities.h"

void CreateObjects(Container &data)
{
    data.push_back(new Car("MH123", "Honda", 1000000.89f, CarType::COMMERCIAL));
    data.push_back(new Car("MH1234", "Tesla", 1003400.89f, CarType::COMMUTE));
    data.push_back(new bike("MH234", "Tata", 500040.34f, BrakingSystem::ABS));
    data.push_back(new bike("MH2324", "HERO", 5023040.34f, BrakingSystem::TRADITIONAL));
}

void PrintCalculateServicingCost(const Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("data is empty");
    }

    std::cout << "Servicing Cost for fist instance" << std::endl;
    Car *ptr = dynamic_cast<Car *>(data[0]);
    if (ptr)
    {
        std::cout << ptr->CalculateServicingCost() << std::endl;
    }

    std::cout << "Servicing Cost for Last instance" << std::endl;
    bike *ptr1 = dynamic_cast<bike *>(data[data.size() - 1]);
    if (ptr1)
    {
        std::cout << ptr1->CalculateServicingCost() << std::endl;
    }
}

void PrintTaxExcemptionAmount(const Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("data is empty");
    }
    int count=0;
    for(Vehicle*ptr: data){
        if(ptr){
                count++;
                Car* cptr = dynamic_cast<Car*>(ptr);
                if(cptr){
                    std::cout<<"Tax Exemption Amount for Instance "<<count<<std::endl;
                    std::cout<<cptr->TaxExceptopAmount()<<std::endl;
                }
        }
    }
}

void PrintBrandPrice(const Container &data, const std::string registrationNumber)
{
    if (data.empty())
    {
        throw std::runtime_error("data is empty");
    }
    int count = 0;
    for (Vehicle *ptr : data)
    {
        count++;
        if (ptr && ptr->registrationNumber() == registrationNumber)
        {
            std::cout << "Price of Instance " << count << " ";
            std::cout << ptr->price() << std::endl;

            std::cout << "brand of Instance " << count << " ";
            std::cout << ptr->brand() << std::endl;

            std::cout << std::endl;
        }
    }
}

void DeleteObj(Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("data is empty");
    }

    for (Vehicle *ptr : data)
    {
        if (ptr)
        {
            delete ptr;
        }
    }
}
