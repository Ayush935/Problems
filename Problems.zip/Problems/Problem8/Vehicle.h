#ifndef VEHICLE_H
#define VEHICLE_H

#include <iostream>

class Vehicle
{
private:
std::string _registration_number;
std::string _brand;
float _price;
    
public:
    Vehicle() = default;
    Vehicle(const Vehicle &) = delete;
    Vehicle operator=(const Vehicle&) = delete;
    Vehicle(Vehicle &&) = delete;
    Vehicle operator=(Vehicle&&) = delete;
    ~Vehicle() = default;
    
    Vehicle(std::string registration_number,std::string brand,float price);
    std::string registrationNumber() const { return _registration_number; }

    std::string brand() const { return _brand; }

    float price() const { return _price; }
    void setPrice(float price) { _price = price; }

    friend std::ostream &operator<<(std::ostream &os, const Vehicle &rhs);

    float CalculateServicingCost();

    virtual float TaxExceptopAmount();
};

#endif // VEHICLE_H
