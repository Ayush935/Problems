#ifndef PRIVATEVEHICLE_H
#define PRIVATEVEHICLE_H

#include "PrivateVehicleLicenseCategory.h"
#include <iostream>
#include <unordered_set>
using SetLicense = std::unordered_set<PrivateVehicleLicenseCategory>;

class PrivateVehicle
{
private:
    /* data */
    std::string _vehicle_registration_number;
    std::string _vehicle_brand;
    float _vehicle_price;
    SetLicense _license_category; 
    unsigned int _seat_count;

public:
    PrivateVehicle(/* args */) = default;
    PrivateVehicle(const PrivateVehicle &) = delete;
    PrivateVehicle(PrivateVehicle &&) = delete;
    PrivateVehicle &operator=(PrivateVehicle &&) = delete;
    PrivateVehicle &operator=(const PrivateVehicle &) = delete;
    ~PrivateVehicle() = default;
    PrivateVehicle(std::string _vehicle_registration_number,
    std::string _vehicle_brand,
    float _vehicle_price,
    // PrivateVehicleLicenseCategory _license_category, 
    SetLicense _license_category,
    unsigned int _seat_count);

    std::string vehicleRegistrationNumber() const { return _vehicle_registration_number; }

    std::string vehicleBrand() const { return _vehicle_brand; }

    float vehiclePrice() const { return _vehicle_price; }

    // PrivateVehicleLicenseCategory licenseCategory() const { return _license_category; }

    unsigned int seatCount() const { return _seat_count; }

    friend std::ostream &operator<<(std::ostream &os, const PrivateVehicle &rhs);
};

#endif // PRIVATEVEHICLE_H
