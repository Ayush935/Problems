#include "PrivateVehicle.h"
#include "TransportVehicle.h"
#include <functional>
#include <memory>
#include <numeric>
#include <algorithm>
#include <future>
#include <variant>
#include <list>
#include <unordered_map>
using PrivateVehiclePtr = std::shared_ptr<PrivateVehicle>;
using TransportVehiclePtr = std::shared_ptr<TransportVehicle>;
using VType = std::variant<PrivateVehiclePtr,TransportVehiclePtr>;
using Container = std::list<VType>;
using LicenseContainer = std::list<TransportVehicleLicenseCategory>;
using MapContainer = std::unordered_map<std::string,VType>;

void CreateObjects(MapContainer & data);

std::optional<LicenseContainer> EnumType(const Container& data);

float AveragePrivateVehicle(const Container& data);

void VehiclePriceFirstN(const Container& data,unsigned int N);

bool SameVehicleType(const Container& data);