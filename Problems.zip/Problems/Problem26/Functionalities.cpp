#include "Functionalities.h"

void CreateObjects(MapContainer &data)
{
    // data.emplace_back(std::make_shared<TransportVehicle>("123","bb",123.9f,TransportVehicleLicenseCategory::HMV,123.0f));
    // data.emplace_back(std::make_shared<TransportVehicle>("123","bb",123.9f,TransportVehicleLicenseCategory::HMV,123.0f));
    // data.emplace_back(std::make_shared<PrivateVehicle>("124","233",324.9f,PrivateVehicleLicenseCategory::LEARNING,213));
    // data.emplace_back(std::make_shared<PrivateVehicle>("124","233",324.9f,PrivateVehicleLicenseCategory::LEARNING,213));
    data.emplace(std::make_pair<std::string,VType>(
        "101",
        std::make_shared<PrivateVehicle>("101","12",2132.0f,SetLicense{PrivateVehicleLicenseCategory::LEARNING,PrivateVehicleLicenseCategory::PERMANENT},234)
    ));
}

// std::optional<LicenseContainer> EnumType(const Container &data)
// {
//     if(data.empty()){
//         throw ;
//     }
//     LicenseContainer result;

//     for(const VType& v: data){
//         if(std::holds_alternative<TransportVehiclePtr>(v)){
//             result.push_back(std::get<TransportVehiclePtr>(v)->licenseCategory());
//         }
//     }

//     return result;

// }

// float AveragePrivateVehicle(const Container &data)
// {
//     if(data.empty()){
//         throw ;
//     }

//     // float sum = 0.0f;
//     int count{0};
//     // for(const VType& v: data){
//     //     if(std::holds_alternative<PrivateVehiclePtr>(v)){
//     //         sum += std::get<PrivateVehiclePtr>(v)->vehiclePrice();
//     //         count++;
//     //     }
//     // }

//     float sum = std::accumulate(
//         data.begin(),
//         data.end(),
//         0.0f,
//         [&](float value_upto_current_point, const VType& v){
//             if(std::holds_alternative<PrivateVehiclePtr>(v)){
//             count++;
//             return value_upto_current_point+ std::get<PrivateVehiclePtr>(v)->vehiclePrice();
//            }
//            return value_upto_current_point;
//         }
//     );
    
//     return sum/count;
// }

// void VehiclePriceFirstN(const Container &data,unsigned int N)
// {
//     if(data.empty()){
//         throw ;
//     }
//     //std::list<float> result;

//     // std::copy_if(
//     //     data.begin(),
//     //     data.end(),
//     //     std::inserter(result,result.begin()),
//     //     [](const VType& v){

//     //     }
//     // )
//     int count{0};
//     for(const VType& v: data){
//         if(count<N){
//            std::visit(
//             [](auto && val){
//                 std::cout<<" Price is "<<val->vehiclePrice()<<'\n';
//             },v
        
//         );
//         count++;
//         }
        
//     }



// }

// bool SameVehicleType(const Container &data)
// {
//     // if(data.empty()){
//     //     throw ;
//     // }
    
//     // PrivateVehicleLicenseCategory first;
//     // for(const VType& v: data){
//     //     if(std::holds_alternative<PrivateVehiclePtr>(v)){
//     //         first = std::get<PrivateVehiclePtr>(v)->licenseCategory();
//     //         break;
//     //     }
//     // }
     
//     // bool check = std::all_of(
//     //     data.begin(),
//     //     data.end(),
//     //     [](const VType& v){
//     //         std::visit(
//     //             [&](auto &&val){
//     //                 second=val->licenseCategory();
//     //             },v
//     //         ); 
//     //     }
//     // )

//     return true;
// }
