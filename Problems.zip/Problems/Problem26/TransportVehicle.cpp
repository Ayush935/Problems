#include "TransportVehicle.h"
std::ostream &operator<<(std::ostream &os, const TransportVehicle &rhs) {
    os << "_vehicle_registration_number: " << rhs._vehicle_registration_number
       << " _vehicle_brand: " << rhs._vehicle_brand
       << " _vehicle_price: " << rhs._vehicle_price
       << " _license_category: " << static_cast<int>(rhs._license_category)
       << " _load_carrying_capacity: " << rhs._load_carrying_capacity;
    return os;
}

TransportVehicle::TransportVehicle(std::string _vehicle_registration_number, std::string _vehicle_brand, float _vehicle_price, TransportVehicleLicenseCategory _license_category, float _load_carrying_capacity)
    : _vehicle_registration_number{_vehicle_registration_number},_vehicle_brand{_vehicle_brand},_vehicle_price{_vehicle_price},_license_category{_license_category},_load_carrying_capacity{_load_carrying_capacity}
{
}