#include "PrivateVehicle.h"

PrivateVehicle::PrivateVehicle(std::string _vehicle_registration_number, std::string _vehicle_brand, float _vehicle_price, SetLicense _license_category, unsigned int _seat_count)
    : _vehicle_registration_number{_vehicle_registration_number},_vehicle_brand{_vehicle_brand},_vehicle_price{_vehicle_price},_license_category{_license_category},_seat_count{_seat_count}
{
}
std::ostream &operator<<(std::ostream &os, const PrivateVehicle &rhs) {
    os << "_vehicle_registration_number: " << rhs._vehicle_registration_number
       << " _vehicle_brand: " << rhs._vehicle_brand
       << " _vehicle_price: " << rhs._vehicle_price
    //    << " _license_category: " << static_cast<int>(rhs._license_category)
       << " _seat_count: " << rhs._seat_count;
    return os;
}
