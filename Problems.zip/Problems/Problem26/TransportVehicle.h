#ifndef TRANSPORTVEHICLE_H
#define TRANSPORTVEHICLE_H

#include "TransportVehicleLicenseCategory.h"
#include <iostream>

class TransportVehicle
{
private:
    /* data */
    std::string _vehicle_registration_number;
    std::string _vehicle_brand;
    float _vehicle_price;
    TransportVehicleLicenseCategory _license_category;
    float _load_carrying_capacity;

public:
    TransportVehicle(/* args */) = default;
    TransportVehicle(const TransportVehicle &) = delete;
    TransportVehicle(TransportVehicle &&) = delete;
    TransportVehicle &operator=(TransportVehicle &&) = delete;
    TransportVehicle &operator=(const TransportVehicle &) = delete;
    ~TransportVehicle() = default;

    TransportVehicle(std::string _vehicle_registration_number,
    std::string _vehicle_brand,
    float _vehicle_price,
    TransportVehicleLicenseCategory _license_category,
    float _load_carrying_capacity);

    std::string vehicleRegistrationNumber() const { return _vehicle_registration_number; }

    std::string vehicleBrand() const { return _vehicle_brand; }

    float vehiclePrice() const { return _vehicle_price; }

    TransportVehicleLicenseCategory licenseCategory() const { return _license_category; }

    float loadCarryingCapacity() const { return _load_carrying_capacity; }

    friend std::ostream &operator<<(std::ostream &os, const TransportVehicle &rhs);
};

#endif // TRANSPORTVEHICLE_H
