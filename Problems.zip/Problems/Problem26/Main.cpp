#include "Functionalities.h"

int main(){
    MapContainer data;
    CreateObjects(data);

    for(auto &[k,v]: data){
        std::cout<<k;
        if(std::holds_alternative<PrivateVehiclePtr>(v)){
            std::cout<<*(std::get<PrivateVehiclePtr>(v));
        }
    }

   
}