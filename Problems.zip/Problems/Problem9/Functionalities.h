#include "Animal.h"
#include "Dog.h"
#include "Cat.h"
#include <vector>

using Container = std::vector<Animal*>;

void CreateObjAnimal(Container &animals);

void PrintmakeSound(const Container &animals);

void Display(const Container &animals);

void DestroyObjAnimal(Container &animals);