#include "Cat.h"
std::ostream &operator<<(std::ostream &os, const Cat &rhs) {
    os << static_cast<const Animal &>(rhs)
       << " _breed: " << rhs._breed;
    return os;
}

Cat::Cat(std::string name, unsigned int age, std::string breed)
    : Animal(name,age), _breed{breed}
{
}

void Cat::makeSound()
{
    std::cout<<"Sound of Cat"<<std::endl;
}
