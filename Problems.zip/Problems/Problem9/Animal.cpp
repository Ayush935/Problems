#include "Animal.h"
std::ostream &operator<<(std::ostream &os, const Animal &rhs) {
    os << "_name: " << rhs._name
       << " _age: " << rhs._age;
    return os;
}

Animal::Animal(std::string name, unsigned int age)
    : _name{name}, _age{age}
{
}