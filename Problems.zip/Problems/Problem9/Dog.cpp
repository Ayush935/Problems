#include "Dog.h"
std::ostream &operator<<(std::ostream &os, const Dog &rhs) {
    os << static_cast<const Animal &>(rhs)
       << " _color: " << rhs._color;
    return os;
}

Dog::Dog(std::string name, unsigned int age, std::string color)
    : Animal(name,age), _color{color}
{
}

void Dog::makeSound()
{
    std::cout<<"Sound of Dog"<<std::endl;
}
