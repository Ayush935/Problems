#include "Functionalities.h"
#include "ContainerEmptyDataException.h"
#include "InvalidValueException.h"

void CreateObjAnimal(Container &animals)
{
    animals.push_back(new Dog("Dog1",10,"Black"));
    animals.push_back(new Dog("Dog2",15,"Brown"));
    animals.push_back(new Cat("Cat1",13,"C1"));
    animals.push_back(new Cat("Cat2",14,"C2"));

}

void PrintmakeSound(const Container &animals)
{
    if(animals.empty()){
        throw ContainerEmptyDataException("Animals Container is empty");
    }

    for(Animal* ptr : animals){
        if(ptr){
            ptr->makeSound();
        }
    }
}

void Display(const Container &animals)
{
    if(animals.empty()){
        throw ContainerEmptyDataException("Animals Container is empty");
    }

    for(Animal * ptr: animals){
        if(ptr){
            Dog* Dptr = dynamic_cast<Dog*>(ptr);
            if(Dptr){
                std::cout<<*Dptr<<std::endl;
            }
            Cat* Cptr = dynamic_cast<Cat*>(ptr);
            if(Cptr){
                std::cout<<*Cptr<<std::endl;
            }

        }
    }


}

void DestroyObjAnimal(Container &animals)
{
    if(animals.empty()){
        throw ContainerEmptyDataException("Animals Container is empty");
    }

    for(Animal *ptr: animals){
        if(ptr){
            delete ptr;
        }
    }

    
}
