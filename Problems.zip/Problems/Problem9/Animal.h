#ifndef ANIMAL_H
#define ANIMAL_H

#include <iostream>

class Animal
{
private:
    std::string _name{""};
    unsigned int _age{1};

public:
    Animal(/* args */) = default;
    Animal(const Animal&) = delete;
    Animal &operator=(const Animal&) = delete;
    Animal(Animal&&) = delete;
    Animal &operator=(Animal&&) = delete;
    virtual ~Animal() = default;

    Animal(std::string name,unsigned int age);

    virtual void makeSound() = 0;

    std::string name() const { return _name; }
    void setName(const std::string &name) { _name = name; }

    unsigned int age() const { return _age; }
    void setAge(unsigned int age) { _age = age; }

    friend std::ostream &operator<<(std::ostream &os, const Animal &rhs);
};

#endif // ANIMAL_H
