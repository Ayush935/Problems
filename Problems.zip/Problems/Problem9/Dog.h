#ifndef DOG_H
#define DOG_H

#include "Animal.h"
#include <ostream>

class Dog : public Animal
{
private:
    std::string _color;
public:
    Dog(/* args */) = default;
    Dog(const Dog&) = delete;
    Dog &operator=(const Dog&) = delete;
    Dog(Dog&&) = delete;
    Dog &operator=(Dog&&) = delete;
    ~Dog() = default;

    Dog(std::string name,unsigned int age,std::string color);

    std::string color() const { return _color; }
    void setColor(const std::string &color) { _color = color; }

    void makeSound() override;

    friend std::ostream &operator<<(std::ostream &os, const Dog &rhs);

    
};

#endif // DOG_H
