#include "Functionalities.h"
#include "ContainerEmptyDataException.h"

int main()
{
    Container animals;

    CreateObjAnimal(animals);

    try
    {
        PrintmakeSound(animals);

        Display(animals);

        DestroyObjAnimal(animals);
    }
    catch (ContainerEmptyDataException &e)
    {
        std::cerr << e.msg() << '\n';
    }
}