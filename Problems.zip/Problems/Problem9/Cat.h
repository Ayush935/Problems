#ifndef CAT_H
#define CAT_H

#include "Animal.h"
#include <ostream>

class Cat : public Animal
{
private:
    std::string _breed;
public:
    Cat(/* args */) = default;
    Cat(const Cat&) = delete;
    Cat &operator=(const Cat&) = delete;
    Cat(Cat&&) = delete;
    Cat &operator=(Cat&&) = delete;
    ~Cat() = default;

    Cat(std::string name,unsigned int age,std::string breed);

    void makeSound() override;

    std::string breed() const { return _breed; }
    void setBreed(const std::string &breed) { _breed = breed; }

    friend std::ostream &operator<<(std::ostream &os, const Cat &rhs);
};

#endif // CAT_H
