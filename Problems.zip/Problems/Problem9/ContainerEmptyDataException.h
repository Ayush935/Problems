#ifndef CONTAINEREMPTYDATAEXCEPTION_H
#define CONTAINEREMPTYDATAEXCEPTION_H

#include <stdexcept>
#include <iostream>

class ContainerEmptyDataException : std::exception
{
private:
    std::string _msg;
public:
    ContainerEmptyDataException(/* args */) = default;
    ContainerEmptyDataException(const ContainerEmptyDataException&) = delete;
    ContainerEmptyDataException &operator=(const ContainerEmptyDataException&) = delete;
    ContainerEmptyDataException(ContainerEmptyDataException&&) = delete;
    ContainerEmptyDataException &operator=(ContainerEmptyDataException&&) = default;
    ~ContainerEmptyDataException() = default;

    ContainerEmptyDataException(std::string msg){_msg=msg;};

    std::string msg() const { return _msg; }
};

#endif // CONTAINEREMPTYDATAEXCEPTION_H
