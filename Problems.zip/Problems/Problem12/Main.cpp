#include "Functionalities.h"

int main()
{
    EngineContainer engines;
    CreateObject(engines);

    try
    {
        CreateObject(engines);

        FindDisplayAverageEngineHorsepower(engines, EngineType::BALANCE);

        DisplayNEngineFuelType(engines, 2);

        std::cout << IsEnginesEngineTorqueAbove200(engines);

        std::cout << IsEnginesSameFuelTypeAndEngineType(engines);

        FindAllEnginesHaveEngineHorsePowerAboveThresold(engines, 50);

        Container fn{IsEnginesEngineTorqueAbove200,
                     IsEnginesSameFuelTypeAndEngineType};
        std::cout<<"Adaptor"<<std::endl;
        Adaptor(engines, fn);
        std::cout<<std::endl;
        auto bindFunction = std::bind(&DisplayNEngineFuelType, std::placeholders::_1, 3);
        std::cout<<"Adaptor"<<std::endl;
        bindFunction(engines);
        
    }
    catch (const std::exception &e)
    {
        std::cerr << e.what() << '\n';
    }
}