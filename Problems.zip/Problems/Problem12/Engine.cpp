#include "Engine.h"
std::ostream &operator<<(std::ostream &os, const Engine &rhs) {
    os << "_id: " << rhs._id
       << " _engine_type: " << static_cast<int>(rhs._engine_type)
       << " _engine_horsepower: " << rhs._engine_horsepower
       << " _engine_torque: " << rhs._engine_torque
       << " _engine_fuel_type: " << static_cast<int>(rhs._engine_fuel_type);
    return os;
}

Engine::Engine(std::string id, EngineType engine_type, float engine_horsepower, float engine_torque, EngineFuelType engine_fuel_type)
   : _id{id}, _engine_type{engine_type},_engine_horsepower{engine_horsepower},_engine_torque{engine_torque},_engine_fuel_type{engine_fuel_type}
{
}