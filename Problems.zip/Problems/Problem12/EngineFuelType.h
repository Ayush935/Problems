#ifndef ENGINEFUELTYPE_H
#define ENGINEFUELTYPE_H

enum class EngineFuelType{
    PETROL,
    DIESEL
};

#endif // ENGINEFUELTYPE_H
