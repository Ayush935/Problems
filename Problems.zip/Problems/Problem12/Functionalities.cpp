#include "Functionalities.h"

void CreateObject(EngineContainer &engines)
{
    engines.push_back(std::make_shared<Engine>("MH123",EngineType::BALANCE,123.89f,90.56f,EngineFuelType::DIESEL));
    engines.push_back(std::make_shared<Engine>("MH124",EngineType::PERFORMANCE,153.89f,230.56f,EngineFuelType::PETROL));
    engines.push_back(std::make_shared<Engine>("MH125",EngineType::TURBOCHARGER,163.89f,190.56f,EngineFuelType::DIESEL));
  
}

void FindDisplayAverageEngineHorsepower(const EngineContainer &engines, EngineType type)
{
    if(engines.empty()){
        throw ;//
    }
    
    int count =0;
    for(EnginePointer eng: engines){
        
        if(eng->engineType()==type){
            count++;
            std::cout<<"Engine HorsePower of Engine "<< eng->engineHorsepower()<<std::endl;
        }
    }
}

void DisplayNEngineFuelType(const EngineContainer &engines, unsigned int N)
{
    if(engines.empty()){
        throw ;//
    }

    if(N<0 || N>engines.size()){
        throw; //
    }

    for(EnginePointer eng: engines){
        if(eng){
            N--;
            std::cout<<static_cast<int>(eng->engineFuelType())<<std::endl;
            if (N==0){
                break;
            }
        }
    }
}

bool IsEnginesEngineTorqueAbove200(const EngineContainer &engines)
{
    if(engines.empty()){
        throw ;//
    }

    for(EnginePointer eng: engines){
        if(eng && eng->engineTorque()<200){
            return false;
        }
    }

    return true;
}

bool IsEnginesSameFuelTypeAndEngineType(const EngineContainer &engines)
{
    if(engines.empty()){
        throw ;//
    }

    EngineType type = engines.front()->engineType();
    EngineFuelType type1 = engines.front()->engineFuelType();
    for(EnginePointer eng: engines){
        if(eng && (eng->engineFuelType()!=type1 || eng->engineType()!=type)){
            return false;
        }
    }

    return true;
}

EngineContainer FindAllEnginesHaveEngineHorsePowerAboveThresold(const EngineContainer &engines, float thresold)
{
    if(engines.empty()){
        throw ;//
    }
    
    if(thresold < 0){
        throw;//
    }

    EngineContainer result;
    for(EnginePointer eng : engines){
        if(eng && eng->engineHorsepower()>thresold){
            result.push_back(eng);
        }
    }
    
    return result;
}

void Adaptor(EngineContainer &engines, Container fn)
{
    for(Container:: iterator itr=fn.begin();itr!=fn.end();itr++){
          (*itr)(engines);
    }
}
