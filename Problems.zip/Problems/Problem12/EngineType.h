#ifndef ENGINETYPE_H
#define ENGINETYPE_H

enum class EngineType{
    TURBOCHARGER,
    PERFORMANCE,
    BALANCE

};

#endif // ENGINETYPE_H
