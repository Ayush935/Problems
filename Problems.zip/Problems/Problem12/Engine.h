#ifndef ENGINE_H
#define ENGINE_H

#include <iostream>
#include "EngineType.h"
#include "EngineFuelType.h"

class Engine
{
private:
    std::string _id;
    EngineType _engine_type;
    float _engine_horsepower;
    float _engine_torque;
    EngineFuelType _engine_fuel_type;

public:
    Engine() = delete;
    Engine(const Engine &) = default;
    Engine(Engine &&) = delete;
    Engine &operator=(const Engine &) = delete;
    Engine &operator=(Engine &&) = delete;
    ~Engine() = default;

    Engine(std::string id,
           EngineType engine_type,
           float engine_horsepower,
           float engine_torque,
           EngineFuelType engine_fuel_type);

    std::string id() const { return _id; }

    EngineType engineType() const { return _engine_type; }
    void setEngineType(const EngineType &engine_type) { _engine_type = engine_type; }

    float engineHorsepower() const { return _engine_horsepower; }
    void setEngineHorsepower(float engine_horsepower) { _engine_horsepower = engine_horsepower; }

    float engineTorque() const { return _engine_torque; }

    EngineFuelType engineFuelType() const { return _engine_fuel_type; }
    void setEngineFuelType(const EngineFuelType &engine_fuel_type) { _engine_fuel_type = engine_fuel_type; }

    friend std::ostream &operator<<(std::ostream &os, const Engine &rhs);
};

#endif // ENGINE_H
