#include <list>
#include <memory>
#include "Engine.h"
#include <functional>

using EnginePointer = std::shared_ptr<Engine>;
using EngineContainer = std::list<EnginePointer>;
using Functions = std::function<bool(EngineContainer)>;
using Container = std::list<Functions>;

void CreateObject(EngineContainer& engines);

void FindDisplayAverageEngineHorsepower(const EngineContainer& engines, EngineType type);

void DisplayNEngineFuelType(const EngineContainer& engines, unsigned int N);

bool IsEnginesEngineTorqueAbove200(const EngineContainer& engines);

bool IsEnginesSameFuelTypeAndEngineType(const EngineContainer& engines);

EngineContainer FindAllEnginesHaveEngineHorsePowerAboveThresold(const EngineContainer& engines,float thresold);

void Adaptor(EngineContainer& engines,Container fn);