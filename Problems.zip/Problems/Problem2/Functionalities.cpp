#include "Functionalities.h"

void CreateObjects(Container &data)
{   
    int arr1[5]={100,200,300,400,500};
    data.push_back(new Customer(123,"Ayush",arr1,CustomerType::PREMIUM,19,109.0f));
    int arr2[5]={104,200,300,400,500};
    data.push_back(new Customer(143,"Bob",arr2,CustomerType::REGULAR,39,199.0f));
    int arr3[5]={100,250,300,400,500};
    data.push_back(new Customer(193,"Bobby",arr3,CustomerType::VIP,69,189.8f));
    int arr4[5]={100,200,300,500,500};
    data.push_back(new Customer(133,"Jay",arr4,CustomerType::REGULAR,49,107.0f));

}

int CustomerId(const Container &data)
{   
    
    if(data.empty()){
        throw std::runtime_error("data is empty");
    }
    int sum;
    int max = 0;
    int customerID = 0;
    for(Customer *ptr: data){
        sum=0;
        for(int i=0;i<5;i++){
           sum = sum+ptr->transactionAmount()[i];
        }
        if(max<sum){
            max=sum;
            customerID = ptr->customeId();
        }
    }
    return customerID;
}

Container FindCustomer(const Container &data, const CustomerType type)
{
    if(data.empty()){
        throw std::runtime_error("data is empty");
    }

    Container result;
    for(Customer *ptr: data){
        if(ptr && ptr->type()==type){
            result.push_back(ptr);
        }
    }

    if(result.size()==0){
        throw std::runtime_error("There are no such Customers");
    }

    return Container();
}

Container StoreCredits(const Container &data)
{
    if(data.empty()){
        throw std::runtime_error("data is empty");
    }
    Container result;
    for(Customer *ptr: data){
        if(ptr && ptr->customerScoreCredits()>=100 && ptr->customerScoreCredits()<=200){
            result.push_back(ptr);
        }
    }

    if(result.size()==0){
        throw std::runtime_error("There are no such customers");
    }

    return Container();
}

void CombinedCustomerCredits(const Container &data)
{
    if(data.empty()){
        throw std::runtime_error("data is empty");
    }
    float low=data[0]->customerScoreCredits();
    float high=data[0]->customerScoreCredits();
    for(Customer *ptr:data){
        if(ptr && ptr->customerScoreCredits()<low){
            low = ptr->customerScoreCredits();
        }
        if(ptr && ptr->customerScoreCredits()>high){
            high = ptr->customerScoreCredits();
        }
    }

    std::cout<<"Combine Customer credits for highest and lowest "<< low+high<<std::endl;

}

void CustomerInstance(const Container &data, const CustomerType type)
{
    if(data.empty()){
        throw std::runtime_error("data is empty");
    }
    for(Customer* ptr: data){
        if(ptr && ptr->type()==type){
            std::cout<<*ptr<<std::endl;
        }
    }
}

float AverageOfAge(const Container &data,CustomerType type)
{   
    if(data.empty()){
        throw std::runtime_error("data is empty");
    }
    float sum = 0.0f;
    for(Customer* ptr: data){
        if(ptr && ptr->type()==type)
           sum = sum + ptr->customerAge();
    }
    return static_cast<float>(sum/data.size());
}




