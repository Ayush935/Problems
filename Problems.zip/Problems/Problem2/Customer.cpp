#include "Customer.h"
std::ostream &operator<<(std::ostream &os, const Customer &rhs) {
    os << "_customer_number: " << rhs._customer_name
       << " _customer_Id: " << rhs._customer_id
       << "_transaction_amount";
       for(int i=0;i<5;i++){
        os<<rhs._transaction_amount[i]<<" ";
       }
    os << " age: " << rhs._customer_age
       << " _customer_score_credits: " << rhs._customer_score_credits;
    return os;
}

Customer::Customer(int customer_id,std::string name, int transaction_amount[],CustomerType type, unsigned int customer_age,float customer_score_credits)
    : _customer_id{customer_id},_customer_name{name}, _type{type}, _customer_age{customer_age},_customer_score_credits{customer_score_credits}
{
    for(int i=0;i<5;i++){
        _transaction_amount[i]=transaction_amount[i];
    }
}

Customer::Customer(int customer_id)
     : _customer_id{customer_id}
{
}

void Customer::operator+(Customer& rhs)
{
    Customer temp;
    temp._customer_score_credits = this->customerScoreCredits()+rhs.customerScoreCredits();
    std::cout<<"Sum is as follows "<<temp._customer_score_credits<<std::endl;
}

Customer Customer::operator=(Customer &rhs)
{
    Customer temp;
    temp._customer_id=rhs.customeId();
    temp._customer_age=rhs.customerAge();
    temp._customer_name=rhs.customerName();
    temp._customer_score_credits=rhs.customerScoreCredits();
    for(int i=0;i<5;i++){
        temp._transaction_amount[i]=rhs.transactionAmount()[i];
    }

    return Customer();
}
