#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <iostream>
#include <vector>
#include "Customer.h"

using Container = std::vector<Customer*>;

void CreateObjects(Container& data);

int CustomerId(const Container &data);

Container FindCustomer(const Container &data, const CustomerType type);

Container StoreCredits(const Container& data);

void CombinedCustomerCredits(const Container& data);

float AverageOfAge(const Container &data,const CustomerType type);

void CustomerInstance(const Container& data,const CustomerType type);


#endif // FUNCTIONALITIES_H
