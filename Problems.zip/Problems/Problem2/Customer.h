#ifndef CUSTOMER_H
#define CUSTOMER_H

#include <iostream>
#include "CustomerType.h"

class Customer
{
private:
    int _customer_id;
    std::string _customer_name;
    int _transaction_amount[5];
    CustomerType _type{CustomerType::PREMIUM};
    unsigned int _customer_age{18};
    float _customer_score_credits{0.0f};
    
public:
    Customer()=default;
    Customer(const Customer&) = default;
    Customer& operator=(const Customer&)=delete;
    Customer(const Customer&&)=delete;
    Customer& operator=(Customer &&)=delete;
    ~Customer()=default;
    Customer(int customer_id,std::string customer_name,int _transaction_amount[],CustomerType type,unsigned int customer_age,float customer_score_credits);
    explicit Customer(int customer_id);

    CustomerType type() const { return _type; }
    void setType(const CustomerType &type) { _type = type; }

    float customerScoreCredits() const { return _customer_score_credits; }

    int customeId() const { return _customer_id; }

    unsigned int customerAge() const { return _customer_age; }

    std::string customerName() const { return _customer_name; }
    void setCustomerName(const std::string &customer_name) { _customer_name = customer_name; }
    void setCustomerAge(unsigned int customer_age) { _customer_age = customer_age; }

    friend std::ostream &operator<<(std::ostream &os, const Customer &rhs);
    
    void operator+(Customer&rhs);

    const int *transactionAmount() const { return _transaction_amount; }

    Customer operator=(Customer&rhs);
    
};

#endif // CUSTOMER_H
