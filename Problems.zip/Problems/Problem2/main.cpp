#include "Functionalities.h"

int main()
{
    Container data;
    int n;
    bool check = false;
    while (!check)
    {
        try
        {
            std::cin >> n;
            if (!(n >= 0 && n <= 2))
            {
                throw std::runtime_error("values are incorrect");
            }
            check = true;
        }
        catch (std::runtime_error &e)
        {
            std::cerr << e.what() << std::endl;
        }
    }

    CustomerType type;
    switch (n)
    {
    case 0:
        type = CustomerType::PREMIUM;
        break;
    case 1:
        type = CustomerType::REGULAR;
        break;
    case 2:
        type = CustomerType::VIP;
        break;
    default:
        type = CustomerType::REGULAR;
    }

    CreateObjects(data);

    try
    {
        Container result;
        std::cout << "Customer id is who has the highest total transaction amount " << CustomerId(data) << std::endl;
        std::cout << std::endl;

        result = FindCustomer(data, type);
        std::cout << "Customer who are similar to type" << std::endl;
        for (Customer *ptr : data)
        {
            std::cout << *ptr << std::endl;
        }
        std::cout << std::endl;

        result = StoreCredits(data);
        std::cout << "Customer whose store credits are more than 100 and less than 200" << std::endl;
        for (Customer *ptr : data)
        {
            std::cout << *ptr << std::endl;
        }
        std::cout << std::endl;

        CombinedCustomerCredits(data);
        std::cout << std::endl;

        std::cout << "Average of ages of the given type is ";
        std::cout << AverageOfAge(data, type) << std::endl;
        std::cout << std::endl;

        CustomerInstance(data, type);
    }
    catch (const std::runtime_error &e)
    {
        std::cerr << e.what() << '\n';
    }
}