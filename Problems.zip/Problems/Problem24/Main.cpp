#include "Functionalities.h"

int main()
{

    Container data;
    ThreadContainer thdata;

    CreateObject(data);

    try
    {
        thdata[0] = std::thread(&FindAndDisplayPermitNumberAtN, std::ref(data), 2);
        thdata[1] = std::thread(&AverageSeatCount, std::ref(data), VehicleType::CAB);
        thdata[2] = std::thread(&PrintAllINstancesHaveSmeVehicleTYpe, std::ref(data));

        for (std::thread &th : thdata)
        {
            if (th.joinable())
            {
                th.join();
            }
        }
    }
    catch (const std::exception &e)
    {
        std::cerr << e.what() << '\n';
    }

    // std::thread t1(&FindAndDisplayPermitNumberAtN,std::ref(data),2);
    // if(t1.joinable()){
    //         t1.join();
    //     }
    // std::thread t2(&AverageSeatCount,std::ref(data),VehicleType::CAB);
    // if(t2.joinable()){
    //         t2.join();
    //     }

    // std::thread t3(&PrintAllINstancesHaveSmeVehicleTYpe);

    // if(t3.joinable()){
    //         t3.join();
    //     }
}