#include "Functionalities.h"
std::mutex m1;

void CreateObject(Container &data)
{
    data[0] = std::make_shared<TransportVehicle>(std::make_shared<Permit>("Mh123",123),VehicleType::BUS,23,123);
    data[1] = std::make_shared<TransportVehicle>(std::make_shared<Permit>("Mh124",153),VehicleType::CAB,23,323);
    data[2] = std::make_shared<TransportVehicle>(std::make_shared<Permit>("Mh125",163),VehicleType::MINI_VAN,33,423);
    data[3] = std::make_shared<TransportVehicle>(std::make_shared<Permit>("Mh126",153),VehicleType::BUS,53,143);
}

void FindAndDisplayPermitNumberAtN(const Container &data, unsigned int N)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }
    
    if(N<0||N>data.size()){
        throw std::runtime_error("Invalid value");
    }
    int n=1;
    auto itr = std::find_if(
        data.begin(),
        data.end(),
        [&](const TransportVehiclePtr& ptr){
            if(n==N){
                return true;
            }
            else{
                n++;
                return false;
            }
        }
    );
    std::lock_guard<std::mutex>lk(m1);
    std::cout<<"Display Permit Number at "<<N<<" "<<(*itr)->permit()->permitNumber()<<std::endl;
}

void AverageSeatCount(const Container &data, VehicleType type)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }
    int count = 0;
    float sum = std::accumulate(
        data.begin(),
        data.end(),
        0.0f,
        [&](float value_upto_current_point,const TransportVehiclePtr& ptr){
            if(ptr->type()==type){
                count++;
                return value_upto_current_point+ptr->seatCount();
            }
            else{
                return value_upto_current_point;
            }
        }
    );
    std::lock_guard<std::mutex>lk(m1);
    std::cout<<"Average "<<sum/static_cast<float>(count)<<std::endl;
}

void PrintAllINstancesHaveSmeVehicleTYpe(const Container &data)
{
    if(data.empty()){
        throw std::runtime_error("Data is empty");
    }
    VehicleType type = data[0]->type();
    bool check = std::all_of(
        data.begin(),
        data.end(),
        [&](const TransportVehiclePtr& ptr){
            return ptr->type()==type;
        }
    );
    std::lock_guard<std::mutex>lk(m1);
    std::cout<<"All have same type "<< std::boolalpha << check<<std::endl;
}
