#include "Permit.h"

Permit::Permit(std::string permit_number, unsigned int permit_situation)
    : _permit_number{permit_number},_permit_situation{permit_situation}
{
}
std::ostream &operator<<(std::ostream &os, const Permit &rhs) {
    os << "_permit_number: " << rhs._permit_number
       << " _permit_situation: " << rhs._permit_situation;
    return os;
}
