#ifndef TRANSPORTVEHICLE_H
#define TRANSPORTVEHICLE_H

#include "Permit.h"
#include "VehicleType.h"
#include <memory>
#include <ostream>
using PermitPtr = std::shared_ptr<Permit>;

class TransportVehicle
{
private:
    PermitPtr _permit;
    VehicleType _type;
    unsigned int _seat_count;
    unsigned int _stops_count;

public:
    TransportVehicle(/* args */) = default;
    TransportVehicle(const TransportVehicle&) = delete;
    TransportVehicle(TransportVehicle&&) = delete;
    TransportVehicle& operator=(TransportVehicle&&) = delete;
    TransportVehicle& operator=(const TransportVehicle&)= delete;
    ~TransportVehicle() = default;
    
    TransportVehicle(PermitPtr _permit,
    VehicleType _type,
    unsigned int _seat_count,
    unsigned int _stops_count);
    PermitPtr permit() const { return _permit; }

    VehicleType type() const { return _type; }

    unsigned int seatCount() const { return _seat_count; }

    unsigned int stopsCount() const { return _stops_count; }

    friend std::ostream &operator<<(std::ostream &os, const TransportVehicle &rhs);
};

#endif // TRANSPORTVEHICLE_H
