#ifndef PERMIT_H
#define PERMIT_H

#include <iostream>

class Permit
{
private:
    std::string _permit_number;
    unsigned int _permit_situation;

public:
    Permit(/* args */) = default;
    Permit(const Permit &) = delete;
    Permit(Permit &&) = delete;
    Permit &operator=(Permit &&) = delete;
    Permit &operator=(const Permit &) = delete;
    ~Permit() = default;

    Permit(std::string permit_number,
           unsigned int permit_situation);

    std::string permitNumber() const { return _permit_number; }

    unsigned int permitSituation() const { return _permit_situation; }

    friend std::ostream &operator<<(std::ostream &os, const Permit &rhs);
};

#endif // PERMIT_H
