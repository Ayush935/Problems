#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include "TransportVehicle.h"
#include <array>
#include <algorithm>
#include <numeric>
#include <mutex>
#include <thread>
using TransportVehiclePtr = std::shared_ptr<TransportVehicle>;
using Container = std::array<TransportVehiclePtr,4>;
using ThreadContainer = std::array<std::thread,3>;

void CreateObject(Container &data);

void FindAndDisplayPermitNumberAtN(const Container&data, unsigned int N);

void AverageSeatCount(const Container&data,VehicleType type);

void PrintAllINstancesHaveSmeVehicleTYpe(const Container& data);

#endif // FUNCTIONALITIES_H
