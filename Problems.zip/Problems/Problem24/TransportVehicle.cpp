#include "TransportVehicle.h"
std::ostream &operator<<(std::ostream &os, const TransportVehicle &rhs) {
    os << "_permit: " << rhs._permit
       << " _type: " << static_cast<int>(rhs._type)
       << " _seat_count: " << rhs._seat_count
       << " _stops_count: " << rhs._stops_count;
    return os;
}

TransportVehicle::TransportVehicle(PermitPtr _permit, VehicleType _type, unsigned int _seat_count, unsigned int _stops_count)
    :_permit{_permit},_type{_type},_seat_count{_seat_count},_stops_count{_stops_count}
{
}