#include "Vehicle.h"
#include <vector>

using Container = std::vector<Vehicle*>;

void CreateObjVehicle(Container &data);

Container PrintCalculateServicingCost(const Container&data);

void PrintTaxExceptionAmount(const Container &data);

void DisplayPriceBrand(const Container&data, const  std::string registrationNumber);

void DestroyObjVehicle(Container &data);

