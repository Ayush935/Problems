#ifndef CAR_H
#define CAR_H

#include "CarType.h"
#include "Vehicle.h"
#include <ostream>

class Car: public Vehicle
{
private:
CarType _car_type;
    
public:
    Car(/* args */) = default;    
    Car(const Car&) = delete;
    Car &operator=(const Car&) = delete;
    Car(Car&&) = delete;
    Car &operator=(Car&&) = delete;
    ~Car() = default;
    
    Car(std::string registration_number,std::string _brand,float price,CarType car_type);

    CarType carType() const { return _car_type; }
    void setCarType(const CarType &car_type) { _car_type = car_type; }

    float CalculateServicingCost();

    float TaxExceptionAmount();

    friend std::ostream &operator<<(std::ostream &os, const Car &rhs);

};

#endif // CAR_H
