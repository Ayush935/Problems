#include "Car.h"

Car::Car(std::string registration_number, std::string _brand, float price, CarType car_type)
    : Vehicle(registration_number,_brand,price), _car_type{car_type}
{
}

std::ostream &operator<<(std::ostream &os, const Car &rhs) {
    os << static_cast<const Vehicle &>(rhs)
       << " _car_type: " << static_cast<int>(rhs._car_type);
    return os;
}

float Car::CalculateServicingCost()
{
    return 0.08*price();
}

float Car::TaxExceptionAmount()
{
    if(CarType()==CarType::COMMUTE){
        return 0.2*price();
    }

    return 0.15*price();
}
