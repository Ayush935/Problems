#include "Functionalities.h"

int main()
{
    Container data;
    CreateObjVehicle(data);

    try
    {

        for (Vehicle *ptr : PrintCalculateServicingCost(data))
        {
            std::cout << *ptr << std::endl;
        }
        
        std::cout<<"Tax Exception amount are as follows"<<std::endl;
        PrintTaxExceptionAmount(data);
        
        DisplayPriceBrand(data, "MH123");

        DestroyObjVehicle(data);
    }
    catch (const std::exception &e)
    {
        std::cerr << e.what() << '\n';
    }
}