#include "Functionalities.h"
#include "Car.h"
#include "Bike.h"
#include "ContainerDataException.h"
#include "InvalidValueException.h"

void CreateObjVehicle(Container &data)
{
    data.push_back(new Car("MH123","XEON",20040.0f,CarType::COMMERCIAL));
    data.push_back(new Car("MH132","XE23ON",277777.565f,CarType::COMMUTE));
    data.push_back(new Bike("MH345","FERRARI",2000000.0F,BrakingSystem::ABS));
    data.push_back(new Bike("MH645","FERRA43RI",123000.0F,BrakingSystem::TRADITIONAL));

}

Container PrintCalculateServicingCost(const Container &data)
{
    if(data.empty()){
        throw ContainerDataException("Data is empty");
    }

    Container result;
    result.push_back(data[0]);
    result.push_back(data[data.size()-1]);

    return result;
}

void PrintTaxExceptionAmount(const Container &data)
{
   if(data.empty()){
        throw ContainerDataException("Data is empty");
    }
    int count =0;
    for(Vehicle*ptr : data){
        if(ptr &&  ptr->TaxExceptionAmount()){
            std::cout<< "Vehicle "<<count++<<" ";
            std::cout<<ptr->TaxExceptionAmount()<<std::endl;
        }
    } 
}

void DisplayPriceBrand(const Container &data,const std::string registrationNumber)
{
    if(data.empty()){
        throw ContainerDataException("Data is empty");
    }
    int count =0;
    for(Vehicle*ptr : data){
        count++;
        if(ptr && ptr->registrationNumber()==registrationNumber){
            std::cout<<"Price and Brand of Vehicle "<<count<<std::endl;
            std::cout<<"Price "<<ptr->price()<<"\n";
            std::cout<<"brand "<<ptr->brand()<<"\n";
        }
    } 
    
}

void DestroyObjVehicle(Container &data)
{
    if(data.empty()){
        throw ContainerDataException("Data is empty");
    }

    for(Vehicle*ptr: data){
        if(ptr){
            delete ptr;
        }
    }
}
