#include "Bike.h"

Bike::Bike(std::string registration_number, std::string _brand, float price, BrakingSystem braking_syztem)
   : Vehicle(registration_number,_brand,price), _braking_system{braking_syztem}
{
}

std::ostream &operator<<(std::ostream &os, const Bike &rhs) {
    os << "_braking_system: " << static_cast<int>(rhs._braking_system);
    return os;
}

float Bike::CalculateServicingCost()
{
    return 0.25*price()+((0.25*price())*0.18);
}


