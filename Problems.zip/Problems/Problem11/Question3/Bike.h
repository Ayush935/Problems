#ifndef BIKE_H
#define BIKE_H

#include "BrakingSystem.h"
#include <iostream>
#include "Vehicle.h"

class Bike: public Vehicle
{
private:
    BrakingSystem _braking_system;
public:
    Bike(/* args */) = default;    
    Bike(const Bike&) = delete;
    Bike &operator=(const Bike&) = delete;
    Bike(Bike&&) = delete;
    Bike &operator=(Bike&&) = delete;
    ~Bike() = default;

    Bike(std::string registration_number,std::string _brand,float price,BrakingSystem braking_syztem);

    BrakingSystem brakingSystem() const { return _braking_system; }
    void setBrakingSystem(const BrakingSystem &braking_system) { _braking_system = braking_system; }

    float CalculateServicingCost();

    friend std::ostream &operator<<(std::ostream &os, const Bike &rhs);
  

};


#endif // BIKE_H
