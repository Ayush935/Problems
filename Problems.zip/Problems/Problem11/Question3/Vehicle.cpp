#include "Vehicle.h"
std::ostream &operator<<(std::ostream &os, const Vehicle &rhs) {
    os << "_registration_number: " << rhs._registration_number
       << " _brand: " << rhs._brand
       << " _price: " << rhs._price;
    return os;
}

Vehicle::Vehicle(std::string registration_number, std::string _brand, float price)
    : _registration_number{registration_number}, _brand{_brand},_price{price}

{
}

float Vehicle::TaxExceptionAmount()
{
    return _price*0.05;
}
