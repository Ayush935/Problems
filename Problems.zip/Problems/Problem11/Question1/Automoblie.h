#ifndef AUTOMOBLIE_H
#define AUTOMOBLIE_H

#include <iostream>
#include "AutomobileType.h"

class Automoblie
{
private:
    std::string _model_name;
    AutomobileType _automobile_type;
    float _automobile_price;
    float _automobile_mileage;

public:
    Automoblie(/* args */) = default;    
    Automoblie(const Automoblie&) = delete;
    Automoblie &operator=(const Automoblie&) = delete;
    Automoblie(Automoblie&&) = delete;
    Automoblie &operator=(Automoblie&&) = delete;
    ~Automoblie() = default;

    Automoblie(std::string model_name,AutomobileType automobile_type,float automobile_price,float automobile_mileage);

    std::string modelName() const { return _model_name; }

    AutomobileType automobileType() const { return _automobile_type; }
    void setAutomobileType(const AutomobileType &automobile_type) { _automobile_type = automobile_type; }

    float automobilePrice() const { return _automobile_price; }
    void setAutomobilePrice(float automobile_price) { _automobile_price = automobile_price; }

    float automobileMileage() const { return _automobile_mileage; }
    void setAutomobileMileage(float automobile_mileage) { _automobile_mileage = automobile_mileage; }

    friend std::ostream &operator<<(std::ostream &os, const Automoblie &rhs);

    
};

#endif // AUTOMOBLIE_H
