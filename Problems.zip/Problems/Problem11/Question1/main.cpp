#include "Functionalities.h"

int main(){
    Container data;
    CreateObjAutomobile(data);

    try
    {
      std::cout<<"Average of mileage " <<  FindAverageMileage(data)<<std::endl;

      std::cout<<"Count of Instance who matches thr type "<< CountMatchesType(data, AutomobileType::PRIVATE)<<std::endl;

      std::cout<<"Is there any Instance whose price is greater than 20000, 1 for true, 0 for false "<< std::endl  <<
        InstancePrice(data, 20000.0f)<<std::endl;

       DestroyObjAutomobile(data);
    }
    catch(const ContainerDataException& e)
    {
        std::cerr << e.msg() << '\n';
    }
    catch(const InvalidValueException& e)
    {
        std::cerr << e.msg() << '\n';
    }
    
}