#ifndef AUTOMOBILETYPE_H
#define AUTOMOBILETYPE_H

enum class AutomobileType{
    PRIVATE,
    TRANSPORT
};

#endif // AUTOMOBILETYPE_H
