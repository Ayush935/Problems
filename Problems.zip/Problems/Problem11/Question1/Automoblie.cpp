#include "Automoblie.h"
std::ostream &operator<<(std::ostream &os, const Automoblie &rhs) {
    os << "_model_name: " << rhs._model_name
       << " _automobile_type: " << static_cast<int>(rhs._automobile_type)
       << " _automobile_price: " << rhs._automobile_price
       << " _automobile_mileage: " << rhs._automobile_mileage;
    return os;
}

Automoblie::Automoblie(std::string model_name, AutomobileType automobile_type, float automobile_price, float automobile_mileage)
    : _model_name{model_name},_automobile_type{automobile_type},_automobile_price{automobile_price},_automobile_mileage{automobile_mileage}
{
}