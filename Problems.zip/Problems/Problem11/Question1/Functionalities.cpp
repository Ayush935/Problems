#include "Functionalities.h"


void CreateObjAutomobile(Container &data)
{
    data.push_back(new Automoblie("XTT",AutomobileType::PRIVATE,203000.0f,42.0f));
    data.push_back(new Automoblie("XYT",AutomobileType::TRANSPORT,103000.0f,52.0f));
    data.push_back(new Automoblie("XRT",AutomobileType::PRIVATE,203000.0f,42.0f));
    data.push_back(new Automoblie("XTC",AutomobileType::TRANSPORT,243000.0f,82.0f));
}

float FindAverageMileage(const Container &data)
{
    if(data.empty()){
        throw ContainerDataException("Data is empty");
    }
    
    float sum = 0.0f;
    for(Automoblie* ptr: data){
        if(ptr){
            sum = sum + ptr->automobileMileage();
        }
    }

    return sum/data.size();
    
}

int CountMatchesType(const Container &data, AutomobileType type)
{
    if(data.empty()){
        throw ContainerDataException("Data is empty");
    }
    
    int count = 0;
    for(Automoblie* ptr: data){
        if(ptr && ptr->automobileType()==type){
            count ++;
        }
    }

    return count;
}

bool InstancePrice(const Container &data, float price)
{
    if(data.empty()){
        throw ContainerDataException("Data is empty");
    }

    if(price < 0){
        throw InvalidValueException("Price value is invalid");
    }
    for(Automoblie* ptr: data){
        if(ptr && ptr->automobilePrice()==price){
            return true;
        }
    }

    return false;
   

}

void DestroyObjAutomobile(Container &data)
{
    if(data.empty()){
        throw ContainerDataException("Data is empty");
    }

    for(Automoblie*ptr: data){
        delete ptr;
    }
}
