#include "Automoblie.h"
#include <vector>
#include "ContainerDataException.h"
#include "InvalidValueException.h"

using Container = std::vector<Automoblie*>;

/*
  Create Objects of Automobiles in a Container
*/
void CreateObjAutomobile(Container &data);

float FindAverageMileage(const Container &data);

int CountMatchesType(const Container& data, AutomobileType type);

bool InstancePrice(const Container&data, float price);

void DestroyObjAutomobile(Container &data);