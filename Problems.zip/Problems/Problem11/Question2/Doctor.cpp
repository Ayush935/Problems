#include "Doctor.h"
std::ostream &operator<<(std::ostream &os, const Doctor &rhs) {
    os << "_doctor_id: " << rhs._doctor_id
       << " _doctor_fees: " << rhs._doctor_fees
       << " _speciality: " << static_cast<int>(rhs._speciality)
       << " _patient: " << *(rhs._patient);
    return os;
}

Doctor::Doctor(std::string doctor_id, float doctor_fees, DoctorSpeciality speciality, Patient *patient)
    : _doctor_id{doctor_id}, _doctor_fees{doctor_fees},_speciality{speciality},_patient{patient}
{
}
