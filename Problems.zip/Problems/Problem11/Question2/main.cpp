#include "Functionalities.h"

int main()
{
    Container data;
    CreateObjDoctor(data);

    try
    {
        std::cout << "Count of Doctor Fees greater than Rs 5000" << CountDoctorFees(data, 5000.0f) << std::endl;

        std::cout << "Are the Doctor with Speciality Cardiologist present 1 for true, 0 for false" << std::endl
                  << FindDoctorSpeciality(data, DoctorSpeciality::CARDIOLOGIST) << std::endl;

        std::cout << "Average of ages" << AverageAges(data);

        for (Doctor *ptr : DisplayLastNInstances(data))
        {
            std::cout << *ptr << std::endl;
        }

        DeleteObjDoctor(data);
    }
    catch (const std::exception &e)
    {
        std::cerr << e.what() << '\n';
    }
}