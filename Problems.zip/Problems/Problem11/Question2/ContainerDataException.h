#ifndef CONTAINERDATAEXCEPTION_H
#define CONTAINERDATAEXCEPTION_H

#include <iostream>
#include <stdexcept>

class ContainerDataException: std::exception
{
private:
    std::string _msg;
public:
    ContainerDataException(/* args */) = default;    
    ContainerDataException(const ContainerDataException&) = delete;
    ContainerDataException &operator=(const ContainerDataException&) = delete;
    ContainerDataException(ContainerDataException&&) = delete;
    ContainerDataException &operator=(ContainerDataException&&) = default;
    ~ContainerDataException() = default;

    ContainerDataException(std::string msg){msg = _msg;};

    std::string msg() const { return _msg; }
};

#endif // CONTAINERDATAEXCEPTION_H
