#ifndef PATIENTTYPE_H
#define PATIENTTYPE_H

enum class PatientType{
    REGULAR,
    NEW
};

#endif // PATIENTTYPE_H
