#include "Doctor.h"
#include <vector>

using Container = std::vector<Doctor*>;

void CreateObjDoctor(Container &data);

int CountDoctorFees(const Container &data, float fees);

bool FindDoctorSpeciality(const Container &data, const DoctorSpeciality &speciality);

float AverageAges(const Container &data);

Container DisplayLastNInstances(Container &data);

void DeleteObjDoctor(Container &data);