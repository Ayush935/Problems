#include "Functionalities.h"
#include "ContainerDataException.h"
#include "InvalidValueException.h"

void CreateObjDoctor(Container &data)
{
    data.push_back(new Doctor("SD123", 12000.0f, DoctorSpeciality::CARDIOLOGIST, new Patient("I123", 29, PatientType::NEW)));
    data.push_back(new Doctor("MD123", 5000.0f, DoctorSpeciality::DERMATOLOGIST, new Patient("I133", 69, PatientType::REGULAR)));
    data.push_back(new Doctor("SD423", 2000.0f, DoctorSpeciality::GENERAL_PHYSICIAN, new Patient("I153", 59, PatientType::NEW)));
    data.push_back(new Doctor("SD143", 10000.0f, DoctorSpeciality::NEUROLOGIST, new Patient("I143", 49, PatientType::REGULAR)));
}

int CountDoctorFees(const Container &data, float fees)
{
    if (data.empty())
    {
        throw ContainerDataException("Data is empty");
    }

    if (fees < 0)
    {
        throw InvalidValueException("Value is not cvalid");
    }

    int count = 0;
    for (Doctor *ptr : data)
    {
        if (ptr && ptr->doctorFees() > fees)
        {
            count++;
        }
    }

    return count;
}

bool FindDoctorSpeciality(const Container &data, const DoctorSpeciality &speciality)
{
    if (data.empty())
    {
        throw ContainerDataException("Data is empty");
    }
    for (Doctor *ptr : data)
    {
        if (ptr && ptr->speciality() == speciality)
        {
            return true;
        }
    }

    return false;
}

float AverageAges(const Container &data)
{
    if (data.empty())
    {
        throw ContainerDataException("Data is empty");
    }

    float sum = 0.0f;
    for (Doctor *ptr : data)
    {
        if (ptr && ptr->patient())
        {
            sum = sum + ptr->patient()->patientAge();
        }
    }

    return sum / data.size();
}

Container DisplayLastNInstances(Container &data)
{
    if (data.empty())
    {
        throw ContainerDataException("Data is empty");
    }

    Container result;

    for (Container::reverse_iterator itr = data.rbegin(); itr != data.rend(); itr++)
    {
        result.push_back(*itr);
    }

    return result;
}

void DeleteObjDoctor(Container &data)
{
    if (data.empty())
    {
        throw ContainerDataException("Data is empty");
    }

    for (Doctor *ptr : data)
    {
        if (ptr)
        {
            if (ptr->patient())
            {
                delete ptr->patient();
            }

            delete ptr;
        }
    }
}
