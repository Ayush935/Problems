#ifndef PATIENT_H
#define PATIENT_H

#include <iostream>
#include "PatientType.h"

class Patient
{
private:
    std::string _patient_id;
    int _patient_age;
    PatientType _Patient_type;

public:
    Patient(/* args */) = default;
    Patient(const Patient &) = delete;
    Patient &operator=(const Patient &) = delete;
    Patient(Patient &&) = delete;
    Patient &operator=(Patient &&) = delete;
    ~Patient() = default;

    Patient(std::string patient_id,int patient_age,PatientType Patient_type);

    std::string patientId() const { return _patient_id; }

    int patientAge() const { return _patient_age; }

    PatientType patientType() const { return _Patient_type; }
    void setPatientType(const PatientType &Patient_type) { _Patient_type = Patient_type; }

    friend std::ostream &operator<<(std::ostream &os, const Patient &rhs);
    
};

#endif // PATIENT_H
