#ifndef DOCTOR_H
#define DOCTOR_H

#include <iostream>
#include "DoctorSpeciality.h"
#include "Patient.h"

class Doctor
{
private:
    std::string _doctor_id;
    float _doctor_fees;
    DoctorSpeciality _speciality;
    Patient *_patient;

public:
    Doctor(/* args */) = default;
    Doctor(const Doctor &) = delete;
    Doctor &operator=(const Doctor &) = delete;
    Doctor(Doctor &&) = delete;
    Doctor &operator=(Doctor &&) = delete;
    ~Doctor() = default;

    Doctor(std::string doctor_id, float doctor_fees, DoctorSpeciality speciality, Patient *patient);

    std::string doctorId() const { return _doctor_id; }

    float doctorFees() const { return _doctor_fees; }
    void setDoctorFees(float doctor_fees) { _doctor_fees = doctor_fees; }

    Patient *patient() const { return _patient; }
    void setPatient(Patient *patient) { _patient = patient; }

    DoctorSpeciality speciality() const { return _speciality; }
    void setSpeciality(const DoctorSpeciality &speciality) { _speciality = speciality; }

    friend std::ostream &operator<<(std::ostream &os, const Doctor &rhs);
};

#endif // DOCTOR_H
