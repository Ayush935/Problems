#include "Patient.h"
std::ostream &operator<<(std::ostream &os, const Patient &rhs) {
    os << "_patient_id: " << rhs._patient_id
       << " _patient_age: " << rhs._patient_age
       << " _Patient_type: " << static_cast<int>(rhs._Patient_type);
    return os;
}

Patient::Patient(std::string patient_id, int patient_age, PatientType Patient_type)
    : _patient_id{patient_id},_patient_age{patient_age},_Patient_type{Patient_type}
{
}