#ifndef INVALIDVALUEEXCEPTION_H
#define INVALIDVALUEEXCEPTION_H

#include <iostream>
#include <stdexcept>

class InvalidValueException: std::exception
{
private:
    std::string _msg;
public:
    InvalidValueException(/* args */) = default;    
    InvalidValueException(const InvalidValueException&) = delete;
    InvalidValueException &operator=(const InvalidValueException&) = delete;
    InvalidValueException(InvalidValueException&&) = delete;
    InvalidValueException &operator=(InvalidValueException&&) = default;
    ~InvalidValueException() = default;

    InvalidValueException(std::string msg){msg = _msg;};

    std::string msg() const { return _msg; }
};

#endif // INVALIDVALUEEXCEPTION_H
