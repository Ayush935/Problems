#ifndef DATAHANDLER_H
#define DATAHANDLER_H

#include <array>
#include <memory>
#include <mutex>
#include <algorithm>
#include <numeric>
#include <iostream>
#include <condition_variable>
#include <thread>
class DataHandler;
using DataHandlerPtr = std::unique_ptr<DataHandler>;
using Container = std::array<int,5>;
using THreadContainer = std::array<std::thread,4>;

class DataHandler
{
private:
    Container _data;
    Container _square_results;
    Container _factoria_results;
    bool flag{false};
    static DataHandlerPtr _only_object;
    std::mutex m1;
    std::condition_variable cv;

    DataHandler(/* args */) = default;
    DataHandler(const DataHandler &) = delete;
    DataHandler(DataHandler &&) = delete;
    DataHandler &operator=(DataHandler &&) = delete;
    DataHandler &operator=(const DataHandler &) = delete;
public:
    
    ~DataHandler() = default;

    static DataHandlerPtr& GetInstance();

    void TakeInput();

    void ComputeSquare();

    void Factorial();

    void CalcAverageValue();

};

#endif // DATAHANDLER_H
