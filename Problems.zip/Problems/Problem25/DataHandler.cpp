#include "DataHandler.h"

DataHandlerPtr DataHandler::_only_object;

DataHandlerPtr &DataHandler::GetInstance()
{
    // TODO: insert return statement here
    if(_only_object){
        return _only_object;
    }
    else{
        _only_object.reset(new DataHandler());
        return _only_object;
    }
}

void DataHandler::TakeInput()
{
    std::unique_lock<std::mutex>ul(m1);

    std::cout<<"Insert Values "<<std::endl;
    int count{0};
    int num{0};
    while (count!=5)
    {
        std::cout<<"Enter "<<"\n";
        std::cin>>num;

        if(num<1 || num>10){
            std::cout<<"reenter value";
        }
        else{
            _data[count] = num;
            count++;
        }
    }

    flag = true;

    cv.notify_one();
    
}

void DataHandler::ComputeSquare()
{
    int count = 0;
    int num = 1;
    while(count!=5){
        if(num%3==0){
            _square_results[count] = num*num;
            count++;
        }
        num++;
    }

    std::lock_guard<std::mutex>lk(m1);
    std::cout<<"Square ";
    for(int &val : _square_results){
        std::cout<<val<<" ";
    }
    std::cout<<std::endl;
}

void DataHandler::Factorial()
{
    std::unique_lock<std::mutex>ul(m1);
    cv.wait(ul,[&](){return flag;});
    
    int fact{1};
    for(int i=0;i<5;i++){
        fact = 1;
        for(int j=1;j<=_data[i];j++){
            fact*=j; 
        }
        _factoria_results[i] = fact;
    }
    std::cout<<"fact"<<std::endl;
    for(int &val : _factoria_results){
        std::cout<<val<<" ";
    }
    std::cout<<std::endl;


}

void DataHandler::CalcAverageValue()
{
    std::array<int,5>a{2,3,5,7,11};

    float sum = std::accumulate(
        a.begin(),
        a.end(),
        0.0f,
        [](float value_upto_current_point, const int &b){
            return value_upto_current_point+b;
        }
    );
     std::lock_guard<std::mutex>lk(m1);
    std::cout<<"Average "<<sum/static_cast<float>(a.size())<<std::endl;
}
