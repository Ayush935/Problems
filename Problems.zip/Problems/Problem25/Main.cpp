#include "DataHandler.h"

int main(){
    DataHandlerPtr& ptr = DataHandler::GetInstance();

    THreadContainer thdata;

    thdata[0] = std::thread(&DataHandler::TakeInput,ptr.get());
    thdata[1] = std::thread(&DataHandler::ComputeSquare,ptr.get());
    thdata[2] = std::thread(&DataHandler::CalcAverageValue,ptr.get());
    thdata[3] = std::thread(&DataHandler::Factorial,ptr.get());

    for(std::thread& t: thdata){
        if(t.joinable()){
            t.join();
        }
    }

    // std::thread t(&DataHandler::TakeInput,ptr.get());
    // if(t.joinable()){
    //         t.join();
    //     }

}